drop TABLE PEI_CUSTOM.XX_VENDOR_FILE_1;
create table PEI_CUSTOM.XX_VENDOR_FILE_1
(
  file_id      VARCHAR2(50 CHAR) not null,
  display_name VARCHAR2(60 CHAR),
  actual_name  VARCHAR2(60 CHAR),
  category     VARCHAR2(32 CHAR),
  create_date  DATE,
  create_by    VARCHAR2(32 CHAR)
);
INSERT INTO PEI_CUSTOM.XX_VENDOR_FILE_1 SELECT * FROM PEI_CUSTOM.XX_VENDOR_FILE;



drop TABLE PEI_CUSTOM.XX_VENDOR_FILE_CATEGORY_1;
create table PEI_CUSTOM.XX_VENDOR_FILE_CATEGORY_1
(
  id          VARCHAR2(32 CHAR) not null,
  name        VARCHAR2(60 CHAR),
  description VARCHAR2(255 CHAR)
);
insert into PEI_CUSTOM.XX_VENDOR_FILE_CATEGORY_1 SELECT * FROM PEI_CUSTOM.XX_VENDOR_FILE_CATEGORY;

drop TABLE PEI_CUSTOM.XX_VENDOR_GROUPS_1;
create table PEI_CUSTOM.XX_VENDOR_GROUPS_1
(
  id                VARCHAR2(255 CHAR) not null,
  name              VARCHAR2(80 CHAR),
  cn                VARCHAR2(80 CHAR),
  distinguishedname VARCHAR2(255 CHAR),
  description       VARCHAR2(255 CHAR),
  samaccountname    VARCHAR2(80 CHAR),
  objectcategory    VARCHAR2(255 CHAR),
  objectclass       VARCHAR2(200 CHAR)
);
INSERT INTO PEI_CUSTOM.XX_VENDOR_GROUPS_1 SELECT * FROM PEI_CUSTOM.XX_VENDOR_GROUPS;


drop TABLE PEI_CUSTOM.XX_VENDOR_GROUP_PERMISSION_1;
create table PEI_CUSTOM.XX_VENDOR_GROUP_PERMISSION_1
(
  group_id      VARCHAR2(255 CHAR) not null,
  permission_id VARCHAR2(255 CHAR) not null,
  created_by    VARCHAR2(32 CHAR),
  created_date  DATE
);
INSERT INTO PEI_CUSTOM.XX_VENDOR_GROUP_PERMISSION_1 SELECT * FROM PEI_CUSTOM.XX_VENDOR_GROUP_PERMISSION;


drop TABLE PEI_CUSTOM.XX_VENDOR_LOG_1;
create table PEI_CUSTOM.XX_VENDOR_LOG_1
(
  id        NUMBER(10) not null,
  ntype     VARCHAR2(1 CHAR) not null,
  info      VARCHAR2(200 CHAR) not null,
  created   TIMESTAMP(6) not null,
  funtype   VARCHAR2(1 CHAR),
  opuser    VARCHAR2(255 CHAR),
  vid       NUMBER(10),
  opper     NUMBER(10),
  isemail   NUMBER(10),
  emailtime TIMESTAMP(6),
  emailstr  VARCHAR2(255 CHAR)
);
INSERT INTO PEI_CUSTOM.XX_VENDOR_LOG_1 SELECT * FROM PEI_CUSTOM.XX_VENDOR_LOG;

drop table PEI_CUSTOM.XX_VENDOR_MANNUL_1;
create table PEI_CUSTOM.XX_VENDOR_MANNUL_1
(
  id         NUMBER(10) not null,
  title      VARCHAR2(100 CHAR) not null,
  summary    VARCHAR2(300 CHAR),
  scontent   BLOB,
  sequence   VARCHAR2(50 CHAR) not null,
  editor     VARCHAR2(50 CHAR),
  fileext    VARCHAR2(10 CHAR),
  ntype      NUMBER(10),
  updatetime TIMESTAMP(6),
  subnodeseq VARCHAR2(500 CHAR),
  isemail    NUMBER(10),
  pid        NUMBER(10)
);
INSERT INTO PEI_CUSTOM.XX_VENDOR_MANNUL_1 SELECT * FROM PEI_CUSTOM.XX_VENDOR_MANNUL;


drop table PEI_CUSTOM.XX_VENDOR_NEWS_1;
create table PEI_CUSTOM.XX_VENDOR_NEWS_1
(
  id          NUMBER(10) not null,
  title       VARCHAR2(300 CHAR) not null,
  redirecturl VARCHAR2(100 CHAR),
  norder      NUMBER(10),
  updatetime  DATE default sysdate not null,
  status      VARCHAR2(1 CHAR) default '0' not null,
  editor      VARCHAR2(50 CHAR),
  subject     NUMBER(10) default 0,
  scontent    BLOB
);
INSERT INTO PEI_CUSTOM.XX_VENDOR_NEWS_1 SELECT * FROM PEI_CUSTOM.XX_VENDOR_NEWS;

drop table PEI_CUSTOM.XX_VENDOR_PERMISSIONS_1;
create table PEI_CUSTOM.XX_VENDOR_PERMISSIONS_1
(
  id          VARCHAR2(255 CHAR) not null,
  name        VARCHAR2(80 CHAR),
  description VARCHAR2(255 CHAR),
  perm_levle  NUMBER(10)
);
INSERT INTO PEI_CUSTOM.XX_VENDOR_PERMISSIONS_1 SELECT * FROM PEI_CUSTOM.XX_VENDOR_PERMISSIONS;


/*
drop table PEI_CUSTOM.XX_VENDOR_SYNC_USERS_1;
create table PEI_CUSTOM.XX_VENDOR_SYNC_USERS_1
(
  account                 VARCHAR2(50) not null,
  name                    VARCHAR2(255) not null,
  enabled                 CHAR(1) default 'T' not null,
  email                   VARCHAR2(255),
  notification_enabled    CHAR(1) default 'F' not null,
  last_notified_time      DATE,
  last_activity_time      DATE,
  inactive_window_minutes NUMBER(10) default 60,
  machine_name            VARCHAR2(255),
  ora_aspnet_userid       RAW(16)
);
INSERT INTO PEI_CUSTOM.XX_VENDOR_SYNC_USERS_1 SELECT * FROM PEI_CUSTOM.XX_VENDOR_SYNC_USERS;
*/


drop TABLE PEI_CUSTOM.XX_VENDOR_USERS_1;
create table PEI_CUSTOM.XX_VENDOR_USERS_1
(
  id                  VARCHAR2(255 CHAR) not null,
  samaccountname      VARCHAR2(25 CHAR),
  objectcategory      VARCHAR2(255 CHAR),
  mail                VARCHAR2(50 CHAR),
  name                VARCHAR2(200 CHAR),
  department          VARCHAR2(32 CHAR),
  distinguishedname   VARCHAR2(255 CHAR),
  objectclass         VARCHAR2(200 CHAR),
  userprincipalname   VARCHAR2(50 CHAR),
  upload_folder       VARCHAR2(120 CHAR),
  download_folder     VARCHAR2(120 CHAR),
  domain_name         VARCHAR2(80 CHAR),
  title               VARCHAR2(60 CHAR),
  company             VARCHAR2(255 CHAR),
  sn                  VARCHAR2(50 CHAR),
  telephone_number    VARCHAR2(40 CHAR),
  postal_code         VARCHAR2(10 CHAR),
  given_name          VARCHAR2(50 CHAR),
  country             VARCHAR2(60 CHAR),
  city                VARCHAR2(60 CHAR),
  street_address      VARCHAR2(60 CHAR),
  state               VARCHAR2(32 CHAR),
  password            VARCHAR2(60 CHAR),
  webpdmgroups        VARCHAR2(50 CHAR),
  first_name          VARCHAR2(50 CHAR),
  last_name           VARCHAR2(50 CHAR),
  direct_phone        VARCHAR2(50 CHAR),
  fax_number          VARCHAR2(50 CHAR),
  relation_to_company VARCHAR2(255 CHAR),
  reason_for_account  VARCHAR2(50 CHAR),
  print_name          VARCHAR2(50 CHAR),
  intra_print_name    VARCHAR2(50 CHAR),
  isactive            NUMBER(1),
  logon_time          TIMESTAMP(6)
);
INSERT INTO PEI_CUSTOM.XX_VENDOR_USERS_1 SELECT id,samaccountname,objectcategory,mail,name,department,distinguishedname,objectclass,userprincipalname,upload_folder,download_folder,domain_name,title,company,sn,telephone_number,postal_code,given_name,country,city,street_address,state,password,webpdmgroups,first_name,last_name,direct_phone,fax_number,relation_to_company,reason_for_account,print_name,intra_print_name,isactive,logon_time FROM PEI_CUSTOM.XX_VENDOR_USERS;


drop table PEI_CUSTOM.XX_VENDOR_USER_FILE_1;
create table PEI_CUSTOM.XX_VENDOR_USER_FILE_1
(
  user_id VARCHAR2(32 CHAR) not null,
  file_id VARCHAR2(50 CHAR) not null,
  is_show VARCHAR2(1 CHAR)
);
INSERT INTO PEI_CUSTOM.XX_VENDOR_USER_FILE_1 SELECT * FROM PEI_CUSTOM.XX_VENDOR_USER_FILE;


drop table PEI_CUSTOM.XX_VENDOR_USER_GROUP_1;
create table PEI_CUSTOM.XX_VENDOR_USER_GROUP_1
(
  user_id      VARCHAR2(255 CHAR) not null,
  groups_id    VARCHAR2(255 CHAR) not null,
  created_by   VARCHAR2(32 CHAR),
  created_date DATE
);
INSERT INTO PEI_CUSTOM.XX_VENDOR_USER_GROUP_1 SELECT * FROM PEI_CUSTOM.XX_VENDOR_USER_GROUP;

drop table PEI_CUSTOM.XX_VENDOR_USER_PERMISSION_1;
create table PEI_CUSTOM.XX_VENDOR_USER_PERMISSION_1
(
  permission_id VARCHAR2(255 CHAR) not null,
  user_id       VARCHAR2(255 CHAR) not null,
  created_by    VARCHAR2(32 CHAR),
  created_date  DATE
);
INSERT INTO PEI_CUSTOM.XX_VENDOR_USER_PERMISSION_1 SELECT * FROM PEI_CUSTOM.XX_VENDOR_USER_PERMISSION;
commit;
/*
alter table PEI_CUSTOM.XX_VENDOR_USER_PERMISSION
drop constraint FKA8BB39EBBB23F790;

alter table PEI_CUSTOM.XX_VENDOR_USER_PERMISSION
drop constraint FKA8BB39EB7A5A3381;

alter table PEI_CUSTOM.XX_VENDOR_USER_FILE
drop constraint FK_USER_FILE_USERD;
*/
/*
alter table PEI_CUSTOM.XX_VENDOR_USER_PERMISSION
drop constraint SYS_C0063556;

alter table PEI_CUSTOM.XX_VENDOR_USERS
drop constraint SYS_C0063543;
*/

/*PEI_CUSTOM.XX_VENDOR_USERS*/
update PEI_CUSTOM.XX_VENDOR_USERS
set ID=LOWER(ID);

update PEI_CUSTOM.XX_VENDOR_USERS
set ID=LOWER(replace(ID,'localhost','dmz1'))
where substr(id,1,14)='localhost__ra_';

update PEI_CUSTOM.XX_VENDOR_USERS
set ID=LOWER(replace(ID,'localhost','dmz1'))
where substr(id,1,14)='localhost__ro_';

commit;

update PEI_CUSTOM.XX_VENDOR_USERS
set ID=LOWER(replace(ID,'__','\'));

update PEI_CUSTOM.XX_VENDOR_USERS
set domain_name='DMZ1'
where domain_name='SyncUsers';

commit;
/*XX_VENDOR_USER_PERMISSION*/
update PEI_CUSTOM.XX_VENDOR_USER_PERMISSION
set USER_ID=LOWER(USER_ID);

update PEI_CUSTOM.XX_VENDOR_USER_PERMISSION
set USER_ID=LOWER(replace(USER_ID,'localhost','dmz1'))
where substr(USER_ID,1,14)='localhost__ra_';


update PEI_CUSTOM.XX_VENDOR_USER_PERMISSION
set USER_ID=LOWER(replace(USER_ID,'localhost','dmz1'))
where substr(USER_ID,1,14)='localhost__ro_';

commit;

update PEI_CUSTOM.XX_VENDOR_USER_PERMISSION
set USER_ID=LOWER(replace(USER_ID,'__','\'));

commit;

/*XX_VENDOR_LOG*/
update PEI_CUSTOM.XX_VENDOR_LOG
set OPUSER=LOWER(OPUSER);

update PEI_CUSTOM.XX_VENDOR_LOG
set OPUSER=LOWER(replace(OPUSER,'__','\'));
commit;


/*XX_VENDOR_USER_FILE*/
update PEI_CUSTOM.XX_VENDOR_USER_FILE
set USER_ID=LOWER(USER_ID);

update PEI_CUSTOM.XX_VENDOR_USER_FILE
set USER_ID=LOWER(replace(USER_ID,'localhost','dmz1'))
where substr(USER_ID,1,14)='localhost__ra_';

update PEI_CUSTOM.XX_VENDOR_USER_FILE
set USER_ID=LOWER(replace(USER_ID,'localhost','dmz1'))
where substr(USER_ID,1,14)='localhost__ro_';

update PEI_CUSTOM.XX_VENDOR_USER_FILE
set USER_ID=LOWER(replace(USER_ID,'__','\'));
commit;
/*
alter table PEI_CUSTOM.XX_VENDOR_USERS
add constraint PK_XXVU_ID PRIMARY KEY(ID);


alter table PEI_CUSTOM.XX_VENDOR_USER_PERMISSION
add constraints PK_XXVUP_PERMISSION_ID_USER_ID primary key(PERMISSION_ID,USER_ID);

alter table PEI_CUSTOM.XX_VENDOR_USER_PERMISSION
add constraint FK_XXVUP_PERMISSIONS_ID foreign key(PERMISSION_ID) 
references PEI_CUSTOM.XX_VENDOR_PERMISSIONS(ID);

alter table PEI_CUSTOM.XX_VENDOR_USER_PERMISSION
  add constraint FK_XXVUP_USERS_ID foreign key (USER_ID)
  references PEI_CUSTOM.XX_VENDOR_USERS (ID);
  
  alter table PEI_CUSTOM.XX_VENDOR_USER_FILE
add constraint FK_USER_FILE_USERD foreign key (USER_ID)
references PEI_CUSTOM.XX_VENDOR_USERS(ID);
*/

commit;

DELETE FROM "PEI_CUSTOM"."XX_VENDOR_USERS" WHERE ID NOT IN (
SELECT DISTINCT USER_ID FROM PEI_CUSTOM.XX_VENDOR_USER_PERMISSION
UNION
SELECT DISTINCT USER_ID FROM PEI_CUSTOM.XX_VENDOR_USER_FILE
);

DROP TABLE PEI_CUSTOM.XX_VENDOR_SYNC_USERS;
CREATE TABLE PEI_CUSTOM.XX_VENDOR_SYNC_USERS
(
      ACCOUNT                 VARCHAR2(50) NOT NULL,
      NAME                    VARCHAR2(255) NOT NULL,
      ENABLED                 CHAR(1) DEFAULT 'T' NOT NULL,
      EMAIL                   VARCHAR2(255),
      NOTIFICATION_ENABLED    CHAR(1) DEFAULT 'F' NOT NULL,
      LAST_NOTIFIED_TIME      DATE,
      LAST_ACTIVITY_TIME      DATE,
      INACTIVE_WINDOW_MINUTES NUMBER(10) DEFAULT 60,
      MACHINE_NAME            VARCHAR2(255),
      ORA_ASPNET_USERID       RAW(16),
      CONSTRAINT PK_VENDOR_SYNC_USERS PRIMARY KEY(ACCOUNT),
      CONSTRAINT "XX_VENDOR_SYNC_USERS_NAME_UQ" UNIQUE ("NAME")
);

GRANT SELECT, INSERT, UPDATE, DELETE ON PEI_CUSTOM.XX_VENDOR_SYNC_USERS TO PLM;

ALTER TABLE PEI_CUSTOM.XX_VENDOR_USERS 
ADD (ORA_ASPNET_USERID RAW(16) );

CREATE INDEX IX_VENDOR_USERS_ASPNET_USERID ON PEI_CUSTOM.XX_VENDOR_USERS (ORA_ASPNET_USERID);

UPDATE PEI_CUSTOM.XX_VENDOR_USERS V SET ORA_ASPNET_USERID=(SELECT USERID FROM PLM.ORA_ASPNET_USERS U WHERE U.LOWEREDUSERNAME=V.ID);

/*
ALTER TABLE PEI_CUSTOM.XX_VENDOR_USERS 
DROP COLUMN ORA_ASPNET_USERID;

MERGE INTO PEI_CUSTOM.XX_VENDOR_USERS V
USING
(
    SELECT LOWEREDEMAIL, USERID FROM (
        SELECT LOWEREDEMAIL,  ROW_NUMBER() OVER (PARTITION BY LOWEREDEMAIL ORDER BY LASTLOGINDATE DESC) LN, U.USERID FROM PLM.ORA_ASPNET_USERS U INNER JOIN PLM.ORA_ASPNET_MEMBERSHIP M ON U.USERID=M.USERID 
        WHERE M.ISAPPROVED=1 AND LASTLOGINDATE<SYSDATE
    ) UM WHERE UM.LN=1
) PLM
ON (PLM.LOWEREDEMAIL=LOWER(V.MAIL))
WHEN MATCHED THEN 
UPDATE SET V.ORA_ASPNET_USERID = PLM.USERID;

*/
commit；

INSERT INTO PEI_CUSTOM.XX_VENDOR_PERMISSIONS (ID,name,description,perm_levle) values('LOGON_FROM_INTERNET','Allow Supreme Account Logon From Internet','Allow Supreme Account Logon From Internet',0);
commit;


insert into PEI_CUSTOM.XX_VENDOR_SYNC_USERS (ACCOUNT, NAME, ENABLED, EMAIL, NOTIFICATION_ENABLED, LAST_NOTIFIED_TIME, LAST_ACTIVITY_TIME, INACTIVE_WINDOW_MINUTES, MACHINE_NAME, ORA_ASPNET_USERID)
values ('dmz1\ra_wellw1', 'wellwiseforautopush', 'T', 'peryshareacc@wellwise.com.hk', 'T', to_date('16-08-2017', 'dd-mm-yyyy'), to_date('16-10-2017', 'dd-mm-yyyy'), 60, 'FTPSERVER', null);

insert into PEI_CUSTOM.XX_VENDOR_SYNC_USERS (ACCOUNT, NAME, ENABLED, EMAIL, NOTIFICATION_ENABLED, LAST_NOTIFIED_TIME, LAST_ACTIVITY_TIME, INACTIVE_WINDOW_MINUTES, MACHINE_NAME, ORA_ASPNET_USERID)
values ('dmz1\ra_sarka1', 'ro_sarka1', 'T', 'ashiqul.sarker@pery.com', 'T', to_date('30-10-2017', 'dd-mm-yyyy'), to_date('30-10-2017', 'dd-mm-yyyy'), 60, 'PEDACFNP1', null);

insert into PEI_CUSTOM.XX_VENDOR_SYNC_USERS (ACCOUNT, NAME, ENABLED, EMAIL, NOTIFICATION_ENABLED, LAST_NOTIFIED_TIME, LAST_ACTIVITY_TIME, INACTIVE_WINDOW_MINUTES, MACHINE_NAME, ORA_ASPNET_USERID)
values ('dmz1\ra_revia1', 'resources_vietnam_coltd', 'T', 'thomast@sourcingbase.com', 'T', to_date('30-10-2017', 'dd-mm-yyyy'), to_date('30-10-2017', 'dd-mm-yyyy'), 60, 'TRENDMICRO', null);

insert into PEI_CUSTOM.XX_VENDOR_SYNC_USERS (ACCOUNT, NAME, ENABLED, EMAIL, NOTIFICATION_ENABLED, LAST_NOTIFIED_TIME, LAST_ACTIVITY_TIME, INACTIVE_WINDOW_MINUTES, MACHINE_NAME, ORA_ASPNET_USERID)
values ('dmz1\ra_bjnoa1', 'Beijing Office', 'T', 'arthur.fu@pery.com', 'T', to_date('30-10-2017', 'dd-mm-yyyy'), to_date('30-10-2017', 'dd-mm-yyyy'), 60, 'PEBJNFNP1', null);

insert into PEI_CUSTOM.XX_VENDOR_SYNC_USERS (ACCOUNT, NAME, ENABLED, EMAIL, NOTIFICATION_ENABLED, LAST_NOTIFIED_TIME, LAST_ACTIVITY_TIME, INACTIVE_WINDOW_MINUTES, MACHINE_NAME, ORA_ASPNET_USERID)
values ('dmz1\ra_jdlap1', 'j_d_light_usa', 'T', 'ademelo@ugmc.ae', 'T', to_date('29-10-2017', 'dd-mm-yyyy'), to_date('29-10-2017', 'dd-mm-yyyy'), 60, 'ARMINDO11', null);

insert into PEI_CUSTOM.XX_VENDOR_SYNC_USERS (ACCOUNT, NAME, ENABLED, EMAIL, NOTIFICATION_ENABLED, LAST_NOTIFIED_TIME, LAST_ACTIVITY_TIME, INACTIVE_WINDOW_MINUTES, MACHINE_NAME, ORA_ASPNET_USERID)
values ('dmz1\ra_speed1', 'Speed Sourcing', 'T', 'technical@pushang.com.hk', 'T', to_date('30-10-2017 06:47:11', 'dd-mm-yyyy hh24:mi:ss'), to_date('30-10-2017', 'dd-mm-yyyy'), 60, 'PMSHKS0008', null);

insert into PEI_CUSTOM.XX_VENDOR_SYNC_USERS (ACCOUNT, NAME, ENABLED, EMAIL, NOTIFICATION_ENABLED, LAST_NOTIFIED_TIME, LAST_ACTIVITY_TIME, INACTIVE_WINDOW_MINUTES, MACHINE_NAME, ORA_ASPNET_USERID)
values ('dmz1\ra_peida1', 'peidautopush', 'T', 'darmawan.prawita@pery.com', 'T', to_date('30-10-2017 06:47:11', 'dd-mm-yyyy hh24:mi:ss'), to_date('30-10-2017', 'dd-mm-yyyy'), 60, 'PECGKFNP1', null);

insert into PEI_CUSTOM.XX_VENDOR_SYNC_USERS (ACCOUNT, NAME, ENABLED, EMAIL, NOTIFICATION_ENABLED, LAST_NOTIFIED_TIME, LAST_ACTIVITY_TIME, INACTIVE_WINDOW_MINUTES, MACHINE_NAME, ORA_ASPNET_USERID)
values ('dmz1\ra_hkgoa1', 'PEI HK', 'T', 'allhkmis@pery.com', 'T', to_date('30-10-2017 06:47:11', 'dd-mm-yyyy hh24:mi:ss'), to_date('30-10-2017', 'dd-mm-yyyy'), 60, 'PEHKGFNP2', null);

insert into PEI_CUSTOM.XX_VENDOR_SYNC_USERS (ACCOUNT, NAME, ENABLED, EMAIL, NOTIFICATION_ENABLED, LAST_NOTIFIED_TIME, LAST_ACTIVITY_TIME, INACTIVE_WINDOW_MINUTES, MACHINE_NAME, ORA_ASPNET_USERID)
values ('dmz1\ra_shnoa1', 'Shang Hai Office', 'T', 'spark.yuan@pery.com', 'T', to_date('30-10-2017 06:47:11', 'dd-mm-yyyy hh24:mi:ss'), to_date('30-10-2017', 'dd-mm-yyyy'), 60, 'PESHNFNP1', null);

insert into PEI_CUSTOM.XX_VENDOR_SYNC_USERS (ACCOUNT, NAME, ENABLED, EMAIL, NOTIFICATION_ENABLED, LAST_NOTIFIED_TIME, LAST_ACTIVITY_TIME, INACTIVE_WINDOW_MINUTES, MACHINE_NAME, ORA_ASPNET_USERID)
values ('dmz1\ra_gzhoa1', 'Guangdong Office', 'T', 'arthur.fu@pery.com', 'T', to_date('30-10-2017 06:47:11', 'dd-mm-yyyy hh24:mi:ss'), to_date('30-10-2017', 'dd-mm-yyyy'), 60, 'PEGZHFNP2', null);

insert into PEI_CUSTOM.XX_VENDOR_SYNC_USERS (ACCOUNT, NAME, ENABLED, EMAIL, NOTIFICATION_ENABLED, LAST_NOTIFIED_TIME, LAST_ACTIVITY_TIME, INACTIVE_WINDOW_MINUTES, MACHINE_NAME, ORA_ASPNET_USERID)
values ('dmz1\ra_peivn1', 'Vietnam office', 'T', 'andy.vo@pery.com', 'T', to_date('30-10-2017 06:47:11', 'dd-mm-yyyy hh24:mi:ss'), to_date('30-10-2017', 'dd-mm-yyyy'), 60, 'PEHCMFNP1', null);

insert into PEI_CUSTOM.XX_VENDOR_SYNC_USERS (ACCOUNT, NAME, ENABLED, EMAIL, NOTIFICATION_ENABLED, LAST_NOTIFIED_TIME, LAST_ACTIVITY_TIME, INACTIVE_WINDOW_MINUTES, MACHINE_NAME, ORA_ASPNET_USERID)
values ('dmz1\ra_ptwoa1', 'Perry Ellis - Taiwan', 'T', 'li.bing@pery.com', 'T', to_date('30-10-2017 06:47:11', 'dd-mm-yyyy hh24:mi:ss'), to_date('30-10-2017', 'dd-mm-yyyy'), 60, 'PETAIFNP1', null);


commit;


GRANT SELECT, INSERT, UPDATE, DELETE ON PEI_CUSTOM.XX_VENDOR_FILE_1 TO PLM;
GRANT SELECT, INSERT, UPDATE, DELETE ON PEI_CUSTOM.XX_VENDOR_FILE_CATEGORY_1 TO PLM;
GRANT SELECT, INSERT, UPDATE, DELETE ON PEI_CUSTOM.XX_VENDOR_GROUPS_1 TO PLM;
GRANT SELECT, INSERT, UPDATE, DELETE ON PEI_CUSTOM.XX_VENDOR_GROUP_PERMISSION_1 TO PLM;
GRANT SELECT, INSERT, UPDATE, DELETE ON PEI_CUSTOM.XX_VENDOR_LOG_1 TO PLM;
GRANT SELECT, INSERT, UPDATE, DELETE ON PEI_CUSTOM.XX_VENDOR_MANNUL_1 TO PLM;
GRANT SELECT, INSERT, UPDATE, DELETE ON PEI_CUSTOM.XX_VENDOR_NEWS_1 TO PLM;
GRANT SELECT, INSERT, UPDATE, DELETE ON PEI_CUSTOM.XX_VENDOR_PERMISSIONS_1 TO PLM;
GRANT SELECT, INSERT, UPDATE, DELETE ON PEI_CUSTOM.XX_VENDOR_USERS_1 TO PLM;
GRANT SELECT, INSERT, UPDATE, DELETE ON PEI_CUSTOM.XX_VENDOR_USER_FILE_1 TO PLM;
GRANT SELECT, INSERT, UPDATE, DELETE ON PEI_CUSTOM.XX_VENDOR_USER_GROUP_1 TO PLM;
GRANT SELECT, INSERT, UPDATE, DELETE ON PEI_CUSTOM.XX_VENDOR_USER_PERMISSION_1 TO PLM;
commit;

