﻿using System;
using System.Collections.Generic;
using System.Linq;
using DAL;
using System.Data;

namespace BLL
{
    public partial class BLLService : BLLBase
    {
        /// <summary>
        /// Gets the synchronization user
        /// </summary>
        /// <returns></returns>
        public List<XX_VENDOR_SYNC_USERS> GetSyncUsers()
        {
            return DALService.GetSyncUsers();
        }

        /// <summary>
        /// By ActualName get the file 
        /// </summary>
        /// <param name="name">Actual_Name</param>
        /// <returns></returns>
        public List<XX_VENDOR_FILE> GetFileActualName(string name)
        {
            return DALService.GetFileActualName(name);
        }

        /// <summary>
        /// Get the latest 6 news by Subject Classification information
        /// </summary>
        /// <param name="subject">Subject</param>
        /// <returns></returns>
        public List<XX_VENDOR_NEWS> GetNewsBySubjectTop6(int subject)
        {
            return DALService.GetNewsBySubjectTop6(subject);
        }

        /// <summary>
        /// Access to news content
        /// </summary>
        /// <returns></returns>
        public List<XX_VENDOR_NEWS> GetNewsContent()
        {
            return DALService.GetNewsContent();
        }

        /// <summary>
        /// Through the ID for more information
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns></returns>
        public XX_VENDOR_NEWS GetNewsByID(int id)
        {
            return DALService.GetNewsByID(id);
        }

        /// <summary>
        /// Manual base node
        /// </summary>
        /// <param name="pid">base identity</param>
        /// <returns></returns>
        public IQueryable<XX_VENDOR_MANNUL> ManualParentNodes(int pid)
        {
            return DALService.ManualParentNodes(pid);
        }

        /// <summary>
        /// Via derived from base node ID node
        /// </summary>
        /// <param name="nodeValue">Node value</param>
        /// <returns></returns>
        public IQueryable<XX_VENDOR_MANNUL> GetChildNodesByPID(int nodeValue)
        {
            return DALService.GetChildNodesByPID(nodeValue);
        }

        /// <summary>
        /// Determines whether the current node contains child nodes
        /// </summary>
        /// <param name="currentNodeID">Identifies the current node</param>
        /// <returns></returns>
        public bool IsCurrentNodeContainSubNodes(int currentNodeID)
        {
            return DALService.IsCurrentNodeContainSubNodes(currentNodeID);
        }

        /// <summary>
        /// By ID Gets the child nodes of the current node Summary
        /// </summary>
        /// <param name="nodeValue">Node value</param>
        /// <returns></returns>
        public IQueryable<string> GetChildNodeSummaryByCurrentNodeID(int nodeValue)
        {
            return DALService.GetChildNodeSummaryByCurrentNodeID(nodeValue);
        }

        /// <summary>
        /// Get the latest news ID
        /// </summary>
        /// <returns></returns>
        public int GetLatestNewsID()
        {
            return DALService.GetLatestNewsID();
        }

        /// <summary>
        /// Add new news
        /// </summary>
        /// <param name="model">Entity</param>
        /// <returns></returns>
        public int InsertNews(XX_VENDOR_NEWS model)
        {
            return DALService.InsertNews(model);
        }

        /// <summary>
        /// News Update
        /// </summary>
        /// <param name="id">News ID</param>
        /// <param name="id">Entity</param>
        /// <returns></returns>
        public int UpdateNews(int id, XX_VENDOR_NEWS model)
        {
            return DALService.UpdateNews(id, model);
        }

        /// <summary>
        /// Get ToUser list for Dropdown
        /// </summary>
        /// <param name="connectString">connection string</param>
        /// <returns></returns>
        public List<UserItem> GetToUserList(string toUser)
        {
            return DALService.GetToUserList(toUser);
        }

        /// <summary>
        /// Through User ID Get User Entity Data
        /// </summary>
        /// <param name="connectionString">Connection String</param>
        /// <param name="id">User ID</param>
        /// <returns></returns>
        public UserItem GetUserItemByID(string id)
        {
            return DALService.GetUserItemByID(id);
        }

        /// <summary>
        /// Create File Information, Insert Data.
        /// </summary>
        /// <param name="fileModel">XX_Vendor_File Entity</param>
        /// <returns></returns>
        public bool CreateVendorFile(XX_VENDOR_FILE model)
        {
            return DALService.CreateVendorFile(model);
        }

        /// <summary>
        /// Create User File Information, Insert Data.
        /// </summary>
        /// <param name="model">XX_Vendor_User_File Entity</param>
        /// <returns></returns>
        public bool CreateVendorUserFile(XX_VENDOR_USER_FILE model)
        {
            return DALService.CreateVendorUserFile(model);
        }

        public string createFileItem(string from_userid, string to_userid, string file_name, string category)
        {
            return DALService.createFileItem(from_userid, to_userid, file_name, category);
        }

        public DataSet GetAlreadySendFilesData(string sql)
        {
            return DALService.GetAlreadySendFilesData(sql);
        }

        /// <summary>
        /// Multiple conditions get account information
        /// </summary>
        /// <param name="sql">select sentence</param>
        /// <returns></returns>
        public List<UserItem> GetAccountDataByMultipleConditions(string sql)
        {
            return DALService.GetAccountDataByMultipleConditions(sql);
        }

        // <summary>
        /// Get user detail information through user ID
        /// </summary>
        /// <param name="sql">sql sentence</param>
        /// <returns></returns>
        public UserItem GetUserDetailByID(string sql)
        {
            return DALService.GetUserDetailByID(sql);
        }

        /// <summary>
        /// Get user permissions according user identity
        /// </summary>
        /// <param name="categoryId">perm_levle</param>
        /// <returns></returns>
        public IQueryable<XX_VENDOR_PERMISSIONS> GetPermissionsByUserIdentity(int categoryId)
        {
            return DALService.GetPermissionsByUserIdentity(categoryId);
        }

        /// <summary>
        /// Get current user role
        /// </summary>
        /// <param name="userId">user id</param>
        /// <returns></returns>
        public string[] GetCurrentUserPermissions(string userId)
        {
            return DALService.GetCurrentUserPermissions(userId);
        }

        /// <summary>
        /// Set permission
        /// </summary>
        /// <param name="model">Entity</param>
        /// <returns></returns>
        public bool SetPermission(XX_VENDOR_USER_PERMISSION model)
        {
            return DALService.SetPermission(model);
        }

        /// <summary>
        /// Get current permission is select
        /// </summary>
        /// <param name="userId">user ID</param>
        /// <param name="permissionId">permission ID</param>
        /// <returns></returns>
        public bool GetIsCurrentPermissionSelected(string userId, string permissionId)
        {
            return DALService.GetIsCurrentPermissionSelected(userId, permissionId);
        }

        public bool RemovePermission(string userId, string permissionId)
        {
            return DALService.RemovePermission(userId, permissionId);
        }

        /// <summary>
        /// Update account data
        /// </summary>
        /// <param name="model">xx_vendor_users entity</param>
        /// <returns></returns>
        public bool UpdateAccountData(UserItem model)
        {
            return DALService.UpdateAccountData(model);
        }

        public bool CreateUserByExternal(UserItem model)
        {
            return DALService.CreateUserByExternal(model);
        }

        /// <summary>
        /// Determines whether the user already exists
        /// </summary>
        /// <param name="userName">User name</param>
        /// <returns></returns>
        public bool IsExistUserName(string userName)
        {
            return DALService.IsExistUserName(userName);
        }

        /// <summary>
        /// Gets the current user's permissions
        /// </summary>
        /// <param name="userId">User identity</param>
        /// <returns></returns>
        public List<string> GainCurrentUserPermissions(string userId)
        {
            return DALService.GainCurrentUserPermissions(userId);
        }

        /// <summary>
        /// Update the Manual title
        /// </summary>
        /// <param name="id">Identity</param>
        /// <param name="title">Title</param>
        /// <returns></returns>
        public bool UpdateManualTitle(int id, string title)
        {
            return DALService.UpdateManualTitle(id, title);
        }

        public bool IsRootNode(int id, int pid)
        {
            return DALService.IsRootNode(id, pid);
        }

        public bool IsHaveChildNode(int nodeId)
        {
            return DALService.IsHaveChildNode(nodeId);
        }

        public string GainNodeTitle(int manualId)
        {
            return DALService.GainNodeTitle(manualId);
        }

        public bool UpdateManualByID(int id, string title, string summary, string editor, string fileEXT, DateTime updateTime, string subNodeSEQ)
        {
            return DALService.UpdateManualByID(id, title, summary, editor, fileEXT, updateTime, subNodeSEQ);
        }

        public System.Data.DataSet GetFilesFromPartner(string current_user, string from_user)
        {
            return DALService.GetFilesFromPartner(current_user, from_user);
        }

        public XX_VENDOR_MANNUL GetManualEntityById(int id)
        {
            return DALService.GetManualEntityById(id);
        }

        public void Open()
        {
            DALService.Open();
        }

        public List<ManualByMail> GetRecentData()
        {
            return DALService.GetRecentData();
        }

        public ManualByMail GetSuperiorData(int pid)
        {
            return DALService.GetSuperiorData(pid);
        }

        public void Close()
        {
            DALService.Close();
        }

        public XX_VENDOR_MANNUL GetChildNodeMessageByCurrentNodeID(int nodeValue)
        {
            return DALService.GetChildNodeMessageByCurrentNodeID(nodeValue);
        }

        public void DeleteManualByID(int nodeID)
        {
            DALService.DeleteManualByID(nodeID);
        }

        public bool AddManual(XX_VENDOR_MANNUL model)
        {
            return DALService.AddManual(model);
        }

        public int? GetManualPIdById(int id)
        {
            return DALService.GetManualPIdById(id);
        }

        public string GetSubnodeseqById(int id)
        {
            return DALService.GetSubnodeseqById(id);
        }

        public int GetLatestMannulId()
        {
            return DALService.GetLatestMannulId();
        }

        public string GetSequenceById(int id)
        {
            return DALService.GetSequenceById(id);
        }

        public bool IsExistenceUser(string accountName)
        {
            return DALService.IsExistenceUser(accountName);
        }

        public bool IsExistenceEmail(string mail)
        {
            return DALService.IsExistenceEmail(mail);
        }

        public List<string> GetAllTitleInfoByCurrentPid(int pid)
        {
            return DALService.GetAllTitleInfoByCurrentPid(pid);
        }

        public bool CreateSyncUser(SyncUser model)
        {
            return DALService.CreateSyncUser(model);
        }

        public bool DeleteSyncUser(string account)
        {
            return DALService.DeleteSyncUser(account);
        }

        public bool IsExistSyncUser(string account)
        {
            return DALService.IsExistSyncUser(account);
        }

        public bool IsExistenceSyncFolder(string syncFolderName)
        {
            return DALService.IsExistenceSyncFolder(syncFolderName);
        }

        public bool UpdateSyncFolderName(string syncFolderName, string id)
        {
            return DALService.UpdateSyncFolderName(syncFolderName, id);
        }

        public UserItem GetUserInfoByEmail(string email)
        {
            return DALService.GetUserInfoByEmail(email);
        }

        public Asp_Users GetAspUserByUserID(string id)
        {
            return DALService.GetAspUserByUserID(id);
        }

        public bool UpdateUserFlagByID(string password, DateTime logonTime, string id)
        {
            return DALService.UpdateUserFlagByID(password, logonTime, id);
        }

        public UserItem GetLogonTimeByFlag(string flag)
        {
            return DALService.GetLogonTimeByFlag(flag);
        }

        public List<OAsp_Membership> GetUserIDsByEmail(string email)
        {
            return DALService.GetUserIDsByEmail(email);
        }

        public bool IsExistedUserByUserIDAndUsername(string userid, string username)
        {
            return DALService.IsExistedUserByUserIDAndUsername(userid, username);
        }

        public bool IsVendorSiteUser(string userid)
        {
            return DALService.IsVendorSiteUser(userid);
        }

        public bool UpdateUserFlagByUserID(string password, DateTime logonTime, string userid)
        {
            return DALService.UpdateUserFlagByUserID(password, logonTime, userid);
        }

        /// <summary>
        /// Get all vendors' mail
        /// </summary>
        /// <returns></returns>
        public List<string> GetAllMail()
        {
            return DALService.GetAllMail();
        }
        public string GetOperatingEnvironment()
        {
            return DALService.GetOperatingEnvironment();
        }
        public List<string> GetNameByUserId(string oraAspnetUserid)
        {
            return DALService.GetNameByUserId(oraAspnetUserid);
        }
        public string GetSyncUserName(string account)
        {
            return DALService.GetSyncUserName(account);
        }
    }
}
