﻿using System;

namespace BLL
{
    public class ServiceFactory
    {
        private static BLLService bllService;

        public static BLLService GetService()
        {
            if (bllService == null)
            {
                bllService = new BLLService();
            }
            return bllService;
        }
    }
}
