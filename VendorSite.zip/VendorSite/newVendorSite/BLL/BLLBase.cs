﻿using System;

namespace BLL
{
    public class BLLBase
    {
        protected DAL.IService DALService;
        public BLLBase()
        {
            DALService = DAL.DataAccess.GetService();
        }
    }
}
