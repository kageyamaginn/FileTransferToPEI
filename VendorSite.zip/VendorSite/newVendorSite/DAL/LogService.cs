﻿using System;
using log4net;

//[assembly: log4net.Config.XmlConfigurator(Watch = true)]
namespace DAL
{
    public class LogService
    {
        public static void WriteErrorLog(Type t, Exception ex)
        {
            ILog log = LogManager.GetLogger(t);
            log.Error("Error", ex);
        } 

        public static void WriteErrorLog(Type t, string msg)
        {
            ILog log = LogManager.GetLogger(t);
            log.Error(msg);
        }

        public static void WriteInfoLog(Type t, string msg)
        {
            ILog log = LogManager.GetLogger(t);
            log.Info(msg);
        }
    }
}
