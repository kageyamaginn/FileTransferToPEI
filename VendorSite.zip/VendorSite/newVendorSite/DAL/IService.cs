﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;

namespace DAL
{
    public interface IService
    {
        /// <summary>
        /// Gets the synchronization user
        /// </summary>
        /// <returns></returns>
        List<XX_VENDOR_SYNC_USERS> GetSyncUsers();

        /// <summary>
        /// By ActualName get the file
        /// </summary>
        /// <param name="name">Actual_Name</param>
        /// <returns></returns>
        List<XX_VENDOR_FILE> GetFileActualName(string name);

        /// <summary>
        /// Get the latest 6 news by Subject Classification information
        /// </summary>
        /// <param name="subject">Subject</param>
        /// <returns></returns>
        List<XX_VENDOR_NEWS> GetNewsBySubjectTop6(int subject);

        /// <summary>
        /// Access to news content
        /// </summary>
        /// <returns></returns>
        List<XX_VENDOR_NEWS> GetNewsContent();

        /// <summary>
        /// Through the ID for more information
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns></returns>
        XX_VENDOR_NEWS GetNewsByID(int id);

        /// <summary>
        /// Manual base node
        /// </summary>
        /// <param name="pid">base identity</param>
        /// <returns></returns>
        IQueryable<XX_VENDOR_MANNUL> ManualParentNodes(int pid);

        /// <summary>
        /// Via derived from base node ID node
        /// </summary>
        /// <param name="nodeValue">Node value</param>
        /// <returns></returns>
        IQueryable<XX_VENDOR_MANNUL> GetChildNodesByPID(int nodeValue);

        /// <summary>
        /// Determines whether the current node contains child nodes
        /// </summary>
        /// <param name="currentNodeID">Identifies the current node</param>
        /// <returns></returns>
        bool IsCurrentNodeContainSubNodes(int currentNodeID);

        /// <summary>
        /// By ID Gets the child nodes of the current node Summary
        /// </summary>
        /// <param name="nodeValue">Node value</param>
        /// <returns></returns>
        IQueryable<string> GetChildNodeSummaryByCurrentNodeID(int nodeValue);

        XX_VENDOR_MANNUL GetChildNodeMessageByCurrentNodeID(int nodeValue);

        /// <summary>
        /// Get the latest news ID
        /// </summary>
        /// <returns></returns>
        int GetLatestNewsID();

        /// <summary>
        /// Add new news
        /// </summary>
        /// <param name="model">Entity</param>
        /// <returns></returns>
        int InsertNews(XX_VENDOR_NEWS model);

        /// <summary>
        /// News Update
        /// </summary>
        /// <param name="id">News ID</param>
        /// <param name="id">Entity</param>
        /// <returns></returns>
        int UpdateNews(int id, XX_VENDOR_NEWS model);

        /// <summary>
        /// Get ToUser list for Dropdown
        /// </summary>
        /// <param name="connectString">connection string</param>
        /// <returns></returns>
        List<UserItem> GetToUserList(string toUser);

        /// <summary>
        /// Through User ID Get User Entity Data
        /// </summary>
        /// <param name="connectionString">Connection String</param>
        /// <param name="id">User ID</param>
        /// <returns></returns>
        UserItem GetUserItemByID(string id);

        /// <summary>
        /// Create File Information, Insert Data.
        /// </summary>
        /// <param name="fileModel">XX_Vendor_File Entity</param>
        /// <returns></returns>
        bool CreateVendorFile(XX_VENDOR_FILE model);

        /// <summary>
        /// Create User File Information, Insert Data.
        /// </summary>
        /// <param name="model">XX_Vendor_User_File Entity</param>
        /// <returns></returns>
        bool CreateVendorUserFile(XX_VENDOR_USER_FILE model);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="from_userid"></param>
        /// <param name="to_userid"></param>
        /// <param name="file_name"></param>
        /// <param name="category"></param>
        /// <returns></returns>
        string createFileItem(string from_userid, string to_userid, string file_name, string category);

        /// <summary>
        /// Gather send partner Data
        /// </summary>
        /// <param name="sql">select statement</param>
        /// <returns></returns>
        DataSet GetAlreadySendFilesData(string sql);

        /// <summary>
        /// Multiple conditions get account information
        /// </summary>
        /// <param name="sql">select sentence</param>
        /// <returns></returns>
        List<UserItem> GetAccountDataByMultipleConditions(string sql);

        /// <summary>
        /// Get user detail information through user ID
        /// </summary>
        /// <param name="sql">sql sentence</param>
        /// <returns></returns>
        UserItem GetUserDetailByID(string sql);

        /// <summary>
        /// Get user permissions according user identity
        /// </summary>
        /// <param name="categoryId">perm_levle</param>
        /// <returns></returns>
        IQueryable<XX_VENDOR_PERMISSIONS> GetPermissionsByUserIdentity(int categoryId);

        /// <summary>
        /// Get current user role
        /// </summary>
        /// <param name="userId">user id</param>
        /// <returns></returns>
        string[] GetCurrentUserPermissions(string userId);

        /// <summary>
        /// Set permission
        /// </summary>
        /// <param name="model">Entity</param>
        /// <returns></returns>
        bool SetPermission(XX_VENDOR_USER_PERMISSION model);

        /// <summary>
        /// Get current permission is select
        /// </summary>
        /// <param name="userId">user ID</param>
        /// <param name="permissionId">permission ID</param>
        /// <returns></returns>
        bool GetIsCurrentPermissionSelected(string userId, string permissionId);

        /// <summary>
        /// Remove user permission
        /// </summary>
        /// <param name="userId">User ID</param>
        /// <returns></returns>
        bool RemovePermission(string userId, string permissionId);

        /// <summary>
        /// Update account data
        /// </summary>
        /// <param name="model">xx_vendor_users entity</param>
        /// <returns></returns>
        bool UpdateAccountData(UserItem model);

        /// <summary>
        /// Create external user
        /// </summary>
        /// <param name="model">xx_vendor_users entity</param>
        /// <returns></returns>
        bool CreateUserByExternal(UserItem model);

        /// <summary>
        /// Determines whether the user already exists
        /// </summary>
        /// <param name="userName">User name</param>
        /// <returns></returns>
        bool IsExistUserName(string userName);

        /// <summary>
        /// Gets the current user's permissions
        /// </summary>
        /// <param name="userId">User identity</param>
        /// <returns></returns>
        List<string> GainCurrentUserPermissions(string userId);

        /// <summary>
        /// Update the Manual title
        /// </summary>
        /// <param name="id">Identity</param>
        /// <param name="title">Title</param>
        /// <returns></returns>
        bool UpdateManualTitle(int id, string title);

        bool IsRootNode(int id, int pid);

        bool IsHaveChildNode(int nodeId);

        string GainNodeTitle(int manualId);

        bool UpdateManualByID(int id, string title, string summary, string editor, string fileEXT, DateTime updateTime, string subNodeSEQ);

        DataSet GetFilesFromPartner(string current_user, string from_user);

        XX_VENDOR_MANNUL GetManualEntityById(int id);

        void Open();

        List<ManualByMail> GetRecentData();

        ManualByMail GetSuperiorData(int pid);

        void Close();

        void DeleteManualByID(int nodeID);

        bool AddManual(XX_VENDOR_MANNUL model);

        int? GetManualPIdById(int id);

        string GetSubnodeseqById(int id);

        int GetLatestMannulId();

        string GetSequenceById(int id);

        bool IsExistenceUser(string accountName);

        bool IsExistenceEmail(string mail);

        List<string> GetAllTitleInfoByCurrentPid(int pid);

        bool CreateSyncUser(SyncUser model);

        bool DeleteSyncUser(string account);

        bool IsExistSyncUser(string account);

        bool IsExistenceSyncFolder(string syncFolderName);

        bool UpdateSyncFolderName(string syncFolderName, string id);

        UserItem GetUserInfoByEmail(string email);

        Asp_Users GetAspUserByUserID(string id);

        bool UpdateUserFlagByID(string password, DateTime logonTime, string id);

        UserItem GetLogonTimeByFlag(string flag);

        List<OAsp_Membership> GetUserIDsByEmail(string email);

        bool IsExistedUserByUserIDAndUsername(string userid, string username);

        bool IsVendorSiteUser(string userid);

        bool UpdateUserFlagByUserID(string password, DateTime logonTime, string userid);


        /// <summary>
        /// Get all vendors' mail
        /// </summary>
        /// <returns></returns>
        List<string> GetAllMail();

        string GetOperatingEnvironment();
        List<string> GetNameByUserId(string oraAspnetUserid);
        string GetSyncUserName(string account);
    }
}
