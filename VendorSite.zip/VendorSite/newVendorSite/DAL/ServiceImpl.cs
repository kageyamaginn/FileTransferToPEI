﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using Oracle.ManagedDataAccess.Client;
using System.Text;
using System.Data.Entity.Core.EntityClient;

namespace DAL
{
    public class ServiceImpl : IService
    {
        private static string conn;
        private static string pConn;
        private static string vConn;
        private OracleConnection oraConn;

        public ServiceImpl()
        {
            DBConnection DB = new DBConnection(DBConnection.Database.WEBPDM, DBConnection.DBDriverTypes.ODPNET);
            conn = DB.ConnectionString;
            vConn = conn;
            pConn = conn;
        }
        #region Entity Framework
        /// <summary>
        /// Gets the synchronization user
        /// </summary>
        /// <returns></returns>
        public List<XX_VENDOR_SYNC_USERS> GetSyncUsers()
        {
            try
            {
                var db = GetDataContext();
                var query = from q in db.XX_VENDOR_SYNC_USERS
                            select q;
                return query.ToList();
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
        }

        /// <summary>
        /// By ActualName get the file
        /// </summary>
        /// <param name="name">Actual_Name</param>
        /// <returns></returns>
        public List<XX_VENDOR_FILE> GetFileActualName(string name)
        {
            try
            {
                var db = GetDataContext();
                var query = from q in db.XX_VENDOR_FILE
                            where q.ACTUAL_NAME.Equals(name, StringComparison.InvariantCultureIgnoreCase)
                            select q;
                return query.ToList();
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
        }

        /// <summary>
        /// Get the latest 6 news by Subject Classification information
        /// </summary>
        /// <param name="subject">Subject</param>
        /// <returns></returns>
        public List<XX_VENDOR_NEWS> GetNewsBySubjectTop6(int subject)
        {
            try
            {
                var db = GetDataContext();
                var query = (from q in db.XX_VENDOR_NEWS
                             where q.SUBJECT == subject && q.SCONTENT != null && q.STATUS.Equals("0")
                             orderby q.UPDATETIME descending
                             select q).Take(6);
                return query.ToList();
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
        }

        /// <summary>
        /// Access to news content
        /// </summary>
        /// <returns></returns>
        public List<XX_VENDOR_NEWS> GetNewsContent()
        {
            try
            {
                var db = GetDataContext();
                var query = from q in db.XX_VENDOR_NEWS
                            select q;
                return query.ToList();
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
        }

        /// <summary>
        /// Through the ID for more information
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns></returns>
        public XX_VENDOR_NEWS GetNewsByID(int id)
        {
            try
            {
                var db = GetDataContext();
                return db.XX_VENDOR_NEWS.FirstOrDefault(e => e.ID == id && e.SCONTENT != null);
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
        }

        /// <summary>
        /// Manual base node
        /// </summary>
        /// <param name="pid">base identity</param>
        /// <returns></returns>
        public IQueryable<XX_VENDOR_MANNUL> ManualParentNodes(int pid)
        {
            try
            {
                var db = GetDataContext();
                return db.XX_VENDOR_MANNUL.Where(m => m.PID == pid).Select(m => m).OrderBy(m => m.TITLE);
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
        }

        /// <summary>
        /// Via derived from base node ID node
        /// </summary>
        /// <param name="nodeValue">Node value</param>
        /// <returns></returns>
        public IQueryable<XX_VENDOR_MANNUL> GetChildNodesByPID(int nodeValue)
        {
            try
            {
                var db = GetDataContext();
                return db.XX_VENDOR_MANNUL.Where(m => m.PID == nodeValue).OrderBy(m => m.TITLE);
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
        }

        /// <summary>
        /// Determines whether the current node contains child nodes
        /// </summary>
        /// <param name="currentNodeID">Identifies the current node</param>
        /// <returns></returns>
        public bool IsCurrentNodeContainSubNodes(int currentNodeID)
        {
            try
            {
                var db = GetDataContext();
                return db.XX_VENDOR_MANNUL.Any(m => m.PID == currentNodeID);
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
        }

        /// <summary>
        /// By ID Gets the child nodes of the current node Summary
        /// </summary>
        /// <param name="nodeValue">Node value</param>
        /// <returns></returns>
        public IQueryable<string> GetChildNodeSummaryByCurrentNodeID(int nodeValue)
        {
            try
            {
                var db = GetDataContext();
                return db.XX_VENDOR_MANNUL.Where(m => m.ID == nodeValue).Select(m => m.SUMMARY);
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
        }

        public XX_VENDOR_MANNUL GetChildNodeMessageByCurrentNodeID(int nodeValue)
        {
            try
            {
                var db = GetDataContext();
                return db.XX_VENDOR_MANNUL.FirstOrDefault(m => m.ID == nodeValue);
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
        }

        /// <summary>
        /// Get the latest news ID
        /// </summary>
        /// <returns></returns>
        public int GetLatestNewsID()
        {
            try
            {
                var db = GetDataContext();
                return db.XX_VENDOR_NEWS.Max(n => n.ID) + 1;
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
        }

        /// <summary>
        /// Add new news
        /// </summary>
        /// <param name="model">Entity</param>
        /// <returns></returns>
        public int InsertNews(XX_VENDOR_NEWS model)
        {
            try
            {
                var db = GetDataContext();
                db.Entry(model).State = EntityState.Added;
                return db.SaveChanges();
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
        }

        /// <summary>
        /// News Update
        /// </summary>
        /// <param name="id">News ID</param>
        /// <param name="id">Entity</param>
        /// <returns></returns>
        public int UpdateNews(int id, XX_VENDOR_NEWS model)
        {
            int row = 0;
            try
            {
                var db = GetDataContext();
                var entity = db.XX_VENDOR_NEWS.FirstOrDefault(n => n.ID == id);
                if (entity != null)
                {
                    entity.ID = model.ID;
                    entity.TITLE = model.TITLE;
                    entity.REDIRECTURL = model.REDIRECTURL;
                    entity.NORDER = model.NORDER;
                    entity.UPDATETIME = model.UPDATETIME;
                    entity.STATUS = model.STATUS;
                    entity.EDITOR = model.EDITOR;
                    entity.SUBJECT = model.SUBJECT;
                    entity.SCONTENT = model.SCONTENT;
                    row = db.SaveChanges();
                }
                return row;
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
        }
        /// <summary>
        /// Create File Information, Insert Data.
        /// </summary>
        /// <param name="fileModel">XX_Vendor_File Entity</param>
        /// <returns></returns>
        public bool CreateVendorFile(XX_VENDOR_FILE model)
        {
            try
            {
                var db = GetDataContext();
                db.Entry(model).State = EntityState.Added;
                var isSuccessed = db.SaveChanges() > 0;
                return isSuccessed;
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
        }

        /// <summary>
        /// Create User File Information, Insert Data.
        /// </summary>
        /// <param name="model">XX_Vendor_User_File Entity</param>
        /// <returns></returns>
        public bool CreateVendorUserFile(XX_VENDOR_USER_FILE model)
        {
            try
            {
                var db = GetDataContext();
                db.Entry(model).State = EntityState.Added;
                var isSuccessed = db.SaveChanges() > 0;
                return isSuccessed;
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
        }
        /// <summary>
        /// Get user permissions according user identity
        /// </summary>
        /// <param name="categoryId">perm_levle</param>
        /// <returns></returns>
        public IQueryable<XX_VENDOR_PERMISSIONS> GetPermissionsByUserIdentity(int categoryId)
        {
            IQueryable<XX_VENDOR_PERMISSIONS> query;
            try
            {
                var db = GetDataContext();
                query = db.XX_VENDOR_PERMISSIONS.Where(p => p.PERM_LEVLE == categoryId).Select(p => p);
                return query;
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
        }

        /// <summary>
        /// Get current user role
        /// </summary>
        /// <param name="userId">user id</param>
        /// <returns></returns>
        public string[] GetCurrentUserPermissions(string userId)
        {
            try
            {
                var db = GetDataContext();
                return db.XX_VENDOR_USER_PERMISSION.Where(p => p.USER_ID.Equals(userId, StringComparison.InvariantCultureIgnoreCase)).Select(p => p.PERMISSION_ID).ToArray();
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
        }

        /// <summary>
        /// Set permission
        /// </summary>
        /// <param name="model">Entity</param>
        /// <returns></returns>
        public bool SetPermission(XX_VENDOR_USER_PERMISSION model)
        {
            try
            {
                var db = GetDataContext();
                db.Entry(model).State = EntityState.Added;
                return db.SaveChanges() > 0;
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
        }

        /// <summary>
        /// Get current permission is select
        /// </summary>
        /// <param name="userId">user ID</param>
        /// <param name="permissionId">permission ID</param>
        /// <returns></returns>
        public bool GetIsCurrentPermissionSelected(string userId, string permissionId)
        {
            try
            {
                var db = GetDataContext();
                return db.XX_VENDOR_USER_PERMISSION.Any(p => p.USER_ID.Equals(userId, StringComparison.InvariantCultureIgnoreCase)
                                                        && p.PERMISSION_ID.Equals(permissionId, StringComparison.InvariantCultureIgnoreCase));
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
        }

        public bool RemovePermission(string userId, string permissionId)
        {
            try
            {
                var db = GetDataContext();
                var model = db.XX_VENDOR_USER_PERMISSION.FirstOrDefault(p => p.USER_ID.Equals(userId, StringComparison.InvariantCultureIgnoreCase) &&
                                                                        p.PERMISSION_ID.Equals(permissionId, StringComparison.InvariantCultureIgnoreCase));
                if (model != null)
                {
                    db.Entry(model).State = EntityState.Deleted;
                    return db.SaveChanges() > 0;
                }
                return false;
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
        }

        /// <summary>
        /// Gets the current user's permissions
        /// </summary>
        /// <param name="userId">User identity</param>
        /// <returns></returns>
        public List<string> GainCurrentUserPermissions(string userId)
        {
            try
            {
                var db = GetDataContext();
                return db.XX_VENDOR_USER_PERMISSION.Where(p => p.USER_ID.ToLower() == userId.ToLower()).Select(p => p.PERMISSION_ID).ToList();
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
        }

        /// <summary>
        /// Update the Manual title
        /// </summary>
        /// <param name="id">Identity</param>
        /// <param name="title">Title</param>
        /// <returns></returns>
        public bool UpdateManualTitle(int id, string title)
        {
            try
            {
                var db = GetDataContext();
                var model = db.XX_VENDOR_MANNUL.FirstOrDefault(m => m.ID == id);
                if (model != null)
                {
                    model.TITLE = title;
                    model.UPDATETIME = DateTime.Now;
                    return db.SaveChanges() > 0;
                }
                return false;
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
        }

        public bool IsRootNode(int id, int pid)
        {
            try
            {
                var db = GetDataContext();
                var model = db.XX_VENDOR_MANNUL.FirstOrDefault(m => m.ID == id);
                if (model != null)
                {
                    if (model.PID != null) return model.PID == pid;
                }
                return false;
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
        }

        public bool IsHaveChildNode(int nodeId)
        {
            try
            {
                var db = GetDataContext();
                var list = db.XX_VENDOR_MANNUL.Where(m => m.PID == nodeId).ToList();
                if (list.Count > 0) return true;
                return false;
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
        }

        public string GainNodeTitle(int manualId)
        {
            try
            {
                var db = GetDataContext();
                var model = db.XX_VENDOR_MANNUL.FirstOrDefault(m => m.ID == manualId);
                if (model != null)
                {
                    return model.TITLE;
                }
                return String.Empty;
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
        }

        public bool UpdateManualByID(int id, string title, string summary, string editor, string fileEXT, DateTime updateTime, string subNodeSEQ)
        {
            try
            {
                var db = GetDataContext();
                var model = db.XX_VENDOR_MANNUL.FirstOrDefault(m => m.ID == id);
                if (model != null)
                {
                    model.TITLE = title;
                    model.SUMMARY = summary;
                    model.EDITOR = editor;
                    model.FILEEXT = fileEXT;
                    model.UPDATETIME = updateTime;
                    model.SUBNODESEQ = subNodeSEQ;
                    return db.SaveChanges() > 0;
                }
                return false;
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
        }
        public XX_VENDOR_MANNUL GetManualEntityById(int id)
        {
            try
            {
                var db = GetDataContext();
                return db.XX_VENDOR_MANNUL.FirstOrDefault(m => m.ID == id);
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
        }
        public void DeleteManualByID(int nodeID)
        {
            try
            {
                var db = GetDataContext();
                var model = db.XX_VENDOR_MANNUL.FirstOrDefault(m => m.ID == nodeID);
                if (model != null)
                {
                    db.Entry(model).State = EntityState.Deleted;
                    db.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
        }

        public bool AddManual(XX_VENDOR_MANNUL model)
        {
            try
            {
                var db = GetDataContext();
                db.Entry(model).State = EntityState.Added;
                return db.SaveChanges() > 0;
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
        }

        public int GetLatestMannulId()
        {
            try
            {
                var db = GetDataContext();
                return db.XX_VENDOR_MANNUL.Max(m => m.ID) + 1;
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
        }

        public string GetSequenceById(int id)
        {
            try
            {
                var db = GetDataContext();
                return db.XX_VENDOR_MANNUL.Where(m => m.ID == id).Select(m => m.SEQUENCE).ToArray()[0];
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
        }

        public int? GetManualPIdById(int id)
        {
            try
            {
                var db = GetDataContext();
                return db.XX_VENDOR_MANNUL.Where(m => m.ID == id).Select(m => m.PID).ToArray()[0];
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
        }

        public string GetSubnodeseqById(int id)
        {
            try
            {
                var db = GetDataContext();
                return db.XX_VENDOR_MANNUL.Where(m => m.ID == id).Select(m => m.SUBNODESEQ).ToArray()[0];
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
        }

        public List<string> GetAllTitleInfoByCurrentPid(int pid)
        {
            try
            {
                var db = GetDataContext();
                return db.XX_VENDOR_MANNUL.Where(m => m.PID == pid).Select(m => m.TITLE).ToList();
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
        }

        #endregion

        #region ODPNET
        public List<string> GetNameByUserId(string oraAspnetUserid)
        {
            OracleCommand cmd = null;
            OracleDataReader dr = null;
            var oraConn = new OracleConnection(conn);
            try
            {
                oraConn.Open();
                string sql = "select * from PEI_CUSTOM.XX_VENDOR_USERS  x where x.ORA_ASPNET_USERID=:userid and (x.ISACTIVE is null or x.ISACTIVE =1)";
                cmd = new OracleCommand(sql, oraConn);
                cmd.Parameters.Add("userid", OracleDbType.Varchar2, 255).Value = oraAspnetUserid;
                dr = cmd.ExecuteReader();
                List<string> userList = new List<string>();
                if (dr != null && dr.HasRows)
                {
                    while (dr.Read())
                    {
                        userList.Add(dr.GetString(0));
                    }
                }
                return userList;
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
            finally
            {
                cmd.Dispose();
                oraConn.Close();
                oraConn.Dispose();
            }
        }
        public string GetOperatingEnvironment()
        {
            //OracleCommand cmd = null;
            //OracleDataReader dr = null;
            var oraConn = new OracleConnection(conn);
            try
            {
                oraConn.Open();
                if (oraConn.DataSource.ToUpper() == "WWW1")
                {
                    return "PRODUCTION";
                }
                return "TEST";
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
            finally
            {
                //cmd.Dispose();
                oraConn.Close();
                oraConn.Dispose();
            }
        }

        /// <summary>
        /// Get all vendors' mail
        /// </summary>
        /// <returns></returns>
        public List<string> GetAllMail()
        {
            OracleCommand cmd = null;
            OracleDataReader dr = null;
            var oraConn = new OracleConnection(conn);
            try
            {
                oraConn.Open();
                var sql = "select mail from pei_custom.xx_vendor_users where  mail is not null and (IsActive =1 or IsActive is null) and domain_name ='DMZ1'";
                cmd = new OracleCommand(sql, oraConn);
                dr = cmd.ExecuteReader();
                List<string> mailList = new List<string>();
                if (dr != null && dr.HasRows)
                {
                    while (dr.Read())
                    {
                        mailList.Add(dr.GetString(0));
                    }
                }
                return mailList;
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
            finally
            {
                cmd.Dispose();
                oraConn.Close();
                oraConn.Dispose();
            }
        }

        public UserItem GetUserInfoByEmail(string email)
        {
            OracleCommand cmd = null;
            OracleDataReader dr = null;
            UserItem model = null;
            var oraConn = new OracleConnection(conn);
            try
            {
                oraConn.Open();
                var sql = "select * from pei_custom.xx_vendor_users where lower(MAIL)=lower(:MAIL)";
                cmd = new OracleCommand(sql, oraConn);
                cmd.Parameters.Add("MAIL", OracleDbType.Varchar2, 255).Value = email;
                dr = cmd.ExecuteReader();
                if (dr != null && dr.HasRows)
                {
                    model = new UserItem();
                    while (dr.Read())
                    {
                        model.ID = dr.GetString(0);
                        model.SaMacCountName = dr.GetString(1);
                        model.ObjectCategory = dr["ObjectCategory"] != null && dr["ObjectCategory"] != DBNull.Value ? (string)dr["ObjectCategory"] : "";
                        model.Mail = dr["Mail"] != null && dr["Mail"] != DBNull.Value ? (string)dr["Mail"] : "";
                        model.Name = dr.GetString(4);
                        model.Department = dr["Department"] != null && dr["Department"] != DBNull.Value ? (string)dr["Department"] : "";
                        model.DistinguishedName = dr["DistinguishedName"] != null && dr["DistinguishedName"] != DBNull.Value ? (string)dr["DistinguishedName"] : "";
                        model.ObjectClass = dr["ObjectClass"] != null && dr["ObjectClass"] != DBNull.Value ? (string)dr["ObjectClass"] : "";
                        model.UserPrincipalName = dr["UserPrincipalName"] != null && dr["UserPrincipalName"] != DBNull.Value ? (string)dr["UserPrincipalName"] : "";
                        model.Upload_Folder = dr.GetString(9);
                        model.Domain_Name = dr.GetString(10);
                        model.Title = dr.GetString(11);
                        model.Company = dr["Company"] != null && dr["Company"] != DBNull.Value ? (string)dr["Company"] : "";
                        model.SN = dr["SN"] != null && dr["SN"] != DBNull.Value ? (string)dr["SN"] : "";
                        model.Telephone_Number = dr["Telephone_Number"] != null && dr["Telephone_Number"] != DBNull.Value ? (string)dr["Telephone_Number"] : "";
                        model.Postal_Code = dr["Postal_Code"] != null && dr["Postal_Code"] != DBNull.Value ? (string)dr["Postal_Code"] : "";
                        model.Given_Name = dr["Given_Name"] != null && dr["Given_Name"] != DBNull.Value ? (string)dr["Given_Name"] : "";
                        model.Country = dr["Country"] != null && dr["Country"] != DBNull.Value ? (string)dr["Country"] : "";
                        model.City = dr["City"] != null && dr["City"] != DBNull.Value ? (string)dr["City"] : "";
                        model.Street_Address = dr["Street_Address"] != null && dr["Street_Address"] != DBNull.Value ? (string)dr["Street_Address"] : "";
                        model.State = dr["State"] != null && dr["State"] != DBNull.Value ? (string)dr["State"] : "";
                        model.Password = dr["Password"] != null && dr["Password"] != DBNull.Value ? (string)dr["Password"] : "";
                        model.WebPDMGroups = dr["WebPDMGroups"] != null && dr["WebPDMGroups"] != DBNull.Value ? (string)dr["WebPDMGroups"] : "";
                        model.First_Name = dr["First_Name"] != null && dr["First_Name"] != DBNull.Value ? (string)dr["First_Name"] : "";
                        model.Last_Name = dr["Last_Name"] != null && dr["Last_Name"] != DBNull.Value ? (string)dr["Last_Name"] : "";
                        model.Direct_Phone = dr["Direct_Phone"] != null && dr["Direct_Phone"] != DBNull.Value ? (string)dr["Direct_Phone"] : "";
                        model.Fax_Number = dr["Fax_Number"] != null && dr["Fax_Number"] != DBNull.Value ? (string)dr["Fax_Number"] : "";
                        model.Relation_To_Company = dr["Relation_To_Company"] != null && dr["Relation_To_Company"] != DBNull.Value ? (string)dr["Relation_To_Company"] : "";
                        model.Reason_For_Account = dr["Reason_For_Account"] != null && dr["Reason_For_Account"] != DBNull.Value ? (string)dr["Reason_For_Account"] : "";
                        model.Print_Name = dr["Print_Name"] != null && dr["Print_Name"] != DBNull.Value ? (string)dr["Print_Name"] : "";
                        model.Intra_Print_Name = dr["Intra_Print_Name"] != null && dr["Intra_Print_Name"] != DBNull.Value ? (string)dr["Intra_Print_Name"] : "";
                        model.ORA_ASPNET_USERID = dr["ORA_ASPNET_USERID"] != null && dr["ORA_ASPNET_USERID"] != DBNull.Value ? (byte[])dr["ORA_ASPNET_USERID"] : null;
                    }
                }
                return model;
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
            finally
            {
                cmd.Dispose();
                oraConn.Close();
                oraConn.Dispose();
            }
        }

        public Asp_Users GetAspUserByUserID(string id)
        {
            OracleCommand cmd = null;
            OracleDataReader dr = null;
            Asp_Users model = null;
            var oraConn = new OracleConnection(pConn);
            try
            {
                oraConn.Open();
                var sql = "select * from plm.ora_aspnet_users where userid=:userid";
                cmd = new OracleCommand(sql, oraConn);
                cmd.Parameters.Add("userid", OracleDbType.Varchar2, 255).Value = id;
                dr = cmd.ExecuteReader();
                if (dr != null && dr.HasRows)
                {
                    model = new Asp_Users();
                    while (dr.Read())
                    {
                        //model.APPLICATIONID = dr["APPLICATIONID"] != null && dr["APPLICATIONID"] != DBNull.Value ? new Guid(dr["APPLICATIONID"].ToString()) : Guid.Empty; // dr.GetGuid(0);
                        //model.USERID = dr["USERID"] != null && dr["USERID"] != DBNull.Value ? new Guid(dr["USERID"].ToString()) : Guid.Empty;
                        model.USERNAME = dr["USERNAME"] != null && dr["USERNAME"] != DBNull.Value ? (string)dr["USERNAME"] : "";
                        //model.LOWEREDUSERNAME = dr["LOWEREDUSERNAME"] != null && dr["LOWEREDUSERNAME"] != DBNull.Value ? (string)dr["LOWEREDUSERNAME"] : "";
                        //model.MOBILEALIAS = dr["MOBILEALIAS"] != null && dr["MOBILEALIAS"] != DBNull.Value ? (string)dr["MOBILEALIAS"] : "";
                        //model.ISANONYMOUS = dr["ISANONYMOUS"] != null && dr["ISANONYMOUS"] != DBNull.Value ? (int)dr["ISANONYMOUS"] : 0;
                        //model.LASTACTIVITYDATE = dr["LASTACTIVITYDATE"] != null && dr["LASTACTIVITYDATE"] != DBNull.Value ? (DateTime)dr["LASTACTIVITYDATE"] : DateTime.MinValue;
                        //model.ObjectClass = dr["ObjectClass"] != null && dr["ObjectClass"] != DBNull.Value ? (string)dr["ObjectClass"] : "";
                        //model.UserPrincipalName = dr["UserPrincipalName"] != null && dr["UserPrincipalName"] != DBNull.Value ? (string)dr["UserPrincipalName"] : "";
                        //model.Upload_Folder = dr.GetString(9);
                        //model.Domain_Name = dr.GetString(10);
                        //model.Title = dr.GetString(11);
                        //model.Company = dr["Company"] != null && dr["Company"] != DBNull.Value ? (string)dr["Company"] : "";
                        //model.SN = dr["SN"] != null && dr["SN"] != DBNull.Value ? (string)dr["SN"] : "";
                        //model.Telephone_Number = dr["Telephone_Number"] != null && dr["Telephone_Number"] != DBNull.Value ? (string)dr["Telephone_Number"] : "";
                        //model.Postal_Code = dr["Postal_Code"] != null && dr["Postal_Code"] != DBNull.Value ? (string)dr["Postal_Code"] : "";
                        //model.Given_Name = dr["Given_Name"] != null && dr["Given_Name"] != DBNull.Value ? (string)dr["Given_Name"] : "";
                        //model.Country = dr["Country"] != null && dr["Country"] != DBNull.Value ? (string)dr["Country"] : "";
                        //model.City = dr["City"] != null && dr["City"] != DBNull.Value ? (string)dr["City"] : "";
                        //model.Street_Address = dr["Street_Address"] != null && dr["Street_Address"] != DBNull.Value ? (string)dr["Street_Address"] : "";
                        //model.State = dr["State"] != null && dr["State"] != DBNull.Value ? (string)dr["State"] : "";
                        //model.Password = dr["Password"] != null && dr["Password"] != DBNull.Value ? (string)dr["Password"] : "";
                        //model.WebPDMGroups = dr["WebPDMGroups"] != null && dr["WebPDMGroups"] != DBNull.Value ? (string)dr["WebPDMGroups"] : "";
                        //model.First_Name = dr["First_Name"] != null && dr["First_Name"] != DBNull.Value ? (string)dr["First_Name"] : "";
                        //model.Last_Name = dr["Last_Name"] != null && dr["Last_Name"] != DBNull.Value ? (string)dr["Last_Name"] : "";
                        //model.Direct_Phone = dr["Direct_Phone"] != null && dr["Direct_Phone"] != DBNull.Value ? (string)dr["Direct_Phone"] : "";
                        //model.Fax_Number = dr["Fax_Number"] != null && dr["Fax_Number"] != DBNull.Value ? (string)dr["Fax_Number"] : "";
                        //model.Relation_To_Company = dr["Relation_To_Company"] != null && dr["Relation_To_Company"] != DBNull.Value ? (string)dr["Relation_To_Company"] : "";
                        //model.Reason_For_Account = dr["Reason_For_Account"] != null && dr["Reason_For_Account"] != DBNull.Value ? (string)dr["Reason_For_Account"] : "";
                        //model.Print_Name = dr["Print_Name"] != null && dr["Print_Name"] != DBNull.Value ? (string)dr["Print_Name"] : "";
                        //model.Intra_Print_Name = dr["Intra_Print_Name"] != null && dr["Intra_Print_Name"] != DBNull.Value ? (string)dr["Intra_Print_Name"] : "";
                        //model.APPLICATIONID = dr["APPLICATIONID"] != null && dr["APPLICATIONID"] != DBNull.Value ? (Guid)dr["APPLICATIONID"] : Guid.Empty;
                        //model.USERID = dr["USERID"] != null && dr["USERID"] != DBNull.Value ? (Guid)dr["USERID"] : Guid.Empty;
                        //model.USERNAME = dr["USERNAME"] != null && dr["USERNAME"] != DBNull.Value ? (string)dr["USERNAME"] : "";
                        //model.LOWEREDUSERNAME = dr["LOWEREDUSERNAME"] != null && dr["LOWEREDUSERNAME"] != DBNull.Value ? (string)dr["LOWEREDUSERNAME"] : "";
                        //model.MOBILEALIAS = dr["MOBILEALIAS"] != null && dr["MOBILEALIAS"] != DBNull.Value ? (string)dr["MOBILEALIAS"] : "";
                        //model.ISANONYMOUS = dr["ISANONYMOUS"] != null && dr["ISANONYMOUS"] != DBNull.Value ? (int)dr["ISANONYMOUS"] : 0;
                        //model.LASTACTIVITYDATE = dr["LASTACTIVITYDATE"] != null && dr["LASTACTIVITYDATE"] != DBNull.Value ? (DateTime)dr["LASTACTIVITYDATE"] : DateTime.MinValue;
                    }
                }
                return model;
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
            finally
            {
                cmd.Dispose();
                oraConn.Close();
                oraConn.Dispose();
            }
        }

        public bool IsExistedUserByUserIDAndUsername(string userid, string username)
        {
            OracleCommand cmd = null;
            OracleDataReader dr = null;
            var oraConn = new OracleConnection(pConn);
            try
            {
                oraConn.Open();
                var sql = "select * from plm.ora_aspnet_users where userid = :userid and loweredusername = :username ";
                cmd = new OracleCommand(sql, oraConn);
                cmd.Parameters.Add("userid", OracleDbType.Varchar2, 255).Value = userid;
                cmd.Parameters.Add("username", OracleDbType.Varchar2, 255).Value = username;
                dr = cmd.ExecuteReader();
                if (dr != null && dr.HasRows)
                    return true;
                return false;
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
            finally
            {
                cmd.Dispose();
                oraConn.Close();
                oraConn.Dispose();
            }
        }

        public bool IsVendorSiteUser(string userid)
        {
            OracleCommand cmd = null;
            OracleDataReader dr = null;
            var oraConn = new OracleConnection(conn);
            try
            {
                oraConn.Open();
                var sql = "select * from pei_custom.xx_vendor_users where ora_aspnet_userid = :userid";
                cmd = new OracleCommand(sql, oraConn);
                cmd.Parameters.Add("userid", OracleDbType.Varchar2, 255).Value = userid;
                dr = cmd.ExecuteReader();
                if (dr != null && dr.HasRows)
                    return true;
                return false;
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
            finally
            {
                cmd.Dispose();
                oraConn.Close();
                oraConn.Dispose();
            }
        }

        public bool UpdateUserFlagByID(string password, DateTime logonTime, string id)
        {
            var oraConn = new OracleConnection(conn);
            OracleCommand cmd = null;
            try
            {
                oraConn.Open();
                var sql = "update pei_custom.xx_vendor_users set password= :password, logon_time=:logonTime where id = :id";
                cmd = new OracleCommand(sql, oraConn);
                OracleParameter[] parameters ={
                     new OracleParameter("password",OracleDbType.Varchar2),
                     new OracleParameter("logonTime",OracleDbType.Date),
                     new OracleParameter("id",OracleDbType.Varchar2)
                };
                parameters[0].Value = password;
                parameters[1].Value = logonTime;
                parameters[2].Value = id;
                foreach (var param in parameters)
                {
                    cmd.Parameters.Add(param);
                }
                var row = cmd.ExecuteNonQuery() > 0;
                return row;
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
            finally
            {
                if (cmd != null) cmd.Dispose();
                if (oraConn.State == System.Data.ConnectionState.Open)
                {
                    oraConn.Close();
                    oraConn.Dispose();
                }
            }
        }

        public bool UpdateUserFlagByUserID(string password, DateTime logonTime, string userid)
        {
            var oraConn = new OracleConnection(conn);
            OracleCommand cmd = null;
            try
            {
                oraConn.Open();
                var sql = "update pei_custom.xx_vendor_users set password= :password, logon_time=:logonTime where ora_aspnet_userid = :userid";
                cmd = new OracleCommand(sql, oraConn);
                OracleParameter[] parameters ={
                     new OracleParameter("password",OracleDbType.Varchar2),
                     new OracleParameter("logonTime",OracleDbType.Date),
                     new OracleParameter("userid",OracleDbType.Varchar2)
                };
                parameters[0].Value = password;
                parameters[1].Value = logonTime;
                parameters[2].Value = userid;
                foreach (var param in parameters)
                {
                    cmd.Parameters.Add(param);
                }
                var row = cmd.ExecuteNonQuery() > 0;
                return row;
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
            finally
            {
                if (cmd != null) cmd.Dispose();
                if (oraConn.State == System.Data.ConnectionState.Open)
                {
                    oraConn.Close();
                    oraConn.Dispose();
                }
            }
        }

        public UserItem GetLogonTimeByFlag(string flag)
        {
            OracleCommand cmd = null;
            OracleDataReader dr = null;
            UserItem model = null;
            var oraConn = new OracleConnection(conn);
            try
            {
                oraConn.Open();
                var sql = "select id, mail, logon_time, ora_aspnet_userid from pei_custom.xx_vendor_users where password= :flag";
                cmd = new OracleCommand(sql, oraConn);
                cmd.Parameters.Add("flag", OracleDbType.Varchar2, 255).Value = flag;
                dr = cmd.ExecuteReader();
                if (dr != null && dr.HasRows)
                {
                    model = new UserItem();
                    while (dr.Read())
                    {
                        model.ID = dr.GetString(0);
                        model.Mail = dr["Mail"] != null && dr["Mail"] != DBNull.Value ? (string)dr["Mail"] : "";
                        model.Logon_Time = dr["Logon_Time"] != null && dr["Logon_Time"] != DBNull.Value ? (DateTime)dr["Logon_Time"] : DateTime.MinValue;
                        model.ORA_ASPNET_USERID = dr["ORA_ASPNET_USERID"] != null && dr["ORA_ASPNET_USERID"] != DBNull.Value ? (byte[])dr["ORA_ASPNET_USERID"] : null;
                    }
                }
                return model;
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
            finally
            {
                cmd.Dispose();
                oraConn.Close();
                oraConn.Dispose();
            }
        }

        /// <summary>
        /// Get ToUser list for Dropdown
        /// </summary>
        /// <param name="connectString">connection string</param>
        /// <returns></returns>
        public List<UserItem> GetToUserList(string toUser)
        {
            List<UserItem> list = null;
            OracleCommand cmd = null;
            OracleDataReader dr = null;
            var oraConn = new OracleConnection(conn);
            try
            {
                oraConn.Open();
                //var sql = @"select ID,Upload_Folder,lower(name) ||' -- '|| id || ' -- ' ||MAIL   displayname from pei_custom.xx_vendor_users u 
                //            where u.id  in(select user_id from pei_custom.xx_vendor_user_permission where (permission_id='GET_FILES_FROM_PEI_USERS' or permission_id='DOWNLOAD_FILES')) 
                //            and u.ora_aspnet_userid is not null
                //            and (IsActive = 1 or IsActive is null)
                //            order by displayname";
                var sql = @"select ID,Download_Folder,MAIL, lower(name) displayname from pei_custom.xx_vendor_users u 
                            where u.id  in(select user_id from pei_custom.xx_vendor_user_permission where (permission_id='GET_FILES_FROM_PEI_USERS' or permission_id='DOWNLOAD_FILES')) 
                            and u.ora_aspnet_userid is not null
                            and (IsActive = 1 or IsActive is null)
                            and (lower(NAME) like lower('%'||:username||'%') or lower(MAIL) like lower('%'||:username||'%'))
                            order by displayname";
                cmd = new OracleCommand(sql, oraConn);
                cmd.Parameters.Add("username", OracleDbType.Varchar2, 255).Value = toUser;
                dr = cmd.ExecuteReader();
                if (dr != null && dr.HasRows)
                {
                    list = new List<UserItem>();
                    while (dr.Read())
                    {
                        var model = new UserItem();
                        model.ID = dr.GetString(0);
                        if (dr["Download_Folder"] != null && dr["Download_Folder"] != DBNull.Value) model.Download_Folder = dr.GetString(1);
                        if (dr["MAIL"] != null && dr["MAIL"] != DBNull.Value) model.Mail = dr.GetString(2);
                        if (dr["displayname"] != null && dr["displayname"] != DBNull.Value) model.DisplayName = dr.GetString(3);
                        list.Add(model);
                    }
                }
                return list;
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
            finally
            {
                if (dr != null) dr.Dispose();
                if (cmd != null) cmd.Dispose();
                if (oraConn.State == System.Data.ConnectionState.Open)
                {
                    oraConn.Close();
                    oraConn.Dispose();
                }
            }
        }

        /// <summary>
        /// Through User ID Get User Entity Data
        /// </summary>
        /// <param name="connectionString">Connection String</param>
        /// <param name="id">User ID</param>
        /// <returns></returns>
        public UserItem GetUserItemByID(string id)
        {
            OracleCommand cmd = null;
            OracleDataReader dr = null;
            UserItem model = null;
            var oraConn = new OracleConnection(conn);
            try
            {
                oraConn.Open();
                var sql = "select * from pei_custom.xx_vendor_users where lower(ID)=lower(:ID)";
                cmd = new OracleCommand(sql, oraConn);
                cmd.Parameters.Add("ID", OracleDbType.Varchar2, 255).Value = id;
                dr = cmd.ExecuteReader();
                if (dr != null && dr.HasRows)
                {
                    model = new UserItem();
                    while (dr.Read())
                    {
                        model.ID = dr.GetString(0);
                        model.SaMacCountName = dr.GetString(1);
                        model.ObjectCategory = dr["ObjectCategory"] != null && dr["ObjectCategory"] != DBNull.Value ? (string)dr["ObjectCategory"] : "";
                        model.Mail = dr["Mail"] != null && dr["Mail"] != DBNull.Value ? (string)dr["Mail"] : "";
                        model.Name = dr.GetString(4);
                        model.Department = dr["Department"] != null && dr["Department"] != DBNull.Value ? (string)dr["Department"] : "";
                        model.DistinguishedName = dr["DistinguishedName"] != null && dr["DistinguishedName"] != DBNull.Value ? (string)dr["DistinguishedName"] : "";
                        model.ObjectClass = dr["ObjectClass"] != null && dr["ObjectClass"] != DBNull.Value ? (string)dr["ObjectClass"] : "";
                        model.UserPrincipalName = dr["UserPrincipalName"] != null && dr["UserPrincipalName"] != DBNull.Value ? (string)dr["UserPrincipalName"] : "";
                        model.Upload_Folder = dr["Upload_Folder"] != null && dr["Upload_Folder"] != DBNull.Value ? (string)dr["Upload_Folder"] : "";// dr.GetString(9);
                        model.Download_Folder = dr["Download_Folder"] != null && dr["Download_Folder"] != DBNull.Value ? (string)dr["Download_Folder"] : ""; //dr.GetString(10);
                        model.Domain_Name = dr["Domain_Name"] != null && dr["Domain_Name"] != DBNull.Value ? (string)dr["Domain_Name"] : "";//dr.GetString(11);
                        model.Title = dr["Title"] != null && dr["Title"] != DBNull.Value ? (string)dr["Title"] : "";//dr.GetString(12);
                        model.Company = dr["Company"] != null && dr["Company"] != DBNull.Value ? (string)dr["Company"] : "";
                        model.SN = dr["SN"] != null && dr["SN"] != DBNull.Value ? (string)dr["SN"] : "";
                        model.Telephone_Number = dr["Telephone_Number"] != null && dr["Telephone_Number"] != DBNull.Value ? (string)dr["Telephone_Number"] : "";
                        model.Postal_Code = dr["Postal_Code"] != null && dr["Postal_Code"] != DBNull.Value ? (string)dr["Postal_Code"] : "";
                        model.Given_Name = dr["Given_Name"] != null && dr["Given_Name"] != DBNull.Value ? (string)dr["Given_Name"] : "";
                        model.Country = dr["Country"] != null && dr["Country"] != DBNull.Value ? (string)dr["Country"] : "";
                        model.City = dr["City"] != null && dr["City"] != DBNull.Value ? (string)dr["City"] : "";
                        model.Street_Address = dr["Street_Address"] != null && dr["Street_Address"] != DBNull.Value ? (string)dr["Street_Address"] : "";
                        model.State = dr["State"] != null && dr["State"] != DBNull.Value ? (string)dr["State"] : "";
                        model.Password = dr["Password"] != null && dr["Password"] != DBNull.Value ? (string)dr["Password"] : "";
                        model.WebPDMGroups = dr["WebPDMGroups"] != null && dr["WebPDMGroups"] != DBNull.Value ? (string)dr["WebPDMGroups"] : "";
                        model.First_Name = dr["First_Name"] != null && dr["First_Name"] != DBNull.Value ? (string)dr["First_Name"] : "";
                        model.Last_Name = dr["Last_Name"] != null && dr["Last_Name"] != DBNull.Value ? (string)dr["Last_Name"] : "";
                        model.Direct_Phone = dr["Direct_Phone"] != null && dr["Direct_Phone"] != DBNull.Value ? (string)dr["Direct_Phone"] : "";
                        model.Fax_Number = dr["Fax_Number"] != null && dr["Fax_Number"] != DBNull.Value ? (string)dr["Fax_Number"] : "";
                        model.Relation_To_Company = dr["Relation_To_Company"] != null && dr["Relation_To_Company"] != DBNull.Value ? (string)dr["Relation_To_Company"] : "";
                        model.Reason_For_Account = dr["Reason_For_Account"] != null && dr["Reason_For_Account"] != DBNull.Value ? (string)dr["Reason_For_Account"] : "";
                        model.Print_Name = dr["Print_Name"] != null && dr["Print_Name"] != DBNull.Value ? (string)dr["Print_Name"] : "";
                        model.Intra_Print_Name = dr["Intra_Print_Name"] != null && dr["Intra_Print_Name"] != DBNull.Value ? (string)dr["Intra_Print_Name"] : "";
                    }
                }
                return model;
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
            finally
            {
                cmd.Dispose();
                oraConn.Close();
                oraConn.Dispose();
            }
        }

        public string createFileItem(string from_userid, string to_userid, string file_name, string category)
        {
            string ret = "";
            OracleTransaction OT = null;
            var oraConn = new OracleConnection(conn);
            try
            {
                oraConn.Open();
                OT = oraConn.BeginTransaction();
                var sql = @"Insert into PEI_CUSTOM.XX_VENDOR_FILE(file_id,display_name,actual_name,category,create_date,create_by) 
                                            VALUES(:file_id,:display_name,:actual_name,:category,:create_date,:create_by)";
                var cmd = new OracleCommand(sql, oraConn);
                cmd.Transaction = OT;
                cmd.Parameters.Clear();
                string file_id = Guid.NewGuid().ToString();
                cmd.Parameters.Add("file_id", OracleDbType.Varchar2, 50).Value = file_id;
                cmd.Parameters.Add("display_name", OracleDbType.Varchar2, 60).Value = file_name;
                cmd.Parameters.Add("actual_name", OracleDbType.Varchar2, 60).Value = file_name;
                cmd.Parameters.Add("category", OracleDbType.Varchar2, 32).Value = category;
                cmd.Parameters.Add("create_date", OracleDbType.Varchar2).Value = DateTime.Now;
                cmd.Parameters.Add("create_by", OracleDbType.Varchar2, 32).Value = from_userid;
                cmd.ExecuteNonQuery();

                cmd.Parameters.Clear();
                cmd.CommandText = @"Insert into PEI_CUSTOM.XX_VENDOR_USER_FILE(user_id,file_id,is_show) VALUES(:user_id,:file_id,:is_show)";
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.Parameters.Add("user_id", OracleDbType.Varchar2, 32).Value = to_userid;
                cmd.Parameters.Add("file_id", OracleDbType.Varchar2, 50).Value = file_id;
                cmd.Parameters.Add("is_show", OracleDbType.Varchar2, 1).Value = "0";
                cmd.ExecuteNonQuery();
                OT.Commit();
                ret = file_id;
            }
            catch (Exception e)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), e);
                OT.Rollback();
                throw e;
            }
            finally
            {
                oraConn.Close();
                oraConn.Dispose();
            }
            return ret;
        }

        /// <summary>
        /// Multiple conditions get account information
        /// </summary>
        /// <param name="sql">select sentence</param>
        /// <returns></returns>
        public List<UserItem> GetAccountDataByMultipleConditions(string sql)
        {
            var oraConn = new OracleConnection(conn);
            OracleCommand cmd = null;
            OracleDataReader dr = null;
            List<UserItem> list = null;
            try
            {
                oraConn.Open();
                cmd = new OracleCommand(sql, oraConn);
                dr = cmd.ExecuteReader();
                if (dr != null && dr.HasRows)
                {
                    list = new List<UserItem>();
                    while (dr.Read())
                    {
                        var model = new UserItem();
                        model.ID = dr["ID"] != null && dr["ID"] != DBNull.Value ? dr.GetString(0) : "";
                        model.Name = dr["Name"] != null && dr["Name"] != DBNull.Value ? dr.GetString(1) : "";
                        model.SaMacCountName = dr["SaMacCountName"] != null && dr["SaMacCountName"] != DBNull.Value ? dr.GetString(2) : "";
                        model.Company = dr["Company"] != null && dr["Company"] != DBNull.Value ? dr.GetString(3) : "";
                        model.Mail = dr["Mail"] != null && dr["Mail"] != DBNull.Value ? dr.GetString(4) : "";
                        if (dr["IsActive"] != null && dr["IsActive"] != DBNull.Value) model.IsAcive = Convert.ToInt32(dr["IsActive"]);
                        list.Add(model);
                    }
                }
                return list;
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
            finally
            {
                if (cmd != null) cmd.Dispose();
                if (oraConn.State == System.Data.ConnectionState.Open)
                {
                    oraConn.Close();
                    oraConn.Dispose();
                }
            }
        }

        public List<OAsp_Membership> GetUserIDsByEmail(string email)
        {
            var oraConn = new OracleConnection(pConn);
            OracleCommand cmd = null;
            OracleDataReader dr = null;
            List<OAsp_Membership> list = null;
            try
            {
                oraConn.Open();
                var sql = "select userid from PLM.ORA_ASPNET_MEMBERSHIP where LOWEREDEMAIL = lower(:mail)";
                cmd = new OracleCommand(sql, oraConn);
                OracleParameter[] parameters = {
                        new OracleParameter("mail",OracleDbType.NVarchar2)
                    };
                parameters[0].Value = email;
                foreach (var param in parameters)
                    cmd.Parameters.Add(param);
                dr = cmd.ExecuteReader();
                if (dr != null && dr.HasRows)
                {
                    list = new List<OAsp_Membership>();
                    while (dr.Read())
                    {
                        var model = new OAsp_Membership();
                        model.UserID = dr["USERID"] != null && dr["USERID"] != DBNull.Value ? (byte[])dr["USERID"] : null;
                        list.Add(model);
                    }
                }
                return list;
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
            finally
            {
                if (cmd != null) cmd.Dispose();
                if (oraConn.State == System.Data.ConnectionState.Open)
                {
                    oraConn.Close();
                    oraConn.Dispose();
                }
            }
        }

        /// <summary>
        /// Get user detail information through user ID
        /// </summary>
        /// <param name="sql">sql sentence</param>
        /// <returns></returns>
        public UserItem GetUserDetailByID(string sql)
        {
            var oraConn = new OracleConnection(conn);
            OracleCommand cmd = null;
            OracleDataReader dr = null;
            UserItem model = null;
            try
            {
                oraConn.Open();
                cmd = new OracleCommand(sql, oraConn);
                dr = cmd.ExecuteReader();
                if (dr != null && dr.HasRows)
                {
                    model = new UserItem();
                    while (dr.Read())
                    {
                        model.ID = dr["ID"] != null && dr["ID"] != DBNull.Value ? dr.GetString(0) : "";
                        model.Name = dr["Name"] != null && dr["Name"] != DBNull.Value ? dr.GetString(1) : "";
                        model.First_Name = dr["First_Name"] != null && dr["First_Name"] != DBNull.Value ? dr.GetString(2) : "";
                        model.Last_Name = dr["Last_Name"] != null && dr["Last_Name"] != DBNull.Value ? dr.GetString(3) : "";
                        model.Direct_Phone = dr["Direct_Phone"] != null && dr["Direct_Phone"] != DBNull.Value ? dr.GetString(4) : "";
                        model.Mail = dr["Mail"] != null && dr["Mail"] != DBNull.Value ? dr.GetString(5) : "";
                        model.Print_Name = dr["Print_Name"] != null && dr["Print_Name"] != DBNull.Value ? dr.GetString(6) : "";
                        model.Intra_Print_Name = dr["Intra_Print_Name"] != null && dr["Intra_Print_Name"] != DBNull.Value ? dr.GetString(7) : "";
                        model.Company = dr["Company"] != null && dr["Company"] != DBNull.Value ? dr.GetString(8) : "";
                        model.Street_Address = dr["Street_Address"] != null && dr["Street_Address"] != DBNull.Value ? dr.GetString(9) : "";
                        model.City = dr["City"] != null && dr["City"] != DBNull.Value ? dr.GetString(10) : "";
                        model.State = dr["State"] != null && dr["State"] != DBNull.Value ? dr.GetString(11) : "";
                        model.Postal_Code = dr["Postal_Code"] != null && dr["Postal_Code"] != DBNull.Value ? dr.GetString(12) : "";
                        model.Country = dr["Country"] != null && dr["Country"] != DBNull.Value ? dr.GetString(13) : "";
                        model.Telephone_Number = dr["Telephone_Number"] != null && dr["Telephone_Number"] != DBNull.Value ? dr.GetString(14) : "";
                        model.Fax_Number = dr["Fax_Number"] != null && dr["Fax_Number"] != DBNull.Value ? dr.GetString(15) : "";
                        model.Reason_For_Account = dr["Reason_For_Account"] != null && dr["Reason_For_Account"] != DBNull.Value ? dr.GetString(16) : "";
                        model.Upload_Folder = dr["Upload_Folder"] != null && dr["Upload_Folder"] != DBNull.Value ? dr.GetString(17) : "";
                        //if (dr["IsActive"] != null && dr["IsActive"] != DBNull.Value) model.IsAcive = dr.GetInt16(18);
                        model.SaMacCountName = dr["SaMacCountName"] != null && dr["SaMacCountName"] != DBNull.Value ? dr.GetString(19) : "";
                    }
                }
                return model;
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
            finally
            {
                if (cmd != null) cmd.Dispose();
                if (oraConn.State == System.Data.ConnectionState.Open)
                {
                    oraConn.Close();
                    oraConn.Dispose();
                }
            }
        }

        public bool UpdateSyncFolderName(string syncFolderName, string id)
        {
            var oraConn = new OracleConnection(conn);
            OracleCommand cmd = null;
            try
            {
                oraConn.Open();
                var sql = "update pei_custom.xx_vendor_users set upload_folder=:syncFolderName where id = :id";
                cmd = new OracleCommand(sql, oraConn);
                OracleParameter[] parameters ={
                     new OracleParameter("syncFolderName",OracleDbType.Varchar2),
                     new OracleParameter("id",OracleDbType.Varchar2)
                };
                parameters[0].Value = syncFolderName;
                parameters[1].Value = id;
                foreach (var param in parameters)
                {
                    cmd.Parameters.Add(param);
                }
                var row = cmd.ExecuteNonQuery() > 0;
                return row;
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
            finally
            {
                if (cmd != null) cmd.Dispose();
                if (oraConn.State == System.Data.ConnectionState.Open)
                {
                    oraConn.Close();
                    oraConn.Dispose();
                }
            }
        }

        /// <summary>
        /// Update account data
        /// </summary>
        /// <param name="model">xx_vendor_users entity</param>
        /// <returns></returns>
        public bool UpdateAccountData(UserItem model)
        {
            var oraConn = new OracleConnection(conn);
            OracleCommand cmd = null;
            try
            {
                oraConn.Open();
                var sql = @"update pei_custom.XX_Vendor_Users set Company = :Company,
                            Street_Address = :Street_Address, First_Name = :First_Name,
                            City = :City, Last_Name = :Last_Name, State = :State, 
                            Direct_Phone = :Direct_Phone, Postal_Code = :Postal_Code, 
                            Mail = :Mail, Country = :Country, Print_Name = :Print_Name,
                            Telephone_Number = :Telephone_Number, Intra_Print_Name = :Intra_Print_Name, 
                            Fax_Number = :Fax_Number, Reason_For_Account = :Reason_For_Account 
                            where ID = :ID
                            ";
                cmd = new OracleCommand(sql, oraConn);
                OracleParameter[] parameters ={
                     new OracleParameter("Company",OracleDbType.Varchar2),
                     new OracleParameter("Street_Address",OracleDbType.Varchar2),
                     new OracleParameter("First_Name",OracleDbType.Varchar2),
                     new OracleParameter("City",OracleDbType.Varchar2),
                     new OracleParameter("Last_Name",OracleDbType.Varchar2),
                     new OracleParameter("State",OracleDbType.Varchar2),
                     new OracleParameter("Direct_Phone",OracleDbType.Varchar2),
                     new OracleParameter("Postal_Code",OracleDbType.Varchar2),
                     new OracleParameter("Mail",OracleDbType.Varchar2),
                     new OracleParameter("Country",OracleDbType.Varchar2),
                     new OracleParameter("Print_Name",OracleDbType.Varchar2),
                     new OracleParameter("Telephone_Number",OracleDbType.Varchar2),
                     new OracleParameter("Intra_Print_Name",OracleDbType.Varchar2),
                     new OracleParameter("Fax_Number",OracleDbType.Varchar2),
                     new OracleParameter("Reason_For_Account",OracleDbType.Varchar2),
                     new OracleParameter("ID",OracleDbType.Varchar2)
                };
                parameters[0].Value = model.Company;
                parameters[1].Value = model.Street_Address;
                parameters[2].Value = model.First_Name;
                parameters[3].Value = model.City;
                parameters[4].Value = model.Last_Name;
                parameters[5].Value = model.State;
                parameters[6].Value = model.Direct_Phone;
                parameters[7].Value = model.Postal_Code;
                parameters[8].Value = model.Mail;
                parameters[9].Value = model.Country;
                parameters[10].Value = model.Print_Name;
                parameters[11].Value = model.Telephone_Number;
                parameters[12].Value = model.Intra_Print_Name;
                parameters[13].Value = model.Fax_Number;
                parameters[14].Value = model.Reason_For_Account;
                parameters[15].Value = model.ID;
                foreach (var param in parameters)
                {
                    cmd.Parameters.Add(param);
                }
                var row = cmd.ExecuteNonQuery() > 0;
                return row;
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
            finally
            {
                if (cmd != null) cmd.Dispose();
                if (oraConn.State == System.Data.ConnectionState.Open)
                {
                    oraConn.Close();
                    oraConn.Dispose();
                }
            }
        }

        /// <summary>
        /// Create external user
        /// </summary>
        /// <param name="model">xx_vendor_users entity</param>
        /// <returns></returns>
        public bool CreateUserByExternal(UserItem model)
        {
            var oraConn = new OracleConnection(conn);
            OracleCommand cmd = null;
            try
            {
                oraConn.Open();
                var sql = @"insert into pei_custom.XX_Vendor_Users  
                            values (:ID, :SAMACCOUNTNAME, :OBJECTCATEGORY, 
                                    :MAIL, :NAME, :DEPARTMENT, 
                                    :DISTINGUISHEDNAME, :OBJECTCLASS, :USERPRINCIPALNAME, 
                                    :UPLOAD_FOLDER, :DOWNLOAD_FOLDER, :DOMAIN_NAME, 
                                    :TITLE, :COMPANY, :SN, 
                                    :TELEPHONE_NUMBER, :POSTAL_CODE, :GIVEN_NAME, 
                                    :COUNTRY, :CITY, :STREET_ADDRESS, 
                                    :STATE, :PASSWORD, :WEBPDMGROUPS, 
                                    :FIRST_NAME, :LAST_NAME, :DIRECT_PHONE,
                                    :FAX_NUMBER, :RELATION_TO_COMPANY, :REASON_FOR_ACCOUNT, 
                                    :PRINT_NAME, :INTRA_PRINT_NAME, 
                                    :ISACTIVE, :LOGON_TIME, :ORA_ASPNET_USERID)";
                //, :ORA_ASPNET_USERID

                cmd = new OracleCommand(sql, oraConn);
                OracleParameter[] parameters = {
                    new OracleParameter("ID",OracleDbType.Varchar2),
                    new OracleParameter("SAMACCOUNTNAME",OracleDbType.Varchar2),
                    new OracleParameter("OBJECTCATEGORY",OracleDbType.Varchar2),
                    new OracleParameter("MAIL",OracleDbType.Varchar2),
                    new OracleParameter("NAME",OracleDbType.Varchar2),
                    new OracleParameter("DEPARTMENT",OracleDbType.Varchar2),
                    new OracleParameter("DISTINGUISHEDNAME",OracleDbType.Varchar2),
                    new OracleParameter("OBJECTCLASS",OracleDbType.Varchar2),
                    new OracleParameter("USERPRINCIPALNAME",OracleDbType.Varchar2),
                    new OracleParameter("UPLOAD_FOLDER",OracleDbType.Varchar2),
                    new OracleParameter("DOWNLOAD_FOLDER",OracleDbType.Varchar2),
                    new OracleParameter("DOMAIN_NAME",OracleDbType.Varchar2),
                    new OracleParameter("TITLE",OracleDbType.Varchar2),
                    new OracleParameter("COMPANY",OracleDbType.Varchar2),
                    new OracleParameter("SN",OracleDbType.Varchar2),
                    new OracleParameter("TELEPHONE_NUMBER",OracleDbType.Varchar2),
                    new OracleParameter("POSTAL_CODE",OracleDbType.Varchar2),
                    new OracleParameter("GIVEN_NAME",OracleDbType.Varchar2),
                    new OracleParameter("COUNTRY",OracleDbType.Varchar2),
                    new OracleParameter("CITY",OracleDbType.Varchar2),
                    new OracleParameter("STREET_ADDRESS",OracleDbType.Varchar2),
                    new OracleParameter("STATE",OracleDbType.Varchar2),
                    new OracleParameter("PASSWORD",OracleDbType.Varchar2),
                    new OracleParameter("WEBPDMGROUPS",OracleDbType.Varchar2),
                    new OracleParameter("FIRST_NAME",OracleDbType.Varchar2),
                    new OracleParameter("LAST_NAME",OracleDbType.Varchar2),
                    new OracleParameter("DIRECT_PHONE",OracleDbType.Varchar2),
                    new OracleParameter("FAX_NUMBER",OracleDbType.Varchar2),
                    new OracleParameter("RELATION_TO_COMPANY",OracleDbType.Varchar2),
                    new OracleParameter("REASON_FOR_ACCOUNT",OracleDbType.Varchar2),
                    new OracleParameter("PRINT_NAME",OracleDbType.Varchar2),
                    new OracleParameter("INTRA_PRINT_NAME",OracleDbType.Varchar2),
                    new OracleParameter("ISACTIVE",OracleDbType.Int16),
                    new OracleParameter("LOGON_TIME",OracleDbType.TimeStamp),
                    new OracleParameter("ORA_ASPNET_USERID",OracleDbType.Raw)
                };
                parameters[0].Value = model.ID;
                parameters[1].Value = model.SaMacCountName;
                parameters[2].Value = model.ObjectCategory;
                parameters[3].Value = model.Mail;
                parameters[4].Value = model.Name;
                parameters[5].Value = model.Department;
                parameters[6].Value = model.DistinguishedName;
                parameters[7].Value = model.ObjectClass;
                parameters[8].Value = model.UserPrincipalName;
                parameters[9].Value = model.Upload_Folder;
                parameters[10].Value = model.Download_Folder;
                parameters[11].Value = model.Domain_Name;
                parameters[12].Value = model.Title;
                parameters[13].Value = model.Company;
                parameters[14].Value = model.SN;
                parameters[15].Value = model.Telephone_Number;
                parameters[16].Value = model.Postal_Code;
                parameters[17].Value = model.Given_Name;
                parameters[18].Value = model.Country;
                parameters[19].Value = model.City;
                parameters[20].Value = model.Street_Address;
                parameters[21].Value = model.State;
                parameters[22].Value = model.Password;
                parameters[23].Value = model.WebPDMGroups;
                parameters[24].Value = model.First_Name;
                parameters[25].Value = model.Last_Name;
                parameters[26].Value = model.Direct_Phone;
                parameters[27].Value = model.Fax_Number;
                parameters[28].Value = model.Relation_To_Company;
                parameters[29].Value = model.Reason_For_Account;
                parameters[30].Value = model.Print_Name;
                parameters[31].Value = model.Intra_Print_Name;
                parameters[32].Value = model.IsAcive;
                parameters[33].Value = model.Logon_Time;
                parameters[34].Value = model.ORA_ASPNET_USERID;
                foreach (var param in parameters)
                {
                    cmd.Parameters.Add(param);
                }
                var row = cmd.ExecuteNonQuery() > 0;
                return row;
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
            finally
            {
                if (cmd != null) cmd.Dispose();
                if (oraConn.State == System.Data.ConnectionState.Open)
                {
                    oraConn.Close();
                    oraConn.Dispose();
                }
            }
        }

        public bool IsExistenceUser(string accountName)
        {
            var oraConn = new OracleConnection(conn);
            OracleCommand cmd = null;
            OracleDataReader dr = null;
            try
            {
                oraConn.Open();
                var sql = "select * from pei_custom.xx_vendor_users where lower(SaMacCountName)=lower(:accountName)";
                var parameter = new OracleParameter("accountName", OracleDbType.Varchar2, 25);
                parameter.Value = accountName;
                cmd = new OracleCommand(sql, oraConn);
                cmd.Parameters.Add(parameter);
                dr = cmd.ExecuteReader();
                if (dr != null && dr.HasRows)
                {
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
            finally
            {
                dr.Dispose();
                dr.Close();
                cmd.Dispose();
                if (oraConn.State == System.Data.ConnectionState.Open)
                {
                    oraConn.Dispose();
                    oraConn.Close();
                }
            }
        }

        public bool IsExistenceSyncFolder(string syncFolderName)
        {
            var oraConn = new OracleConnection(conn);
            OracleCommand cmd = null;
            OracleDataReader dr = null;
            try
            {
                oraConn.Open();
                var sql = "select * from pei_custom.xx_vendor_users where lower(upload_folder)=lower(:syncFolderName)";
                var parameter = new OracleParameter("syncFolderName", OracleDbType.Varchar2, 120);
                parameter.Value = syncFolderName;
                cmd = new OracleCommand(sql, oraConn);
                cmd.Parameters.Add(parameter);
                dr = cmd.ExecuteReader();
                if (dr != null && dr.HasRows)
                {
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
            finally
            {
                dr.Dispose();
                dr.Close();
                cmd.Dispose();
                if (oraConn.State == System.Data.ConnectionState.Open)
                {
                    oraConn.Dispose();
                    oraConn.Close();
                }
            }
        }

        public bool IsExistenceEmail(string mail)
        {
            var oraConn = new OracleConnection(conn);
            OracleCommand cmd = null;
            try
            {
                oraConn.Open();
                var sql = "select count(*) from pei_custom.xx_vendor_users where lower(mail) = lower(:mail)";
                var parameter = new OracleParameter("mail", OracleDbType.Varchar2, 50);
                parameter.Value = mail;
                cmd = new OracleCommand(sql, oraConn);
                cmd.Parameters.Add(parameter);
                var result = cmd.ExecuteScalar();
                var convertResultValue = Convert.ToInt32(result);
                if (convertResultValue >= 1)
                {
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
            finally
            {
                cmd.Dispose();
                if (oraConn.State == System.Data.ConnectionState.Open)
                {
                    oraConn.Dispose();
                    oraConn.Close();
                }
            }
        }

        /// <summary>
        /// Determines whether the user already exists
        /// </summary>
        /// <param name="userName">User name</param>
        /// <returns></returns>
        public bool IsExistUserName(string userName)
        {
            var oraConn = new OracleConnection(conn);
            OracleCommand cmd = null;
            try
            {
                oraConn.Open();
                var sql = String.Format("select count(*) from pei_custom.xx_vendor_users where SaMacCountName = '{0}'", userName);
                cmd = new OracleCommand(sql, oraConn);
                var value = (int)cmd.ExecuteScalar();
                return value >= 1 ? true : false;
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
            finally
            {
                if (cmd != null) cmd.Dispose();
                if (oraConn.State == System.Data.ConnectionState.Open)
                {
                    oraConn.Close();
                    oraConn.Dispose();
                }
            }
        }

        public System.Data.DataSet GetFilesFromPartner(string current_user, string from_user)
        {
            var oraConn = new OracleConnection(conn);
            string sql = "";
            OracleCommand cmd = null;
            OracleDataAdapter da = null;
            System.Data.DataSet ds = null;
            try
            {
                oraConn.Open();
                if (!String.IsNullOrEmpty(from_user))
                {
                    sql = @"SELECT a.file_id,c.name,a.display_name,a.category,a.create_date,(SELECT Download_Folder from  pei_custom.xx_vendor_users where id=:received_user_id)  as Download_Folder 
                            FROM pei_custom.xx_vendor_file a, pei_custom.xx_vendor_user_file b, pei_custom.xx_vendor_users c 
                            WHERE lower(b.user_id)=:received_user_id
                            AND a.create_by=c.id 
                            AND a.file_id = b.file_id 
                            AND lower(c.name) like :user_id 
                            ORDER BY create_date desc";
                    cmd = new OracleCommand(sql, oraConn);
                    OracleParameter[] parameters = {
                        new OracleParameter("received_user_id",OracleDbType.Varchar2),
                        new OracleParameter("user_id",OracleDbType.Varchar2)
                    };
                    parameters[0].Value = current_user;
                    parameters[1].Value = from_user;
                    foreach (var param in parameters)
                    {
                        cmd.Parameters.Add(param);
                    }
                }
                else
                {
                    sql = @"SELECT a.file_id,c.name,a.display_name,a.category,a.create_date,(SELECT Download_Folder from  pei_custom.xx_vendor_users where id=:received_user_id)  as Download_Folder 
                            FROM pei_custom.xx_vendor_file a, pei_custom.xx_vendor_user_file b, pei_custom.xx_vendor_users c 
                            WHERE lower(b.user_id)= :received_user_id
                            AND a.create_by=c.id 
                            AND a.file_id = b.file_id 
                            ORDER BY create_date desc";
                    cmd = new OracleCommand(sql, oraConn);
                    cmd.Parameters.Add("received_user_id", OracleDbType.Varchar2).Value = current_user;
                }
                da = new OracleDataAdapter(sql, oraConn);
                da.SelectCommand = cmd;
                ds = new System.Data.DataSet();
                da.Fill(ds);
                return ds;
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
            finally
            {
                if (ds != null) ds.Dispose();
                if (da != null) da.Dispose();
                if (oraConn.State == System.Data.ConnectionState.Open)
                {
                    oraConn.Close();
                    oraConn.Dispose();
                }
            }
        }

        public void Open()
        {
            oraConn = new OracleConnection(conn);
            oraConn.Open();
        }

        public List<ManualByMail> GetRecentData()
        {
            List<ManualByMail> list = null;
            var sql = "select * from pei_custom.xx_vendor_mannul where updatetime >= sysdate-1 and updatetime <= sysdate order by updatetime desc";
            OracleCommand cmd = null;
            try
            {
                cmd = new OracleCommand(sql, oraConn);
                var dr = cmd.ExecuteReader();
                if (dr != null && dr.HasRows)
                {
                    list = new List<ManualByMail>();
                    while (dr.Read())
                    {
                        var model = new ManualByMail
                        {
                            ID = dr.GetInt32(0),
                            Title = dr.GetString(1),
                            SubNodeSEQ = dr["SUBNODESEQ"] != null && dr["SUBNODESEQ"] != DBNull.Value ? dr.GetString(9) : String.Empty,
                            PID = dr.GetInt32(11)
                        };
                        list.Add(model);
                    }
                    return list;
                }
            }
            finally
            {
                if (cmd != null) cmd.Dispose();
            }
            return list;
        }

        public ManualByMail GetSuperiorData(int pid)
        {
            //var oraConn = new OracleConnection(ConfigurationManager.AppSettings["UserConnection"]);
            //oraConn.Open();
            var sql = "select * from pei_custom.xx_vendor_mannul where id = :pid";
            OracleCommand cmd = null;
            try
            {
                cmd = new OracleCommand(sql, oraConn);
                cmd.Parameters.Add("pid", OracleDbType.Int32).Value = pid;
                var dr = cmd.ExecuteReader();
                if (dr != null && dr.HasRows)
                {
                    var model = new ManualByMail();
                    while (dr.Read())
                    {
                        model.ID = dr["ID"] != null && dr["ID"] != DBNull.Value ? dr.GetInt32(0) : 0;
                        model.Title = dr["TITLE"] != null && dr["TITLE"] != DBNull.Value ? dr.GetString(1) : "";
                        if (dr["PID"] != null && dr["PID"] != DBNull.Value)
                        {
                            model.PID = dr.GetInt32(11);
                        }
                    }
                    return model;
                }
            }
            finally
            {
                if (cmd != null) cmd.Dispose();
            }
            return null;
        }

        public void Close()
        {
            if (oraConn != null && oraConn.State == System.Data.ConnectionState.Open)
            {
                oraConn.Close();
                oraConn.Dispose();
            }
        }

        public bool CreateSyncUser(SyncUser model)
        {
            var oraConn = new OracleConnection(conn);
            OracleCommand cmd = null;
            try
            {
                oraConn.Open();
                var sql = "insert into PEI_Custom.XX_Vendor_Sync_Users(ACCOUNT,NAME,ENABLED,EMAIL,NOTIFICATION_ENABLED,LAST_NOTIFIED_TIME,LAST_ACTIVITY_TIME,INACTIVE_WINDOW_MINUTES,MACHINE_NAME)" +
                          " values (:ACCOUNT,:NAME,:ENABLED,:EMAIL,:NOTIFICATION_ENABLED,:LAST_NOTIFIED_TIME,:LAST_ACTIVITY_TIME,:INACTIVE_WINDOW_MINUTES,:MACHINE_NAME)";
                cmd = new OracleCommand(sql, oraConn);
                cmd.Parameters.Add("ACCOUNT", OracleDbType.Varchar2, 50).Value = model.Account;
                cmd.Parameters.Add("NAME", OracleDbType.Varchar2, 255).Value = model.Name;
                cmd.Parameters.Add("ENABLED", OracleDbType.Char, 1).Value = model.Enabled;
                cmd.Parameters.Add("EMAIL", OracleDbType.Varchar2, 255).Value = model.Email;
                cmd.Parameters.Add("NOTIFICATION_ENABLED", OracleDbType.Char, 1).Value = model.Notification_Enabled;
                cmd.Parameters.Add("LAST_NOTIFIED_TIME", OracleDbType.Date).Value = model.Last_Notified_Time;
                cmd.Parameters.Add("LAST_ACTIVITY_TIME", OracleDbType.Date).Value = model.Last_Activity_Time;
                cmd.Parameters.Add("INACTIVE_WINDOW_MINUTES", OracleDbType.Int32).Value = model.Inactive_Window_Minutes;
                cmd.Parameters.Add("MACHINE_NAME", OracleDbType.Varchar2, 255).Value = model.Machine_Name;
                var row = cmd.ExecuteNonQuery() > 0;
                return row;
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
            finally
            {
                if (cmd != null) cmd.Dispose();
                if (oraConn.State == System.Data.ConnectionState.Open)
                {
                    oraConn.Close();
                    oraConn.Dispose();
                }
            }
        }

        public bool DeleteSyncUser(string account)
        {
            var oraConn = new OracleConnection(conn);
            OracleCommand cmd = null;
            try
            {
                oraConn.Open();
                var sql = "delete from pei_custom.xx_vendor_sync_users where account=:account";
                cmd = new OracleCommand(sql, oraConn);
                cmd.Parameters.Add("account", OracleDbType.Varchar2, 50).Value = account;
                var row = cmd.ExecuteNonQuery() > 0;
                return row;
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
            finally
            {
                if (cmd != null) cmd.Dispose();
                if (oraConn.State == System.Data.ConnectionState.Open)
                {
                    oraConn.Close();
                    oraConn.Dispose();
                }
            }
        }

        public string GetSyncUserName(string account)
        {
            var oraConn = new OracleConnection(conn);
            OracleCommand cmd = null;
            try
            {
                string name = "";
                oraConn.Open();
                var sql = "select * from pei_custom.xx_vendor_sync_users where account=:account";
                cmd = new OracleCommand(sql, oraConn);
                cmd.Parameters.Add("account", OracleDbType.Varchar2, 50).Value = account;
                var dr = cmd.ExecuteReader();
                if (dr != null && dr.HasRows)
                {
                    while (dr.Read())
                    {
                        name = dr["NAME"] != null && dr["NAME"] != DBNull.Value ? dr.GetString(1) : "";
                    }
                }
                return name;
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
            finally
            {
                if (cmd != null) cmd.Dispose();
                if (oraConn.State == System.Data.ConnectionState.Open)
                {
                    oraConn.Close();
                    oraConn.Dispose();
                }
            }
        }

        public bool IsExistSyncUser(string account)
        {
            var oraConn = new OracleConnection(conn);
            OracleCommand cmd = null;
            OracleDataReader dr = null;
            try
            {
                oraConn.Open();
                var sql = "select * from pei_custom.xx_vendor_sync_users where lower(account)=lower(:account)";
                var parameter = new OracleParameter("account", OracleDbType.Varchar2, 50);
                parameter.Value = account;
                cmd = new OracleCommand(sql, oraConn);
                cmd.Parameters.Add(parameter);
                dr = cmd.ExecuteReader();
                if (dr != null && dr.HasRows)
                {
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
            finally
            {
                dr.Dispose();
                dr.Close();
                cmd.Dispose();
                if (oraConn.State == System.Data.ConnectionState.Open)
                {
                    oraConn.Dispose();
                    oraConn.Close();
                }
            }
        }
        public System.Data.DataSet GetAlreadySendFilesData(string sql)
        {
            var connection = new OracleConnection(conn);
            OracleDataAdapter da = null;
            System.Data.DataSet ds = null;
            try
            {
                connection.Open();
                da = new OracleDataAdapter(sql, connection);
                ds = new System.Data.DataSet();
                da.Fill(ds);
                return ds;
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(ServiceImpl), ex);
                throw ex;
            }
            finally
            {
                if (ds != null) ds.Dispose();
                if (da != null) da.Dispose();
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                    connection.Dispose();
                }
            }
        }
        #endregion

        #region Method
        private VendorSiteEntities GetDataContext()
        {
            var db = new VendorSiteEntities(GetEntityConnString(vConn));
            return db;
        }
        private string GetEntityConnString(string conn)
        {
            EntityConnectionStringBuilder entityBuilder = new EntityConnectionStringBuilder();
            //Metadata属性的值，是从生成的Config粘贴过来的
            entityBuilder.Metadata = "res://*/Model1.csdl|res://*/Model1.ssdl|res://*/Model1.msl";
            entityBuilder.ProviderConnectionString = vConn;
            entityBuilder.Provider = "Oracle.ManagedDataAccess.Client";
            return entityBuilder.ToString();
        }
        private string GetUserId(byte[] buffer)
        {
            StringBuilder sb = new StringBuilder();
            foreach (var b in buffer)
            {
                sb.Append(b.ToString("x2"));
            }
            return sb.ToString().ToUpper();
        }
        #endregion
    }

    [Serializable()]
    public class UserItem
    {
        public string ID { get; set; }
        public string SaMacCountName { get; set; }
        public string ObjectCategory { get; set; }
        public string Mail { get; set; }
        public string Name { get; set; }
        public string Department { get; set; }
        public string DistinguishedName { get; set; }
        public string ObjectClass { get; set; }
        public string UserPrincipalName { get; set; }
        public string Upload_Folder { get; set; }
        public string Download_Folder { get; set; }
        public string Domain_Name { get; set; }
        public string Title { get; set; }
        public string Company { get; set; }
        public string SN { get; set; }
        public string Telephone_Number { get; set; }
        public string Postal_Code { get; set; }
        public string Given_Name { get; set; }
        public string Country { get; set; }
        public string City { get; set; }
        public string Street_Address { get; set; }
        public string State { get; set; }
        public string Password { get; set; }
        public string WebPDMGroups { get; set; }
        public string First_Name { get; set; }
        public string Last_Name { get; set; }
        public string Direct_Phone { get; set; }
        public string Fax_Number { get; set; }
        public string Relation_To_Company { get; set; }
        public string Reason_For_Account { get; set; }
        public string Print_Name { get; set; }
        public string Intra_Print_Name { get; set; }
        public int? IsAcive { get; set; }
        public DateTime? Logon_Time { get; set; }
        public string DisplayName { get; set; }

        public byte[] ORA_ASPNET_USERID { get; set; }
    }

    public class ManualByMail
    {
        public int ID { get; set; }
        public string Title { get; set; }
        public string SubNodeSEQ { get; set; }
        public int PID { get; set; }
    }

    public class SyncUser
    {
        public string Account { get; set; }
        public string Name { get; set; }
        public char Enabled { get; set; }
        public string Email { get; set; }
        public char Notification_Enabled { get; set; }
        public DateTime Last_Notified_Time { get; set; }
        public DateTime Last_Activity_Time { get; set; }
        public int Inactive_Window_Minutes { get; set; }
        public string Machine_Name { get; set; }
    }

    public class Asp_Users
    {
        public Guid APPLICATIONID { get; set; }
        public Guid USERID { get; set; }
        public string USERNAME { get; set; }
        public string LOWEREDUSERNAME { get; set; }
        public string MOBILEALIAS { get; set; }
        public int ISANONYMOUS { get; set; }
        public DateTime LASTACTIVITYDATE { get; set; }
    }

    public class OAsp_Membership
    {
        public byte[] UserID { get; set; }

        public string LoweredEmail { get; set; }
    }
}
