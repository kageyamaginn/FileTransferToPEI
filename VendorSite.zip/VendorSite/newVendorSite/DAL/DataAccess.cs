﻿using System;

namespace DAL
{
    public sealed class DataAccess
    {
        private static IService srv;

        private DataAccess() { }

        public static IService GetService()
        {
            if (srv == null)
            {
                srv = new ServiceImpl();
            }
            return srv;
        }
    }
}
