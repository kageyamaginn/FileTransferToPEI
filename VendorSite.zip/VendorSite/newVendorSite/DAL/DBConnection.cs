﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data.Odbc;
using System.IO;
using Oracle.ManagedDataAccess.Client;

// ///////////////////////////////////////////////////////////////////////////////////////////////////
//
//  Class:          DBConnection
//  Description:    This class encasulates all functionality regarding a database connection.
//                  It supports connecting through ODBC, Oracle, and SQL Server drivers.  A reference
//                  for these System.Data namespaces must be added in order to use this class.  Here is 
//                  the class definition:
//  
//                  Properties:
//                          Instance:       Returns connected database.
//                          OnTransaction:  Returns true or false, whether there is a transaction for 
//                                          the connection.
//                          DBState:        Returns the connection database state.
//
//                  Methods:
//                          Connect:        Connects to the specified database.
//                          Disconnect:     Disconnects from the database.
//                          StartTrans:     Start a database transaction.
//                          RollBackTrans:  Roll back a database transaction.
//                          CommitTrans:    Commit a transaction.
//                          GetDataReader:  Returns a datareader based on the passed command.
//                          ExecuteCmd:     Execute the passed command object.
//                          
// ///////////////////////////////////////////////////////////////////////////////////////////////////
//
//  Maintenance Log
//  Date            Description
//
// ///////////////////////////////////////////////////////////////////////////////////////////////////


namespace DAL
{
    public class DBConnection
    {
        #region Enums

        public enum DBDriverTypes
        {
            ODBC,
            Oracle,
            SQLServer,
            ODPNET
        }

        public enum Database
        {
            JDA,
            WMS1,
            JPRD,
            SPRD,
            SEWN,
            EDEV,
            PEIPRD1,
            PRDA,
            RMS,
            GENTRAN,
            WEBPDM,
            NONE
        }

        #endregion

        #region Class Const and Variables

        //we can have up to three DB connection types...
        private SqlConnection SQLConn;
        private OdbcConnection ODBCConn;
        private OracleConnection ODPConn;

        private SqlTransaction SQLTrans;
        private OdbcTransaction ODBCTrans;
        private OracleTransaction OdpTrans;

        private bool bolInTransaction = false;

        private Database DBInstance;
        private DBDriverTypes DBDriver;

        private string connectionString;

        #endregion

        #region Constructors & Destructors

        // Simple constructor with just the database type...
        public DBConnection(Database ConnectTo)
        {
            bolInTransaction = false;
            createConnection(DBDriverTypes.ODBC);
            Connect(ConnectTo);

        }

        public string ConnectionString
        {
            get { return connectionString; }
        }
        public DBConnection(Database ConnectTo, DBDriverTypes DBDriver)
        {
            bolInTransaction = false;
            createConnection(DBDriver);
            Connect(ConnectTo);

        }

        ~DBConnection()
        {
            switch (DBDriver)
            {
                case DBDriverTypes.ODBC:
                    if (ODBCConn != null)
                    {
                        if (bolInTransaction) { ODBCTrans.Rollback(); ODBCTrans.Dispose(); ODBCTrans = null; }
                        if (ODBCConn.State != System.Data.ConnectionState.Closed) ODBCConn.Close();
                        ODBCConn.Dispose(); ODBCConn = null;

                    }
                    break;

                case DBDriverTypes.SQLServer:
                    if (SQLConn != null)
                    {
                        if (bolInTransaction) { SQLTrans.Rollback(); SQLTrans.Dispose(); SQLTrans = null; }
                        if (SQLConn.State != System.Data.ConnectionState.Closed) SQLConn.Close();
                        SQLConn.Dispose(); SQLConn = null;

                    }
                    break;

                case DBDriverTypes.ODPNET:
                    if (ODPConn != null)
                    {
                        if (bolInTransaction) { OdpTrans.Rollback(); OdpTrans.Dispose(); OdpTrans = null; }
                        if (ODPConn.State != System.Data.ConnectionState.Closed) ODPConn.Close();
                        ODPConn.Dispose(); ODPConn = null;
                    }
                    break;
            }
        }

        #endregion

        #region Properties

        public Database Instance
        {
            get
            {
                return DBInstance;
            }

        }

        public bool OnTransaction
        {
            get
            {
                return bolInTransaction;

            }

        }

        public System.Data.ConnectionState DBState
        {
            get
            {
                switch (DBDriver)
                {
                    case DBDriverTypes.ODBC:
                        return ODBCConn.State;

                    case DBDriverTypes.ODPNET:
                        return ODPConn.State;

                    default:
                        //DBDriverTypes.SQLServer:
                        return SQLConn.State;

                }

            }

        }

        #endregion

        #region Methods

        private void createConnection(DBDriverTypes DBConnDriver)
        {
            DBDriver = DBConnDriver;
            switch (DBConnDriver)
            {
                case DBDriverTypes.ODBC:
                    ODBCConn = new OdbcConnection();
                    break;

                case DBDriverTypes.ODPNET:
                    ODPConn = new OracleConnection();
                    break;

                case DBDriverTypes.SQLServer:
                    SQLConn = new SqlConnection();
                    break;

                default:
                    throw new Exception("cannot create connection object for the specified (unknown) database driver");

            }

        }

        // Connect to the specified database using the specified driver...
        public Boolean Connect(Database DB)
        {
            Microsoft.Win32.RegistryKey rkPEI; String strRegKey, strDBName;
            Microsoft.Win32.RegistryKey rkDSN;

            DBInstance = DB;
            // Lets determine where do we need to go to get the DB credentials...
            switch (DB)
            {
                case Database.JDA:
                    strRegKey = "Software\\PEI\\JDA";
                    strDBName = "JDA";
                    break;
                case Database.GENTRAN:
                    strRegKey = "Software\\PEI\\GENTRAN";
                    strDBName = "GENTRAN";
                    break;

                case Database.WMS1:
                    strRegKey = "Software\\PEI\\PKMS";
                    strDBName = "Supreme";
                    break;

                case Database.JPRD:
                    strRegKey = "Software\\PEI\\JPKMS";
                    strDBName = "Jantzen";
                    break;

                case Database.SPRD:
                    strRegKey = "Software\\PEI\\SPKMS";
                    strDBName = "Salant";
                    break;

                case Database.SEWN:
                    strRegKey = "Software\\PEI\\SEWN";
                    strDBName = "Essentus";
                    break;

                case Database.PEIPRD1:
                    strRegKey = "Software\\PEI\\PEIPRD1_ERET";
                    strDBName = "PEIPRD1";
                    break;

                case Database.PRDA:
                    strRegKey = "Software\\PEI\\ORAFIN";
                    strDBName = "Oracle Financials";
                    break;

                case Database.RMS:
                    strRegKey = "Software\\PEI\\RMS";
                    strDBName = "RMS-RETEK";
                    break;

                case Database.WEBPDM:
                    strRegKey = "Software\\PEI\\WEBPDM";
                    strDBName = "WebPDM";
                    break;

                case Database.NONE:
                    return false;

                default:
                    throw new Exception("there is no connection settings for [" + DB.ToString() + "] database in PEI.DBConnection class");

            }

            rkPEI = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(strRegKey, false);
            if (rkPEI != null)
            {
                switch (DBDriver)
                {
                    case DBDriverTypes.ODBC:
                        ODBCConn = new OdbcConnection();
                        connectionString = "dsn=" + rkPEI.GetValue("ODBC DSN", "") + ";uid=" + rkPEI.GetValue("ODBC UID", "") + ";pwd=" + rkPEI.GetValue("ODBC PWD", "");
                        ODBCConn.ConnectionString = connectionString; //"dsn=" + rkPEI.GetValue("ODBC DSN", "") + ";uid=" + rkPEI.GetValue("ODBC UID", "") + ";pwd=" + rkPEI.GetValue("ODBC PWD", "");
                        try
                        {
                            ODBCConn.Open();

                        }
                        catch (Exception ex)
                        {
                            throw new Exception("failed to open ODBC connection to " + strDBName + " - " + ex.Message);
                        }
                        break;

                    case DBDriverTypes.ODPNET:
                        ODPConn = new OracleConnection();

                        rkDSN = Microsoft.Win32.Registry.LocalMachine.OpenSubKey("Software\\ODBC\\ODBC.INI\\" + rkPEI.GetValue("ODBC DSN", ""));
                        if (rkDSN != null)
                        {
                            connectionString = "Data Source=" + (rkDSN.GetValue("ServerName", "").ToString() != "" ? rkDSN.GetValue("ServerName", "") : rkDSN.GetValue("SERVER", "")) + "; User ID=" + rkPEI.GetValue("ODBC UID", "") + ";Password=" + rkPEI.GetValue("ODBC PWD", "") + "; ";
                            ODPConn.ConnectionString = connectionString;
                            try
                            {
                                ODPConn.Open();
                            }
                            catch (Exception ex)
                            {
                                throw new Exception("failed to open ODP.NET connection to " + strDBName + " - " + ex.Message);
                            }

                        }
                        break;

                    case DBDriverTypes.SQLServer:
                        throw new Exception("cannot connect to the specified SQL Server because this driver is currently not supported.");

                    default:
                        throw new Exception("cannot connect to the requested database because the specified driver has not been configured in the PEI.DBConnection class");

                }

            }
            return true;

        }

        // Disconnect... make sure you rollback any uncommitted transactions...
        public Boolean Disconnect()
        {
            switch (DBDriver)
            {
                case DBDriverTypes.ODBC:
                    if (bolInTransaction) { ODBCTrans.Rollback(); ODBCTrans.Dispose(); ODBCTrans = null; }
                    ODBCConn.Close(); ODBCConn.Dispose(); ODBCConn = null;
                    break;

                case DBDriverTypes.ODPNET:
                    if (bolInTransaction) { OdpTrans.Rollback(); OdpTrans.Dispose(); OdpTrans = null; }
                    ODPConn.Close(); ODPConn.Dispose(); ODPConn = null;
                    break;

                case DBDriverTypes.SQLServer:
                    if (bolInTransaction) { SQLTrans.Rollback(); SQLTrans.Dispose(); SQLTrans = null; }
                    SQLConn.Close(); SQLConn.Dispose(); SQLConn = null;
                    break;

                default:
                    throw new Exception("unknown data base connection driver");

            }
            DBInstance = Database.NONE;
            return true;

        }

        // GetDataReader for ODBC...
        public OdbcDataReader GetDataReader(OdbcCommand DBCommand)
        {
            // First check the driver type...
            if (DBDriver != DBDriverTypes.ODBC) throw new Exception("cannot retrieve data because the connection driver is not ODBC.");

            // Now if we are connected, and connection is open then execute the reader...
            if (ODBCConn != null && ODBCConn.State != System.Data.ConnectionState.Closed)
            {
                DBCommand.Connection = ODBCConn;
                if (bolInTransaction) DBCommand.Transaction = ODBCTrans;

                return DBCommand.ExecuteReader();

            }
            throw new Exception("cannot retrieve data because the database connection is closed.");

        }

        public long ExecuteCmd(OdbcCommand DBCommand)
        {
            // First check the driver type...
            if (DBDriver != DBDriverTypes.ODBC) throw new Exception("cannot execute command because the connection driver is not ODBC.");

            // Now if we are connected, and connection is open then execute the reader...
            if (ODBCConn != null && ODBCConn.State != System.Data.ConnectionState.Closed)
            {
                DBCommand.Connection = ODBCConn;
                if (bolInTransaction) DBCommand.Transaction = ODBCTrans;

                return DBCommand.ExecuteNonQuery();

            }
            throw new Exception("cannot execute command because the database connection is closed.");

        }

        // GetDataReader for ODP...
        public OracleDataReader GetDataReader(OracleCommand DBCommand)
        {
            // First check the driver type...
            if (DBDriver != DBDriverTypes.ODPNET) throw new Exception("cannot retrieve data because the connection driver is not ODP.");

            // Now if we are connected, and connection is open then execute the reader...
            if (ODPConn != null && ODPConn.State != System.Data.ConnectionState.Closed)
            {
                DBCommand.Connection = ODPConn;
                if (bolInTransaction) DBCommand.Transaction = OdpTrans;

                return DBCommand.ExecuteReader();

            }
            throw new Exception("cannot retrieve data because the database connection is closed.");

        }

        public long ExecuteCmd(OracleCommand DBCommand)
        {
            // First check the driver type...
            if (DBDriver != DBDriverTypes.ODPNET) throw new Exception("cannot execute command because the connection driver is not ODP.");

            // Now if we are connected, and connection is open then execute the reader...
            if (ODPConn != null && ODPConn.State != System.Data.ConnectionState.Closed)
            {
                DBCommand.Connection = ODPConn;
                if (bolInTransaction) DBCommand.Transaction = OdpTrans;

                return DBCommand.ExecuteNonQuery();

            }
            throw new Exception("cannot execute command because the database connection is closed.");

        }

        // GetDataReader for SQL...
        public SqlDataReader GetDataReader(SqlCommand DBCommand)
        {
            // First check the driver type...
            if (DBDriver != DBDriverTypes.SQLServer) throw new Exception("cannot retrieve data because the connection driver is not SQL Server.");

            // Now if we are connected, and connection is open then execute the reader...
            if (SQLConn != null && SQLConn.State != System.Data.ConnectionState.Closed)
            {
                DBCommand.Connection = SQLConn;
                if (bolInTransaction) DBCommand.Transaction = SQLTrans;

                return DBCommand.ExecuteReader();

            }
            throw new Exception("cannot retrieve data because the database connection is closed.");

        }

        public long ExecuteCmd(SqlCommand DBCommand)
        {
            // First check the driver type...
            if (DBDriver != DBDriverTypes.SQLServer) throw new Exception("cannot execute command because the connection driver is not SQL Server.");

            // Now if we are connected, and connection is open then execute the reader...
            if (SQLConn != null && SQLConn.State != System.Data.ConnectionState.Closed)
            {
                DBCommand.Connection = SQLConn;
                if (bolInTransaction) DBCommand.Transaction = SQLTrans;

                return DBCommand.ExecuteNonQuery();

            }
            throw new Exception("cannot execute command because the database connection is closed.");

        }

        public void StartTrans()
        {
            // First check if we are already in a transaction...
            if (bolInTransaction) return;

            // If we are here, then we are not...
            switch (DBDriver)
            {
                case DBDriverTypes.ODBC:
                    ODBCTrans = ODBCConn.BeginTransaction();
                    break;

                case DBDriverTypes.ODPNET:
                    OdpTrans = ODPConn.BeginTransaction();
                    break;

                case DBDriverTypes.SQLServer:
                    SQLTrans = SQLConn.BeginTransaction();
                    break;

                default:
                    throw new Exception("could not start transaction for the unknown data base connection driver");

            }
            bolInTransaction = true;

        }

        public void RollBackTrans()
        {
            // First check if we are already in a transaction...
            if (!bolInTransaction) return;

            // If we are here, then we are...
            switch (DBDriver)
            {
                case DBDriverTypes.ODBC:
                    ODBCTrans.Rollback(); ODBCTrans = null;
                    break;

                case DBDriverTypes.ODPNET:
                    OdpTrans.Rollback(); OdpTrans = null;
                    break;

                case DBDriverTypes.SQLServer:
                    SQLTrans.Rollback(); SQLTrans = null;
                    break;

                default:
                    throw new Exception("could not rollback transaction for the unknown data base connection driver");

            }
            bolInTransaction = false;

        }

        public void CommitTrans()
        {
            switch (DBDriver)
            {
                case DBDriverTypes.ODBC:
                    if (bolInTransaction) { ODBCTrans.Commit(); ODBCTrans.Dispose(); ODBCTrans = null; }
                    break;

                case DBDriverTypes.ODPNET:
                    if (bolInTransaction) { OdpTrans.Commit(); OdpTrans.Dispose(); OdpTrans = null; }
                    break;

                case DBDriverTypes.SQLServer:
                    if (bolInTransaction) { SQLTrans.Commit(); SQLTrans.Dispose(); SQLTrans = null; }
                    break;

            }
            bolInTransaction = false;

        }

        public Object GetConnection()
        {
            if (DBDriver == DBDriverTypes.ODBC)
            {
                return ODBCConn;
            }
            else if (DBDriver == DBDriverTypes.ODPNET)
            {
                return ODPConn;
            }
            else
            {
                return SQLConn;
            }
        }

        #endregion

    }

}
