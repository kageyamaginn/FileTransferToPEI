﻿using System;
using System.Collections.Generic;
using System.Text;
using Pei.DirectoryServices;
using DAL;
using System.Net;
using Newtonsoft.Json;
using System.IO;
using Newtonsoft.Json.Linq;

namespace PEI.Web
{
    public partial class ChangePassword : PageBase
    {
        string UserId
        {
            get
            {
                var uid = ViewState["UserId"];
                return uid != null ? (string)uid : String.Empty;
            }
            set
            {
                ViewState["UserId"] = value;
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                var identify = Request["flag"];
                if (identify == null) return;
                VerifyActivateMailLink(identify);
            }
        }

        protected void VerifyActivateMailLink(string flag)
        {
            var result = BllSrv.GetLogonTimeByFlag(flag);
            if (result == null)
            {
                warningTip.Visible = true;
                lblErrorMsg.Text = "* The activate link has been invalid.";
                return;
            }
            var expiredTime = Convert.ToDateTime(result.Logon_Time).AddDays(1); //** 
            if (expiredTime < DateTime.Now)
            {
                warningTip.Visible = true;
                lblErrorMsg.Text = "* The activate link had been over the can operates time.";
                return;
            }
            try
            {
                UserId = GetUserID(result.ORA_ASPNET_USERID);
                pnlResetPassword.Visible = true;
                pnlSendMail.Visible = false;
                pnlVerifyMail.Visible = false;
            }
            catch (Exception ex)
            {
                lblErrorMsg.Text = "* Unknow error.";
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            var mail = txbMail.Text.Trim().ToLower();
            string userid = UserName.Value.ToLower();
            if (string.IsNullOrEmpty(userid))
            {
                warningTip.Visible = true;
                lblErrorMsg.Text = "* Account does not exist.";
                return;
            }
            try
            {
                var pwd = Guid.NewGuid().ToString();
                var logonTime = DateTime.Now;
                var isUpdateUserIdentify = BllSrv.UpdateUserFlagByID(pwd, logonTime, userid);
                if (isUpdateUserIdentify)
                {
                    var sendFrom = "SOFTWARE.SUPPORT@PERY.COM";
                    var sendSubject = "Reset password notice";
                    var sendBody = "From PEI vendor site, " +
                                   "reset password service.<br /> " +
                                   "Please click this link " + Utility.VendorSiteUrl + "/ChangePassword.aspx?flag=" + pwd + " " +
                                   "in order to activate operates.";
                    var sendTo = new List<string> { mail };
                    Utility.Send(sendFrom, sendSubject, sendBody, true, false, sendTo, null, null, null);
                    LogService.WriteInfoLog(typeof(ChangePassword), String.Format("Sent mail to {0}, by reset password operates.", sendTo[0]));
                    pnlSendMail.Visible = true;
                    pnlVerifyMail.Visible = pnlResetPassword.Visible = false;
                }
                else
                {
                    warningTip.Visible = true;
                    lblErrorMsg.Text = "* Unknow error";
                    return;
                }
            }
            catch (Exception ex)
            {
                warningTip.Visible = true;
                lblErrorMsg.Text = "* Server error";
                LogService.WriteErrorLog(typeof(ChangePassword), ex.ToString());
                return;
            }
        }

        string GetUserID(byte[] bytes)
        {
            var sb = new StringBuilder();
            for (int i = 0; i < bytes.Length; i++)
            {
                var singleByte = bytes[i];
                if (singleByte < 16)
                {
                    sb.Append("0");
                    sb.AppendFormat(Convert.ToString(singleByte, 16));
                    continue;
                }
                sb.Append(Convert.ToString(singleByte, 16));
            }
            return sb.ToString().ToUpper();
        }

        protected void btnResetPassword_Click(object sender, EventArgs e)
        {
            string flag = Request["flag"];
            var result = BllSrv.GetLogonTimeByFlag(flag);
            var username = txbUserAccount.Text.Trim().ToLower();
            if (result.ID.ToLower() != username)
            {
                pnlCPWarning.Visible = true;
                lblCPErrorMsg.Text = "* The activate link has been invalid.";
                return;
            }
            var newPwd = txbNewPassword.Text.Trim();


            ErrorMsg cResult = ErrorMsg.Unknown;
            try
            {
                cResult = Global.adHelper.SetPassword(username, newPwd);
            }
            catch (Exception ex)
            {
                if (SetPassword(username, newPwd) == "0")
                {
                    var isUpdateUserIdentify = BllSrv.UpdateUserFlagByUserID("", DateTime.MinValue, UserId);
                    pnlCPWarning.Visible = true;
                    lblCPErrorMsg.Text = String.Format("* Password has been changed. <a href=\"{0}\">Login</a>", "https://sync.pery.com/VendorSite/Login.aspx");
                    LogService.WriteInfoLog(typeof(ChangePassword), String.Format("User {0} has been changed password.", username));
                    return;
                }
                pnlCPWarning.Visible = true;
                LogService.WriteErrorLog(typeof(ChangePassword), ex);
                if (ex.Message.IndexOf("(exception", StringComparison.InvariantCultureIgnoreCase) > -1)
                    lblCPErrorMsg.Text = ex.Message.Substring(0, ex.Message.IndexOf("(exception", StringComparison.InvariantCultureIgnoreCase));
                else
                    lblCPErrorMsg.Text = ex.Message;
                return;
            }
            switch (cResult)
            {
                case ErrorMsg.None:
                    var isUpdateUserIdentify = BllSrv.UpdateUserFlagByUserID("", DateTime.MinValue, UserId);
                    pnlCPWarning.Visible = true;
                    lblCPErrorMsg.Text = String.Format("* Password has been changed. <a href=\"{0}\">Login</a>", "Login.aspx");
                    LogService.WriteInfoLog(typeof(ChangePassword), String.Format("User {0} has been changed password.", username));
                    break;
                case ErrorMsg.Not_Administrator:
                    pnlCPWarning.Visible = true;
                    lblCPErrorMsg.Text = "* The user is not administrator.";
                    LogService.WriteInfoLog(typeof(ChangePassword), String.Format("User {0} reset password fail, reason: {1}", username, lblCPErrorMsg.Text));
                    break;
                case ErrorMsg.Duplicate_Name:
                    pnlCPWarning.Visible = true;
                    lblCPErrorMsg.Text = "* Duplicated user folder name.";
                    LogService.WriteInfoLog(typeof(ChangePassword), String.Format("User {0} reset password fail, reason: {1}", username, lblCPErrorMsg.Text));
                    break;
                case ErrorMsg.Duplicate_Account:
                    pnlCPWarning.Visible = true;
                    lblCPErrorMsg.Text = "* Duplicated account.";
                    LogService.WriteInfoLog(typeof(ChangePassword), String.Format("User {0} reset password fail, reason: {1}", username, lblCPErrorMsg.Text));
                    break;
                case ErrorMsg.Name_Not_Found:
                    pnlCPWarning.Visible = true;
                    lblCPErrorMsg.Text = "* The user account does not found.";
                    LogService.WriteInfoLog(typeof(ChangePassword), String.Format("User {0} reset password fail, reason: {1}", username, lblCPErrorMsg.Text));
                    break;
                case ErrorMsg.User_Disabled:
                    pnlCPWarning.Visible = true;
                    lblCPErrorMsg.Text = "* The user has been disabled.";
                    LogService.WriteInfoLog(typeof(ChangePassword), String.Format("User {0} reset password fail, reason: {1}", username, lblCPErrorMsg.Text));
                    break;
                case ErrorMsg.User_Not_Disabled:
                    pnlCPWarning.Visible = true;
                    lblCPErrorMsg.Text = "* The user is not disabled.";
                    LogService.WriteInfoLog(typeof(ChangePassword), String.Format("User {0} reset password fail, reason: {1}", username, lblCPErrorMsg.Text));
                    break;
                case ErrorMsg.Invalid_Account:
                    pnlCPWarning.Visible = true;
                    lblCPErrorMsg.Text = "* Invalid user account.";
                    LogService.WriteInfoLog(typeof(ChangePassword), String.Format("User {0} reset password fail, reason: {1}", username, lblCPErrorMsg.Text));
                    break;
                case ErrorMsg.Unknown:
                    pnlCPWarning.Visible = true;
                    lblCPErrorMsg.Text = "* Unknown exception.";
                    LogService.WriteInfoLog(typeof(ChangePassword), String.Format("User {0} reset password fail, reason: {1}", username, lblCPErrorMsg.Text));
                    break;
            }
        }

        private string SetPassword(string username, string newPwd)
        {
            SetPassword model = new SetPassword()
            {
                account = username,
                password = newPwd
            };
            string url = "https://plm.pery.com/ADSvc/odata/SetPassword";

            HttpWebRequest req = (HttpWebRequest)HttpWebRequest.Create(url);
            req.Method = "POST";
            string param = JsonConvert.SerializeObject(model);
            byte[] bs = Encoding.ASCII.GetBytes(param);
            req.Method = "POST";
            req.ContentType = "application/json; charset=utf-8";
            req.ContentLength = bs.Length;
            using (Stream reqStream = req.GetRequestStream())
            {
                reqStream.Write(bs, 0, bs.Length);
            }
            using (WebResponse wr = req.GetResponse())
            {
                //在这里对接收到的页面内容进行处理
                string html = new StreamReader(wr.GetResponseStream(), Encoding.GetEncoding("utf-8")).ReadToEnd();
                JObject jo = (JObject)JsonConvert.DeserializeObject(html);
                if (jo["value"].ToString() == "CHANGEPASSWORD SUCCEED")
                {
                    return "0";
                }
                else
                {
                    return html;
                }
            }
        }
    }
    public class SetPassword
    {
        public string account { get; set; }
        public string password { get; set; }
    }
}