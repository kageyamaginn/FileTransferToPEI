﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DAL;
using DirectoryServices;
using System.Configuration;

namespace PEI.Web.Account
{
    public partial class AccountOperation : PageBase
    {
        public const string SyncUserPermission = "SYNC_USER_SUPREME";
        //public const string ExternalUserIDPrefix = "localhost__";
        public string syncUserNameBySupremeDomain;
        public string syncUserNameByExternalDomain;
        private string SQLSentence
        {
            get
            {
                var sql = ViewState["sqlSentence"];
                return sql != null ? (string)sql : "";
            }
            set
            {
                ViewState["sqlSentence"] = value;
            }
        }

        private string SDetailID
        {
            get
            {
                var sID = ViewState["sDetailID"];
                return sID != null ? (string)sID : String.Empty;
            }
            set
            {
                ViewState["sDetailID"] = value;
            }
        }

        private string SPermissionID
        {
            get
            {
                var spID = ViewState["sPermissionID"];
                return spID != null ? (string)spID : String.Empty;
            }
            set
            {
                ViewState["sPermissionID"] = value;
            }
        }

        private string EDetailID
        {
            get
            {
                var eID = ViewState["eDetailID"];
                return eID != null ? (string)eID : String.Empty;
            }
            set
            {
                ViewState["eDetailID"] = value;
            }
        }

        private string EUpdateID
        {
            get
            {
                var euID = ViewState["eUpdateID"];
                return euID != null ? (string)euID : String.Empty;
            }
            set
            {
                ViewState["eUpdateID"] = value;
            }
        }

        private string ENewDetailID
        {
            get
            {
                var sndID = ViewState["eNewDetailID"];
                return sndID != null ? (string)sndID : String.Empty;
            }
            set
            {
                ViewState["eNewDetailID"] = value;
            }
        }

        private string EPermissionID
        {
            get
            {
                var epID = ViewState["ePermissionID"];
                return epID != null ? (string)epID : String.Empty;
            }
            set
            {
                ViewState["ePermissionID"] = value;
            }
        }

        public int PostbackCount
        {
            get
            {
                var count = ViewState["postbackCount"];
                return count != null ? (int)count : 1;
            }
            set
            {
                ViewState["postbackCount"] = value;
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session[Utility._sessionUserPermissions] == null)
            {
                Response.Redirect("~/NewsList.aspx", true);
            }
            else
            {
                string permissions = Session[Utility._sessionUserPermissions].ToString();
                if (!(permissions.Contains(SupremeUserPermissions.OPERATIONAL_UPDATES_EDIT) || permissions.Contains(SupremeUserPermissions.PERMISSION_EDIT)))
                {
                    Response.Redirect("~/NewsList.aspx", true);
                }
            }
            if (!IsPostBack)
            {
                //if (Session[Utility._aspUser] == null && Session[Utility._sessionUserPermissions] == null) Response.Redirect("~/NewsList.aspx", true);
                EachPanelOperate();
            }
            if (pnlSupremePermission.Visible)
                GetPermissionSetFieldPageTitleAndDefaultSyncFolder("Account Management - User Set Permissions", SPermissionID, VendorEnums.VendorsiteDomain.Supreme.ToString());
            else if (pnlExternalPermission.Visible)
                GetPermissionSetFieldPageTitleAndDefaultSyncFolder("Account Management - External User Set Permissions", EPermissionID, VendorEnums.VendorsiteDomain.External.ToString());
        }

        void GetPermissionSetFieldPageTitleAndDefaultSyncFolder(string pageTitle, string userID, string type)
        {
            Page.Title = pageTitle;
            var model = BllSrv.GetUserItemByID(userID);
            if (model != null)
            {
                if (type.Equals(VendorEnums.VendorsiteDomain.Supreme.ToString(), StringComparison.InvariantCultureIgnoreCase))
                    syncUserNameBySupremeDomain = !String.IsNullOrEmpty(model.Upload_Folder) ? model.Upload_Folder : "";
                else if (type.Equals(VendorEnums.VendorsiteDomain.External.ToString(), StringComparison.InvariantCultureIgnoreCase))
                    syncUserNameByExternalDomain = !String.IsNullOrEmpty(model.Upload_Folder) ? model.Upload_Folder : "";
            }
        }

        protected void EachPanelOperate()
        {
            //"Supreme Domain Detail"
            if (Request["sDetailID"] != null)
            {
                Page.Title = "Account Management - User Detail";
                SDetailID = Request["sDetailID"];
                pnlSupremeDetail.Visible = true;
                pnlSupremePermission.Visible = false;
                pnlExternalDetail.Visible = false;
                pnlExternalUpdate.Visible = false;
                pnlExternalDetail1.Visible = false;
                pnlExternalPermission.Visible = false;
                SQLSentence = @"select ID, Name, First_Name, Last_Name, Direct_Phone,
                                Mail, Print_Name, Intra_Print_Name, Company, Street_Address,
                                City, State, Postal_Code, Country, Telephone_Number, Fax_Number,
                                Reason_For_Account, Upload_Folder, IsActive, SaMacCountName from pei_custom.XX_Vendor_Users ";
                SQLSentence += String.Format("where ID = '{0}'", SDetailID);
                UserItem model = null;
                try
                {
                    model = BllSrv.GetUserDetailByID(SQLSentence);
                }
                catch (Exception ex)
                {
                    LogService.WriteErrorLog(typeof(AccountOperation), "Call method 'GetUserDetailByID' error by AccountOperation page: " + ex.Message);
                    Utility.ShowMessage(Page, "Obtain data exception, please later try again.");
                }
                if (model == null) return;
                ltlAccountName.Text = model.ID;
                //ltlAccountName.Text = model.ID.Replace("__", @"\");
                ltlCompanyName.Text = model.Company;
                ltlVendorName.Text = model.Name;
                ltlCompanyAddress.Text = model.Street_Address;
                ltlFirstName.Text = model.First_Name;
                ltlCity.Text = model.City;
                ltlLastName.Text = model.Last_Name;
                ltlState.Text = model.State;
                ltlDirectPhoneNumber.Text = model.Direct_Phone;
                ltlPostalCode.Text = model.Postal_Code;
                ltlEmailAddress.Text = model.Mail;
                ltlCountryRegion.Text = model.Country;
                ltlPersonRequestingSetup.Text = model.Print_Name;
                ltlTelephoneNumber.Text = model.Telephone_Number;
                ltlSupremeInternationalContact.Text = model.Intra_Print_Name;
                ltlFaxNumber.Text = model.Fax_Number;
                ltlReasonforAccount.Text = model.Reason_For_Account;
                ltlSyncFolderName.Text = model.Upload_Folder;
            }
            //"Supreme Domain Set Permissions"
            else if (Request["sPermissionID"] != null)
            {
                if (!Session[Utility._sessionUserPermissions].ToString().Contains(SupremeUserPermissions.PERMISSION_EDIT))
                {
                    Response.Redirect("~/NewsList.aspx", true);
                }
                Page.Title = "Account Management - User Set Permissions";
                SPermissionID = Request["sPermissionID"];
                pnlSupremeDetail.Visible = false;
                pnlSupremePermission.Visible = true;
                pnlExternalDetail.Visible = false;
                pnlExternalUpdate.Visible = false;
                pnlExternalDetail1.Visible = false;
                pnlExternalPermission.Visible = false;
                //ltlGivePermission.Text = SPermissionID.Replace("__", @"\");
                ltlGivePermission.Text = SPermissionID;
                List<XX_VENDOR_PERMISSIONS> list = null;
                try
                {
                    list = BllSrv.GetPermissionsByUserIdentity((int)VendorEnums.UserDomain.Supreme).ToList();
                    cblPermissionItem.DataSource = list;
                    cblPermissionItem.DataTextField = "Name";
                    cblPermissionItem.DataValueField = "ID";
                    cblPermissionItem.DataBind();
                }
                catch (Exception ex)
                {
                    LogService.WriteErrorLog(typeof(AccountOperation), "Call method 'GetPermissionsByUserIdentity' error by AccountOperation page: " + ex.Message);
                    Utility.ShowMessage(Page, "Obtain data exception, please later try again.");
                    cblPermissionItem.DataSource = null;
                }

                string[] permissions = null;
                List<string> permissionList = null;
                try
                {
                    permissionList = BllSrv.GetCurrentUserPermissions(SPermissionID).ToList();
                    var currentUserNameSubStr = SPermissionID;
                    var account = CreateUser.syncUserAccountPrefix + currentUserNameSubStr;
                    var isExist = (BllSrv.IsExistSyncUser(account)) || (BllSrv.IsExistSyncUser(currentUserNameSubStr));
                    if (isExist) permissionList.Add(SyncUserPermission);
                }
                catch (Exception ex)
                {
                    LogService.WriteErrorLog(typeof(AccountOperation), "Call method 'GetCurrentUserPermissions' error by AccountOperation page: " + ex.Message);
                    Utility.ShowMessage(Page, "Obtain data exception, please later try again.");
                }

                if ((list == null) || (permissionList == null)) return;
                for (int i = 0; i < list.Count; i++)
                {
                    foreach (var permission in permissionList)
                    {
                        if (cblPermissionItem.Items[i].Value.Equals(permission, StringComparison.InvariantCultureIgnoreCase)) cblPermissionItem.Items[i].Selected = true;
                    }
                }
                var model = BllSrv.GetUserItemByID(SPermissionID);
                if (model != null)
                {
                    syncUserNameBySupremeDomain = !String.IsNullOrEmpty(model.Upload_Folder) ? model.Upload_Folder : "";
                }
            }
            //"External Users Detail"
            else if (Request["eDetailID"] != null)
            {
                Page.Title = "Account Management - External User Detail";
                EDetailID = Request["eDetailID"];
                pnlSupremeDetail.Visible = false;
                pnlSupremePermission.Visible = false;
                pnlExternalDetail.Visible = true;
                pnlExternalUpdate.Visible = false;
                pnlExternalDetail1.Visible = false;
                pnlExternalPermission.Visible = false;
                SQLSentence = @"select ID, Name, First_Name, Last_Name, Direct_Phone,
                                Mail, Print_Name, Intra_Print_Name, Company, Street_Address,
                                City, State, Postal_Code, Country, Telephone_Number, Fax_Number,
                                Reason_For_Account, Upload_Folder, IsActive, SaMacCountName from pei_custom.XX_Vendor_Users ";
                SQLSentence += String.Format("where ID = '{0}'", EDetailID);
                UserItem model = null;
                try
                {
                    model = BllSrv.GetUserDetailByID(SQLSentence);
                }
                catch (Exception ex)
                {
                    LogService.WriteErrorLog(typeof(AccountOperation), "Call method 'GetUserDetailByID' error by AccountOperation page: " + ex.Message);
                    Utility.ShowMessage(Page, "Obtain data exception, please later try again.");
                }
                if (model == null) return;
                ltlExternalAccountName.Text = model.SaMacCountName;
                ltlExternalCompanyName.Text = model.Company;
                ltlExternalVendorName.Text = model.Name;
                ltlExternalCompanyAddress.Text = model.Street_Address;
                ltlExternalFirstName.Text = model.First_Name;
                ltlExternalCity.Text = model.City;
                ltlExternalLastName.Text = model.Last_Name;
                ltlExternalState.Text = model.State;
                ltlExternalDirectPhoneNumber.Text = model.Direct_Phone;
                ltlExternalPostalCode.Text = model.Postal_Code;
                ltlExternalEmailAddress.Text = model.Mail;
                ltlExternalCountryRegion.Text = model.Country;
                ltlExternalPersonRequestingSetup.Text = model.Print_Name;
                ltlExternalTelephoneNumber.Text = model.Telephone_Number;
                ltlExternalSupremeInternationalContact.Text = model.Intra_Print_Name;
                ltlExternalFaxNumber.Text = model.Fax_Number;
                ltlExternalReasonforAccount.Text = model.Reason_For_Account;
                ltlSyncFolderName.Text = model.Upload_Folder;
                btnExternalSettheAccountStatus.Text = model.IsAcive == -1 ? "Set the Account Active" : model.IsAcive == 1 ? "Set the Account InActive" : "Set the Account Active";
            }
            //"External Users Update"
            else if (Request["eUpdateID"] != null)
            {
                if (!Session[Utility._sessionUserPermissions].ToString().Contains(SupremeUserPermissions.OPERATIONAL_UPDATES_EDIT))
                {
                    Response.Redirect("~/NewsList.aspx", true);
                }
                new AccountManage() { Idx = 1 };
                Page.Title = "Account Management - External User Update Information";
                EUpdateID = Request["eUpdateID"];
                pnlSupremeDetail.Visible = false;
                pnlSupremePermission.Visible = false;
                pnlExternalDetail.Visible = false;
                pnlExternalUpdate.Visible = true;
                pnlExternalDetail1.Visible = false;
                pnlExternalPermission.Visible = false;
                SQLSentence = @"select ID, Name, First_Name, Last_Name, Direct_Phone,
                                Mail, Print_Name, Intra_Print_Name, Company, Street_Address,
                                City, State, Postal_Code, Country, Telephone_Number, Fax_Number,
                                Reason_For_Account, Upload_Folder, IsActive, SaMacCountName from pei_custom.XX_Vendor_Users ";
                SQLSentence += String.Format("where ID = '{0}'", EUpdateID);
                UserItem model = null;
                try
                {
                    model = BllSrv.GetUserDetailByID(SQLSentence);
                }
                catch (Exception ex)
                {
                    LogService.WriteErrorLog(typeof(AccountOperation), "Call method 'GetUserDetailByID' error by AccountOperation page: " + ex.Message);
                    Utility.ShowMessage(Page, "Obtain data exception, please later try again.");
                }
                if (model == null) return;
                ltlExternalUpdateAccountName.Text = model.SaMacCountName;
                txbExternalUpdateCompanyName.Text = model.Company;
                ltlExternalUpdateVendorName.Text = model.Name;
                txbExternalUpdateCompanyAddress.Text = model.Street_Address;
                txbExternalUpdateFirstName.Text = model.First_Name;
                txbExternalUpdateCity.Text = model.City;
                txbExternalUpdateLastName.Text = model.Last_Name;
                txbExternalUpdateState.Text = model.State;
                txbExternalUpdateDirectPhoneNumber.Text = model.Direct_Phone;
                txbExternalUpdatePostalCode.Text = model.Postal_Code;
                txbExternalUpdateEmailAddress.Text = model.Mail;
                txbExternalUpdateCountryRegion.Text = model.Country;
                txbExternalUpdatePersonRequestingSetup.Text = model.Print_Name;
                txbExternalUpdateTelephoneNumber.Text = model.Telephone_Number;
                txbExternalUpdateSupremeInternationalContact.Text = model.Intra_Print_Name;
                txbExternalUpdateFaxNumber.Text = model.Fax_Number;
                txbExternalUpdateReasonForAccount.Text = model.Reason_For_Account;
            }
            //"External Users Detail"
            else if (Request["eNewDetailID"] != null)
            {
                Page.Title = "Account Management - External User Detail";
                ENewDetailID = Request["eNewDetailID"];
                pnlSupremeDetail.Visible = false;
                pnlSupremePermission.Visible = false;
                pnlExternalDetail.Visible = false;
                pnlExternalUpdate.Visible = false;
                pnlExternalDetail1.Visible = true;
                pnlExternalPermission.Visible = false;
                SQLSentence = @"select ID, Name, First_Name, Last_Name, Direct_Phone,
                                Mail, Print_Name, Intra_Print_Name, Company, Street_Address,
                                City, State, Postal_Code, Country, Telephone_Number, Fax_Number,
                                Reason_For_Account, Upload_Folder, IsActive, SaMacCountName from pei_custom.XX_Vendor_Users ";
                SQLSentence += String.Format("where ID = '{0}'", ENewDetailID);
                UserItem model = null;
                try
                {
                    model = BllSrv.GetUserDetailByID(SQLSentence);
                }
                catch (Exception ex)
                {
                    LogService.WriteErrorLog(typeof(AccountOperation), "Call method 'GetUserDetailByID' error by AccountOperation page: " + ex.Message);
                    Utility.ShowMessage(Page, "Obtain data exception, please later try again.");
                }
                if (model == null) return;
                ltlExternalDetail1AccountName.Text = model.SaMacCountName;
                ltlExternalDetail1CompanyName.Text = model.Company;
                ltlExternalDetail1VendorName.Text = model.Name;
                ltlExternalDetail1CompanyAddress.Text = model.Street_Address;
                ltlExternalDetail1FirstName.Text = model.First_Name;
                ltlExternalDetail1City.Text = model.City;
                ltlExternalDetail1LastName.Text = model.Last_Name;
                ltlExternalDetail1State.Text = model.State;
                ltlExternalDetail1DirectPhoneNumber.Text = model.Direct_Phone;
                ltlExternalDetail1PostalCode.Text = model.Postal_Code;
                ltlExternalDetail1EmailAddress.Text = model.Mail;
                ltlExternalDetail1CountryRegion.Text = model.Country;
                ltlExternalDetail1PersonRequestingSetup.Text = model.Print_Name;
                ltlExternalDetail1TelephoneNumber.Text = model.Telephone_Number;
                ltlExternalDetail1SupremeInternationalContact.Text = model.Intra_Print_Name;
                ltlExternalDetail1FaxNumber.Text = model.Fax_Number;
                ltlExternalDetail1ReasonforAccount.Text = model.Reason_For_Account;
                ltlExternalDetail1SyncFolderName.Text = model.Upload_Folder;
            }
            //"External Users Set Permissions"
            else if (Request["ePermissionID"] != null)
            {
                if (!Session[Utility._sessionUserPermissions].ToString().Contains(SupremeUserPermissions.PERMISSION_EDIT))
                {
                    Response.Redirect("~/NewsList.aspx", true);
                }
                //Page.Title = "Account Management - External User Set Permissions";
                EPermissionID = Request["ePermissionID"];
                pnlSupremeDetail.Visible = false;
                pnlSupremePermission.Visible = false;
                pnlExternalDetail.Visible = false;
                pnlExternalUpdate.Visible = false;
                pnlExternalDetail1.Visible = false;
                pnlExternalPermission.Visible = true;
                SQLSentence = @"select ID, Name, First_Name, Last_Name, Direct_Phone,
                                Mail, Print_Name, Intra_Print_Name, Company, Street_Address,
                                City, State, Postal_Code, Country, Telephone_Number, Fax_Number,
                                Reason_For_Account, Upload_Folder, IsActive, SaMacCountName from pei_custom.XX_Vendor_Users ";
                SQLSentence += String.Format("where ID = '{0}'", EPermissionID);

                UserItem model = null;
                try
                {
                    model = BllSrv.GetUserDetailByID(SQLSentence);
                }
                catch (Exception ex)
                {
                    LogService.WriteErrorLog(typeof(AccountOperation), "Call method 'GetUserDetailByID' occur exception by AccountOperation page: " + ex.Message);
                    Utility.ShowMessage(Page, "Obtain data exception, please later try again.");
                }
                ltlExternalPermissionLoginName.Text = model == null ? String.Empty : model.SaMacCountName;
                List<XX_VENDOR_PERMISSIONS> list = null;
                try
                {
                    list = BllSrv.GetPermissionsByUserIdentity((int)VendorEnums.UserDomain.External).ToList();
                    cblExternalPermission.DataSource = list;
                    cblExternalPermission.DataTextField = "Name";
                    cblExternalPermission.DataValueField = "ID";
                    cblExternalPermission.DataBind();
                }
                catch (Exception ex)
                {
                    LogService.WriteErrorLog(typeof(AccountOperation), "Call method 'GetPermissionsByUserIdentity' occur exception by AccountOperation page: " + ex.Message);
                    Utility.ShowMessage(Page, "Obtain data exception, please later try again.");
                    cblExternalPermission.DataSource = null;
                }
                string[] permissions = null;
                List<string> permissionList = null;
                try
                {
                    //permissions = BllSrv.GetCurrentUserPermissions(EPermissionID);
                    permissionList = BllSrv.GetCurrentUserPermissions(EPermissionID).ToList();
                    var account = CreateUser.syncUserAccountPrefix + ltlExternalPermissionLoginName.Text;
                    var isExist = (BllSrv.IsExistSyncUser(account)) || (BllSrv.IsExistSyncUser(ltlExternalPermissionLoginName.Text));
                    if (isExist) permissionList.Add(CreateUser.syncUserPermission);
                }
                catch (Exception ex)
                {
                    LogService.WriteErrorLog(typeof(AccountOperation), "Call method 'GetCurrentUserPermissions' occur exception by AccountOperation page: " + ex.Message);
                    Utility.ShowMessage(Page, "Obtain data exception, please later try again.");
                }
                if ((list == null) || (permissionList == null)) return;
                for (int i = 0; i < list.Count; i++)
                {
                    foreach (var permission in permissionList)
                    {
                        if (cblExternalPermission.Items[i].Value.Equals(permission, StringComparison.InvariantCultureIgnoreCase)) cblExternalPermission.Items[i].Selected = true;
                    }
                }
                var modelE = BllSrv.GetUserItemByID(EPermissionID);
                if (modelE != null)
                {
                    syncUserNameByExternalDomain = !String.IsNullOrEmpty(modelE.Upload_Folder) ? modelE.Upload_Folder : "";
                }
            }
            else
            {
                pnlSupremeDetail.Visible = pnlSupremePermission.Visible = pnlExternalDetail.Visible =
                    pnlExternalUpdate.Visible = pnlExternalDetail1.Visible = pnlExternalPermission.Visible = false;
                Response.Redirect("AccountManage.aspx", true);
            }
        }

        /// <summary>
        /// give permission to 'supreme' user
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSetPermission_Click(object sender, EventArgs e)
        {
            PostbackCount++;
            if (!String.IsNullOrEmpty(SPermissionID))
            {
                var isSuccessed = true;
                for (int i = 0; i < cblPermissionItem.Items.Count; i++)
                {
                    if (cblPermissionItem.Items[i].Selected)
                    {
                        if (cblPermissionItem.Items[i].Value.Equals(SyncUserPermission, StringComparison.InvariantCultureIgnoreCase))
                        {
                            UserItem model = BllSrv.GetUserItemByID(SPermissionID);
                            //var currentUserNameSubStr = SPermissionID.Substring(SPermissionID.IndexOf("__") + 2);
                            var currentUserNameSubStr = SPermissionID;
                            var account = CreateUser.syncUserAccountPrefix + currentUserNameSubStr;
                            var isExist = (BllSrv.IsExistSyncUser(account)) || (BllSrv.IsExistSyncUser(currentUserNameSubStr));
                            if (!isExist)
                            {
                                //model = BllSrv.GetUserItemByID(SPermissionID);
                                var xx_vendor_sync_user = new SyncUser
                                {
                                    //Account = CreateUser.syncUserAccountPrefix + model.SaMacCountName,
                                    Account = model.SaMacCountName,
                                    //Name = model.SaMacCountName,
                                    Name = String.Format("{0} {1}", model.First_Name, model.Last_Name).ToUpper(),
                                    Enabled = 'T',
                                    Email = model.Mail,
                                    Notification_Enabled = 'F',
                                    Last_Notified_Time = DateTime.Now,
                                    Last_Activity_Time = DateTime.Now,
                                    Inactive_Window_Minutes = 60,
                                    Machine_Name = ""
                                };
                                var row = BllSrv.CreateSyncUser(xx_vendor_sync_user);
                            }
                            var syncFolderField = Request.Params["txbSyncField"];
                            if (model.Upload_Folder.Equals(syncFolderField, StringComparison.InvariantCultureIgnoreCase)) continue;
                            var syncFolderExist = BllSrv.IsExistenceSyncFolder(syncFolderField);
                            if (syncFolderExist)
                            {
                                isSuccessed = false;
                                break;
                            }
                            var rowSync = BllSrv.UpdateSyncFolderName(syncFolderField, SPermissionID);
                            continue;
                        }
                        var isSelected = BllSrv.GetIsCurrentPermissionSelected(SPermissionID, cblPermissionItem.Items[i].Value);
                        if (!isSelected)
                        {
                            var model = new XX_VENDOR_USER_PERMISSION
                            {
                                PERMISSION_ID = cblPermissionItem.Items[i].Value,
                                USER_ID = SPermissionID,
                                CREATED_BY = (string)Session[Utility._aspUser], //HttpContext.Current.User.Identity.Name   //newchange= @"supreme\zhanm3"
                                CREATED_DATE = DateTime.Now
                            };
                            isSuccessed = BllSrv.SetPermission(model);
                        }
                    }
                    if (!cblPermissionItem.Items[i].Selected)
                    {
                        if (cblPermissionItem.Items[i].Value.Equals(SyncUserPermission, StringComparison.InvariantCultureIgnoreCase))
                        {
                            var currentUserNameSubStr = SPermissionID;
                            //var currentUserNameSubStr = SPermissionID.Substring(SPermissionID.IndexOf("__") + 2);
                            var account = CreateUser.syncUserAccountPrefix + currentUserNameSubStr;
                            //var isExist = BllSrv.IsExistSyncUser(account);
                            var isExist = false;
                            var actualAccount = "";
                            if (BllSrv.IsExistSyncUser(account))
                            {
                                actualAccount = account;
                                isExist = true;
                            }
                            else if (BllSrv.IsExistSyncUser(currentUserNameSubStr))
                            {
                                actualAccount = currentUserNameSubStr;
                                isExist = true;
                            }
                            if (isExist)
                            {
                                var row = BllSrv.DeleteSyncUser(actualAccount);
                            }
                            continue;
                        }
                        var isSelected = BllSrv.GetIsCurrentPermissionSelected(SPermissionID, cblPermissionItem.Items[i].Value);
                        if (isSelected)
                        {
                            isSuccessed = BllSrv.RemovePermission(SPermissionID, cblPermissionItem.Items[i].Value);
                        }
                    }
                }
                if (!isSuccessed)
                {
                    Utility.ShowMessage(Page, "Sync folder name has been existed, please input other name.");
                }
                else
                {
                    Session[Utility._sessionUserPermissions] = null;
                    Utility.ShowMessage(Page, "Operation Successed.", "../NewsList.aspx?source=AccountManage");
                }
                //if (isSuccessed)
                //{

                //}
            }
        }

        /// <summary>
        /// Update userinfo
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnExternalUpdateConfirmtoUpdate_Click(object sender, EventArgs e)
        {
            PostbackCount++;
            if (!String.IsNullOrEmpty(EUpdateID))
            {
                var model = new UserItem
                {
                    Company = txbExternalUpdateCompanyName.Text.Trim(),
                    Street_Address = txbExternalUpdateCompanyAddress.Text.Trim(),
                    First_Name = txbExternalUpdateFirstName.Text.Trim(),
                    City = txbExternalUpdateCity.Text.Trim(),
                    Last_Name = txbExternalUpdateLastName.Text.Trim(),
                    State = txbExternalUpdateState.Text.Trim(),
                    Direct_Phone = txbExternalUpdateDirectPhoneNumber.Text.Trim(),
                    Postal_Code = txbExternalUpdatePostalCode.Text.Trim(),
                    Mail = txbExternalUpdateEmailAddress.Text.Trim().ToLower(),
                    Country = txbExternalUpdateCountryRegion.Text.Trim(),
                    Print_Name = txbExternalUpdatePersonRequestingSetup.Text.Trim(),
                    Telephone_Number = txbExternalUpdateTelephoneNumber.Text.Trim(),
                    Intra_Print_Name = txbExternalUpdateSupremeInternationalContact.Text.Trim(),
                    Fax_Number = txbExternalUpdateFaxNumber.Text.Trim(),
                    Reason_For_Account = txbExternalUpdateReasonForAccount.Text.Trim(),
                    ID = EUpdateID
                };
                var isSuccessed = BllSrv.UpdateAccountData(model);
                if (isSuccessed)
                {
                    if (cbExternalUpdateResenMail.Checked == true)
                    {
                        var pwd = Guid.NewGuid().ToString();
                        var logonTime = DateTime.Now;
                        //成功后发个邮件
                        var isUpdateUserIdentify = BllSrv.UpdateUserFlagByID(pwd, logonTime, EUpdateID);
                        if (isUpdateUserIdentify)
                        {
                            var sendFrom = "SOFTWARE.SUPPORT@PERY.COM";
                            var sendSubject = "Reset password notice";
                            var sendBody = "From PEI vendor site, " +
                                           "reset password service.<br /> " +
                                           "Please click this link " + Utility.VendorSiteUrl + "/ChangePassword.aspx?flag=" + pwd + " " +
                                           "in order to activate operates.";
                            var sendTo = new List<string> { model.Mail };
                            Utility.Send(sendFrom, sendSubject, sendBody, true, false, sendTo, null, null, null);
                            LogService.WriteInfoLog(typeof(ChangePassword), String.Format("Sent mail to {0}, by update userInfo operates.", sendTo[0]));
                        }
                    }
                    Utility.ShowMessage(Page, "Update Successed.");
                }
                cbExternalUpdateResenMail.Checked = false;
            }
        }

        /// <summary>
        /// Give premission to external user
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnExternalPermissionSetPermissions_Click(object sender, EventArgs e)
        {
            PostbackCount++;
            if (!String.IsNullOrEmpty(EPermissionID))
            {
                var isSuccessed = true;
                for (int i = 0; i < cblExternalPermission.Items.Count; i++)
                {
                    if (cblExternalPermission.Items[i].Selected)
                    {
                        if (cblExternalPermission.Items[i].Value.Equals(CreateUser.syncUserPermission, StringComparison.InvariantCultureIgnoreCase))
                        {
                            //var model = BllSrv.GetUserItemByID(ExternalUserIDPrefix + ltlExternalPermissionLoginName.Text);
                            var model = BllSrv.GetUserItemByID(ltlExternalPermissionLoginName.Text);
                            var account = CreateUser.syncUserAccountPrefix + ltlExternalPermissionLoginName.Text;
                            var isExist = (BllSrv.IsExistSyncUser(account)) || (BllSrv.IsExistSyncUser(ltlExternalPermissionLoginName.Text));
                            if (!isExist)
                            {
                                //var model = BllSrv.GetUserItemByID(ExternalUserIDPrefix + ltlExternalPermissionLoginName.Text);
                                var xx_vendor_sync_user = new SyncUser
                                {
                                    //Account = CreateUser.syncUserAccountPrefix + model.SaMacCountName,
                                    Account = model.SaMacCountName,
                                    //Name = model.SaMacCountName,
                                    Name = String.Format("{0} {1}", model.First_Name, model.Last_Name).ToUpper(),
                                    Enabled = 'T',
                                    Email = model.Mail,
                                    Notification_Enabled = 'F',
                                    Last_Notified_Time = DateTime.Now,
                                    Last_Activity_Time = DateTime.Now,
                                    Inactive_Window_Minutes = 60,
                                    Machine_Name = ""
                                };
                                var row = BllSrv.CreateSyncUser(xx_vendor_sync_user);
                            }
                            var syncFolderField = Request.Params["txbSyncFieldExternal"];
                            if (model.Upload_Folder.Equals(syncFolderField, StringComparison.InvariantCultureIgnoreCase)) continue;
                            var syncFolderExist = BllSrv.IsExistenceSyncFolder(syncFolderField);
                            if (syncFolderExist)
                            {
                                isSuccessed = false;
                                break;
                            }
                            var rowSync = BllSrv.UpdateSyncFolderName(syncFolderField, EPermissionID);
                            continue;
                        }
                        var isSelected = BllSrv.GetIsCurrentPermissionSelected(EPermissionID, cblExternalPermission.Items[i].Value);
                        if (!isSelected)
                        {
                            var model = new XX_VENDOR_USER_PERMISSION
                            {
                                PERMISSION_ID = cblExternalPermission.Items[i].Value,
                                USER_ID = EPermissionID,
                                CREATED_BY = (string)Session[Utility._aspUser],   //HttpContext.Current.User.Identity.Name   //newchange=@"supreme\zhanm3"
                                CREATED_DATE = DateTime.Now
                            };
                            isSuccessed = BllSrv.SetPermission(model);
                        }
                    }
                    if (!cblExternalPermission.Items[i].Selected)
                    {
                        if (cblExternalPermission.Items[i].Value.Equals(CreateUser.syncUserPermission, StringComparison.InvariantCultureIgnoreCase))
                        {
                            var account = CreateUser.syncUserAccountPrefix + ltlExternalPermissionLoginName.Text;
                            //var isExist = BllSrv.IsExistSyncUser(account);
                            var isExist = false;
                            var actualAccount = "";
                            if (BllSrv.IsExistSyncUser(account))
                            {
                                actualAccount = account;
                                isExist = true;
                            }
                            else if (BllSrv.IsExistSyncUser(ltlExternalPermissionLoginName.Text))
                            {
                                actualAccount = ltlExternalPermissionLoginName.Text;
                                isExist = true;
                            }
                            if (isExist)
                            {
                                var row = BllSrv.DeleteSyncUser(actualAccount);
                            }
                            continue;
                        }
                        var isSelected = BllSrv.GetIsCurrentPermissionSelected(EPermissionID, cblExternalPermission.Items[i].Value);
                        if (isSelected)
                        {
                            isSuccessed = BllSrv.RemovePermission(EPermissionID, cblExternalPermission.Items[i].Value);
                        }
                    }
                }
                if (!isSuccessed)
                {
                    Utility.ShowMessage(Page, "Sync folder name has been existed, please input other name.");
                }
                else
                {
                    Session[Utility._sessionUserPermissions] = null;
                    Utility.ShowMessage(Page, "Operation Successed.", "../NewsList.aspx?source=AccountManage");
                }
                //if (isSuccessed)
                //{
                //}
            }
        }
    }
}