﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace PEI.Web.Account
{
    /// <summary>
    /// Summary description for ValidEmailAddressRepeatedly
    /// </summary>
    public class ValidEmailAddressRepeatedly : CreateUser, IHttpHandler
    {
        private string mail;

        public override void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/plain";
            if (context.Request["mail"] == null)
            {
                context.Response.Write("Argument data exception.");
                return;
            }
            mail = context.Request["mail"];
            if (!String.IsNullOrEmpty(mail))
            {
                var handleMailString = mail.Trim().ToLower();
                var result = false; //BllSrv.IsExistenceEmail(handleMailString);
                if (result)
                {
                    context.Response.Write("no:This email is already vendorsite user.");
                }
                else
                {
                    string userName = string.Empty;
                    List<DAL.OAsp_Membership> membership = BllSrv.GetUserIDsByEmail(handleMailString);
                    if (membership == null)
                    {
                        context.Response.Write("no:The email does not exist in the membership");
                    }
                    else
                    {
                        foreach (var item in membership)
                        {
                            DAL.Asp_Users user = BllSrv.GetAspUserByUserID(GetUserID(item.UserID));
                            //if (user.USERNAME.ToLower().StartsWith("dmz"))
                            //{
                                userName += user.USERNAME + "," + GetUserID(item.UserID) + "|";
                            //}
                        }
                        if (userName.Length <= 0)
                        {
                            context.Response.Write("no:The email does not exist in the membership");
                        }
                        else
                        {
                            context.Response.Write("ok:" + userName.Substring(0, userName.Length - 1));
                        }
                    }
                }
            }
        }

        public new bool IsReusable
        {
            get
            {
                return false;
            }
        }
        string GetUserID(byte[] bytes)
        {
            var sb = new StringBuilder();
            for (int i = 0; i < bytes.Length; i++)
            {
                var singleByte = bytes[i];
                if (singleByte < 16)
                {
                    sb.Append("0");
                    sb.AppendFormat(Convert.ToString(singleByte, 16));
                    continue;
                }
                sb.Append(Convert.ToString(singleByte, 16));
            }
            return sb.ToString().ToUpper(); //
        }
    }
}