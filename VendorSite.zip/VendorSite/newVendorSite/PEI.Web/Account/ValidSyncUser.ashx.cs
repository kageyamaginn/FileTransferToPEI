﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PEI.Web.Account
{
    /// <summary>
    /// Summary description for ValidSyncUser
    /// </summary>
    public class ValidSyncUser : CreateUser,IHttpHandler
    {
        private string name;
        public override void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/plain";
            if (context.Request["name"] == null)
            {
                context.Response.Write("Argument exception.");
                return;
            }
            name = context.Request["name"];
            if (!String.IsNullOrEmpty(name))
            {
                var handleUsernameString = name.Trim().ToLower();
                var existUser = BllSrv.IsExistenceSyncFolder(handleUsernameString);
                if (existUser) context.Response.Write("Has been exist folder.");
                else context.Response.Write("folder could be used.");
            }
            else
            {
                context.Response.Write("Value is empty.");
            }
        }
        public new bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}