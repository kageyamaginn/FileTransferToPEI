﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PEI.Web.Account
{
    /// <summary>
    /// Summary description for ValidUsernameRepeatedly
    /// </summary>
    public class ValidUsernameRepeatedly : CreateUser, IHttpHandler
    {
        private string username;

        public override void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/plain";
            if (context.Request["username"] == null)
            {
                context.Response.Write("Argument exception.");
                return;
            }
            username = context.Request["username"];
            if (!String.IsNullOrEmpty(username))
            {
                var handleUsernameString = username.Trim().ToLower();
                var existUser = BllSrv.IsExistenceUser(handleUsernameString);
                if (existUser) context.Response.Write("Has been exist user.");
                else context.Response.Write("Username could be used.");
            }
            else context.Response.Write("Value is empty.");
        }

        public new bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}