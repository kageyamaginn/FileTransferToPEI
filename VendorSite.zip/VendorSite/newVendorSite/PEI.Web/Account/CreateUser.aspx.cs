﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DAL;
using System.Text;
using System.Configuration;

namespace PEI.Web.Account
{
    public partial class CreateUser : PageBase
    {
        public const string syncUserPermission = "SYNC_USER_EXTERNAL";
        public const string syncUserAccountPrefix = @"VENDMAN\";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session[Utility._sessionUserPermissions] == null)
            {
                Response.Redirect("~/NewsList.aspx", true);
            }
            else
            {
                if (!((string)Session[Utility._sessionUserPermissions]).Contains(SupremeUserPermissions.PERMISSION_EDIT))
                {
                    Response.Redirect("~/NewsList.aspx", true);
                }
            }
            if (!IsPostBack)
            {
                if (Session[Utility._aspUser] == null && Session[Utility._sessionUserPermissions] == null) Response.Redirect("~/NewsList.aspx", true);
                BindCheckBoxList();
            }
        }

        protected void BindCheckBoxList()
        {
            List<XX_VENDOR_PERMISSIONS> list = null;
            try
            {
                list = BllSrv.GetPermissionsByUserIdentity((int)VendorEnums.UserDomain.External).ToList();
                cblPermissions.DataSource = list;
                cblPermissions.DataTextField = "Name";
                cblPermissions.DataValueField = "ID";
                cblPermissions.DataBind();
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(CreateUser), "Call method 'GetPermissionsByUserIdentity' occur exception by CreateUser page: " + ex.Message);
                Utility.ShowMessage(Page, "Obtain data exception, please later try again.");
                cblPermissions.DataSource = null;
            }

            if (list == null) return;
            for (int i = 0; i < list.Count; i++)
            {
                if (cblPermissions.Items[i].Value.Equals("3PL_MANUAL_LIST_EDIT", StringComparison.InvariantCultureIgnoreCase)) continue;
                if (cblPermissions.Items[i].Value.Equals("AUTOPUSHWEB_EDIT", StringComparison.InvariantCultureIgnoreCase)) continue;
                cblPermissions.Items[i].Selected = true;
            }
        }

        protected void btnAddUser_Click(object sender, EventArgs e)
        {
            string name = listSaMacCountName.Text.Trim().Split(',')[0];
            byte[] oraUserId = Encoding.Default.GetBytes(listSaMacCountName.Text.Trim().Split(',')[1]);
            var model = new UserItem
            {
                //ID = String.Format("localhost__{0}", txbSaMacCountName.Text.ToLower().Trim()),
                ID = name.ToLower(),
                SaMacCountName = name.ToLower().Split('\\')[1],
                ObjectCategory = "",
                Mail = txbMail.Text.Trim(),
                Name = txbFirstName.Text.Trim()+" "+ txbLastName.Text.Trim(),
                Department = "",
                DistinguishedName = "",
                ObjectClass = "",
                UserPrincipalName = "",
                Upload_Folder = !String.IsNullOrEmpty(txbDownloadFolder.Text) ? txbDownloadFolder.Text.Trim() : name.ToLower().Split('\\')[1],
                Download_Folder = !String.IsNullOrEmpty(txbDownloadFolder.Text) ? txbDownloadFolder.Text.Trim() : name.ToLower().Split('\\')[1],
                Domain_Name = name.ToLower().Split('\\')[0],
                Title = "",
                Company = txbCompany.Text.Trim(),
                SN = "",
                Telephone_Number = txbTelephoneNumber.Text.Trim(),
                Postal_Code = txbPostalCode.Text.Trim(),
                Given_Name = "",
                Country = txbCountry.Text.Trim(),
                City = txbCity.Text.Trim(),
                Street_Address = txbStreetAddress.Text.Trim(),
                State = txbState.Text.Trim(),
                Password = "",
                WebPDMGroups = txbWebPDMGroups.Text.Trim(),
                First_Name = txbFirstName.Text.Trim(),
                Last_Name = txbLastName.Text.Trim(),
                Direct_Phone = txbDirectPhone.Text.Trim(),
                Fax_Number = txbFaxNumber.Text.Trim(),
                Relation_To_Company = "",
                Reason_For_Account = txbReasonForAccount.Text.Trim(),
                Print_Name = txbPrintName.Text.Trim(),
                Intra_Print_Name = txbIntraPrintName.Text.Trim(),
                IsAcive = 1,
                Logon_Time = DateTime.Now,
                DisplayName = "",
                ORA_ASPNET_USERID = oraUserId
            };
            try
            {
                var effectRow = BllSrv.CreateUserByExternal(model);
                if (effectRow)
                {
                    //创建成功后发个邮件
                    var pwd = Guid.NewGuid().ToString();
                    var isUpdateUserIdentify = BllSrv.UpdateUserFlagByID(pwd, DateTime.Now, model.ID);
                    if (isUpdateUserIdentify)
                    {
                        var sendFrom = "SOFTWARE.SUPPORT@PERY.COM";
                        var sendSubject = "Set password notice";
                        var sendBody = "From PEI vendor site, " +
                                       "set password service.<br /> " +
                                       "Please click this link " + Utility.VendorSiteUrl+"/ChangePassword.aspx?flag=" + pwd + " " +
                                       "in order to activate operates.";
                        var sendTo = new List<string> { model.Mail };
                        Utility.Send(sendFrom, sendSubject, sendBody, true, false, sendTo, null, null, null);
                        LogService.WriteInfoLog(typeof(ChangePassword), String.Format("Sent mail to {0}, by create user operates.", sendTo[0]));
                    }
                }
                for (int i = 0; i < cblPermissions.Items.Count; i++)
                {
                    if (cblPermissions.Items[i].Selected)
                    {
                        if (cblPermissions.Items[i].Value.Equals(syncUserPermission, StringComparison.CurrentCultureIgnoreCase))
                        {
                            var xx_vendor_sync_user = new SyncUser
                            {
                                //Account = syncUserAccountPrefix + txbSaMacCountName.Text.ToLower().Trim(),
                                Account = name.ToLower().Split('\\')[1],
                                //Name = txbSaMacCountName.Text.Trim(),
                                Name = String.Format("{0} {1}", txbFirstName.Text.Trim(), txbLastName.Text.Trim()).ToUpper(),
                                Enabled = 'T',
                                Email = txbMail.Text.Trim(),
                                Notification_Enabled = 'F',
                                Last_Notified_Time = DateTime.Now,
                                Last_Activity_Time = DateTime.Now,
                                Inactive_Window_Minutes = 60,
                                Machine_Name = ""
                            };
                            var row = BllSrv.CreateSyncUser(xx_vendor_sync_user);
                            continue;
                        }
                        var permissionModel = new XX_VENDOR_USER_PERMISSION
                        {
                            PERMISSION_ID = cblPermissions.Items[i].Value,
                            USER_ID = model.ID,
                            CREATED_BY = HttpContext.Current.User.Identity.Name,
                            CREATED_DATE = DateTime.Now
                        };
                        effectRow = BllSrv.SetPermission(permissionModel);
                    }
                }
                if (effectRow)
                {
                    Utility.ShowMessage(Page, "Operation Successed.", "AccountManage.aspx");
                }
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(CreateUser), "Create user fail. reason: " + ex.Message);
                Utility.ShowMessage(Page, ex.Message);
            }
        }

        string GetUserID(byte[] bytes)
        {
            var sb = new StringBuilder();
            for (int i = 0; i < bytes.Length; i++)
            {
                var singleByte = bytes[i];
                if (singleByte < 16)
                {
                    sb.Append("0");
                    sb.AppendFormat(Convert.ToString(singleByte, 16));
                    continue;
                }
                sb.Append(Convert.ToString(singleByte, 16));
            }
            return sb.ToString().ToUpper(); //
        }
    }
}