﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DAL;
using System.Data;

namespace PEI.Web.Account
{
    public partial class AccountManage : PageBase
    {
        int currentPageCount;
        int totalPageCount;
        static bool loadMore;
        private int PageSize
        {
            get
            {
                return gridView1.PageSize;
            }
        }

        private int PageCount
        {
            get
            {
                var dataCount = DataCollection.Count();
                return (int)Math.Ceiling((double)dataCount / PageSize);
            }
            set
            {
                PageCount = value;
            }
        }

        private int TotalCount
        {
            get
            {
                return DataCollection.Count();
            }
        }

        private int CurrentPageIndex
        {
            get
            {
                if (ViewState["CurrentPageIndex"] == null)
                    ViewState["CurrentPageIndex"] = 0;
                return (int)ViewState["CurrentPageIndex"];
            }
            set
            {
                ViewState["CurrentPageIndex"] = value;
            }
        }

        private string SqlQuery
        {
            get
            {
                if (ViewState["sqlWhere"] == null)
                    ViewState["sqlWhere"] = String.Empty;
                return (string)ViewState["sqlWhere"];
            }
            set
            {
                ViewState["sqlWhere"] = value;
            }
        }

        private List<UserItem> DataCollection
        {
            get
            {
                var list = ViewState["dataCollection"];
                return list != null ? (List<UserItem>)ViewState["dataCollection"] : new List<UserItem>();
            }
            set
            {
                ViewState["dataCollection"] = value;
            }
        }

        public int Idx
        {
            get
            {
                var value = ViewState["Idx"];
                return value != null ? (int)value : 1;
            }
            set
            {
                ViewState["Idx"] = value;
            }
        }

        bool CanEditPermission
        {
            get
            {
                var value = ViewState["CanEditPermission"];
                return value != null ? (bool)value : false;
            }
            set
            {
                ViewState["CanEditPermission"] = value;
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session[Utility._sessionUserPermissions] == null)
            {
                Response.Redirect("~/NewsList.aspx", true);
            }
            else
            {
                string permissions = Session[Utility._sessionUserPermissions].ToString();
                if (!(permissions.Contains(SupremeUserPermissions.OPERATIONAL_UPDATES_EDIT) || permissions.Contains(SupremeUserPermissions.PERMISSION_EDIT)))
                {
                    Response.Redirect("~/NewsList.aspx", true);
                }
            }
            if (!IsPostBack)
            {
                //if (Session[Utility._aspUser] == null && Session[Utility._sessionUserPermissions] == null) Response.Redirect("~/NewsList.aspx", true);
                GetUserPermission();
                SqlQuery = "select ID, Name, SaMacCountName, Company, Mail, IsActive from pei_custom.XX_Vendor_Users where  upper(Domain_Name) = 'SUPREME' and (IsActive =1 or IsActive is null) and ora_aspnet_userid is not null  and rownum <= 600  order by Name";
                GetData(SqlQuery);
                BindGridView();
                currentPageCount = CurrentPageIndex;
                lblCurrentPage.Text = (currentPageCount + 1).ToString();
                totalPageCount = PageCount;
                lblTotalPage.Text = totalPageCount.ToString();
                //btnCreateAccount.Visible = false;
                loadMore = false;
            }
        }

        protected void GetUserPermission()
        {
            var sessionValues = (string)Session[Utility._sessionUserPermissions];
            CanEditPermission = sessionValues.Contains(SupremeUserPermissions.PERMISSION_EDIT) ? true : false;
        }

        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
            lbtnLoadMore.Visible = loadMore ? false : true;
            lbtnPrevious.Visible = DataCollection.Count == 0 ? false : true;
            lbtnNext.Visible = DataCollection.Count == 0 ? false : true;
            pnlPaging.Visible = DataCollection.Count == 0 ? false : true;
            if (CurrentPageIndex == 0)
            {
                lbtnPrevious.Enabled = false;
                lbtnPrevious.CssClass = "lbtnDisabled";
            }
            else
            {
                lbtnPrevious.Enabled = true;
                lbtnPrevious.CssClass = "lbtnNonDisabled";
            }
            if (CurrentPageIndex == PageCount - 1)
            {
                lbtnNext.Enabled = false;
                lbtnNext.CssClass = "lbtnDisabled";
            }
            else
            {
                lbtnNext.Enabled = true;
                lbtnNext.CssClass = "lbtnNonDisabled";
            }
        }

        void BindGridView(int currentPageIndex = 0)
        {
            if (DataCollection == null) return;
            var query = (from q in DataCollection
                         select q).Skip(CurrentPageIndex * PageSize).Take(PageSize)
                         .ToList();
            gridView1.DataSource = query;
            gridView1.DataBind();
        }

        void GetData(string sql)
        {
            try
            {
                DataCollection = BllSrv.GetAccountDataByMultipleConditions(sql);
            }
            catch (Exception ex)
            {
                LogService.WriteErrorLog(typeof(AccountManage), "Call method 'GetAccountDataByMultipleConditions' error by AccountManage page: " + ex.Message);
                Utility.ShowMessage(Page, "Obtain data exception, please later try again.");
                DataCollection = null;
            }
        }

        protected void rbSupreme_CheckedChanged(object sender, EventArgs e)
        {
            SqlQuery = loadMore
                        ? "select ID, Name, SaMacCountName, Company, Mail, IsActive from pei_custom.XX_Vendor_Users where upper(Domain_Name) = 'SUPREME'  and ora_aspnet_userid is not null and (IsActive =1 or IsActive is null)  order by Name"
                        : "select ID, Name, SaMacCountName, Company, Mail, IsActive from pei_custom.XX_Vendor_Users where upper(Domain_Name) = 'SUPREME'  and ora_aspnet_userid is not null and (IsActive =1 or IsActive is null) and rownum <= 600  order by Name";
            CurrentPageIndex = 0;
            Idx = 1;
            GetData(SqlQuery);
            BindGridView();
            ddlNType.SelectedIndex = 0;
            txbTextByType.Text = "";
            currentPageCount = CurrentPageIndex;
            lblCurrentPage.Text = (currentPageCount + 1).ToString();
            totalPageCount = PageCount;
            lblTotalPage.Text = totalPageCount.ToString();
            txbGotoPage.Text = "";
        }

        protected void rbExternal_CheckedChanged(object sender, EventArgs e)
        {
            SqlQuery = loadMore
                        ? "select ID, Name, SaMacCountName, Company, Mail, IsActive from pei_custom.XX_Vendor_Users where (upper(Domain_Name) = 'DMZ1' or upper(Domain_Name) = 'SYNCUSERS') and ora_aspnet_userid is not null and (IsActive =1 or IsActive is null) order by Name"
                        : "select ID, Name, SaMacCountName, Company, Mail, IsActive from pei_custom.XX_Vendor_Users where (upper(Domain_Name) = 'DMZ1' or upper(Domain_Name) = 'SYNCUSERS') and ora_aspnet_userid is not null and (IsActive =1 or IsActive is null) and rownum <= 600 order by Name";
            CurrentPageIndex = 0;
            Idx = 1;
            GetData(SqlQuery);
            BindGridView();
            ddlNType.SelectedIndex = 0;
            txbTextByType.Text = "";
            currentPageCount = CurrentPageIndex;
            lblCurrentPage.Text = (currentPageCount + 1).ToString();
            totalPageCount = PageCount;
            lblTotalPage.Text = totalPageCount.ToString();
            txbGotoPage.Text = "";
        }

        protected void btnFind_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(txbTextByType.Text)) return;
            SqlQuery = "select ID, Name, SaMacCountName, Company, Mail, IsActive from pei_custom.XX_Vendor_Users ";
            SqlQuery += rbSupreme.Checked
                ? "where upper(Domain_Name) = 'SUPREME' and ora_aspnet_userid is not null and (IsActive =1 or IsActive is null)"
                : "where (upper(Domain_Name) = 'DMZ1' or upper(Domain_Name) = 'SYNCUSERS') and ora_aspnet_userid is not null and (IsActive =1 or IsActive is null)";
            MultiConditionsFiltersData();
            currentPageCount = CurrentPageIndex;
            lblCurrentPage.Text = (currentPageCount + 1).ToString();
            totalPageCount = PageCount;
            lblTotalPage.Text = totalPageCount.ToString();
            txbGotoPage.Text = "";
        }

        protected void MultiConditionsFiltersData()
        {
            switch (ddlNType.SelectedItem.Text)
            {
                default: return;
                case "Search by Display Name":
                    CurrentPageIndex = 0;
                    Idx = 1;
                    SqlQuery += rbSupreme.Checked
                        ? String.Format(" and lower(Name) like '%{0}%' and ora_aspnet_userid is not null and (IsActive =1 or IsActive is null) order by Name", txbTextByType.Text.ToLower().Trim())
                        : String.Format(" and lower(Name) like '%{0}%' and ora_aspnet_userid is not null and (IsActive = 1 or IsActive is null) order by Name", txbTextByType.Text.ToLower().Trim());
                    try
                    {
                        DataCollection = BllSrv.GetAccountDataByMultipleConditions(SqlQuery);
                    }
                    catch (Exception ex)
                    {
                        LogService.WriteErrorLog(typeof(AccountManage), "Call method 'GetAccountDataByMultipleConditions' error by AccountManage page: " + ex.Message);
                        Utility.ShowMessage(Page, "Obtain data exception, please later try again.");
                        DataCollection = null;
                        return;
                    }
                    BindGridView();
                    break;
                case "Search by Company Name":
                    CurrentPageIndex = 0;
                    Idx = 1;
                    SqlQuery += rbSupreme.Checked
                        ? String.Format(" and lower(Company) like '%{0}%' and ora_aspnet_userid is not null and (IsActive = 1 or IsActive is null) order by Name", txbTextByType.Text.ToLower().Trim())
                        : String.Format(" and lower(Company) like '%{0}%' and ora_aspnet_userid is not null and (IsActive = 1 or IsActive is null) order by Name", txbTextByType.Text.ToLower().Trim());
                    try
                    {
                        DataCollection = BllSrv.GetAccountDataByMultipleConditions(SqlQuery);
                    }
                    catch (Exception ex)
                    {
                        LogService.WriteErrorLog(typeof(AccountManage), "Call method 'GetAccountDataByMultipleConditions' error by AccountManage page: " + ex.Message);
                        Utility.ShowMessage(Page, "Obtain data exception, please later try again.");
                        DataCollection = null;
                        return;
                    }

                    BindGridView();
                    break;
                case "Search by Email":
                    CurrentPageIndex = 0;
                    Idx = 1;
                    SqlQuery += rbSupreme.Checked
                        ? String.Format(" and lower(Mail) like '%{0}%' and ora_aspnet_userid is not null and (IsActive = 1 or IsActive is null) order by Name", txbTextByType.Text.ToLower().Trim())
                        : String.Format(" and lower(Mail) like '%{0}%' and ora_aspnet_userid is not null and (IsActive = 1 or IsActive is null) order by Name", txbTextByType.Text.ToLower().Trim());
                    try
                    {
                        DataCollection = BllSrv.GetAccountDataByMultipleConditions(SqlQuery);
                    }
                    catch (Exception ex)
                    {
                        LogService.WriteErrorLog(typeof(AccountManage), "Call method 'GetAccountDataByMultipleConditions' error by AccountManage page: " + ex.Message);
                        Utility.ShowMessage(Page, "Obtain data exception, please later try again.");
                        DataCollection = null;
                        return;
                    }
                    BindGridView();
                    break;
            }
        }

        protected void gridView1_PageIndexChanged(object sender, EventArgs e)
        {
            BindGridView();
        }

        protected void gridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gridView1.PageIndex = e.NewPageIndex;
        }

        protected void gridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                var imgUserStatus = e.Row.FindControl("imgUserStatus") as Image;
                var isActiveValue = e.Row.Cells[1].Text;
                switch (isActiveValue)
                {
                    default:
                        imgUserStatus.ImageUrl = "~/Images/Account/User.png";
                        break;
                    case "-1":
                        imgUserStatus.ImageUrl = "~/Images/Account/DelUser.gif";
                        break;
                    case "0":
                        imgUserStatus.ImageUrl = "~/Images/Account/User.png";
                        break;
                    case "1":
                        imgUserStatus.ImageUrl = "~/Images/Account/smallsuccess.gif";
                        break;
                }
            }
            if (rbSupreme.Checked)
            {
                if (e.Row.RowType == DataControlRowType.Header || e.Row.RowType == DataControlRowType.DataRow || e.Row.RowType == DataControlRowType.Footer)
                    e.Row.Cells[0].Visible = e.Row.Cells[1].Visible = false;
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    var hlUpdate = e.Row.FindControl("hlUpdate") as HyperLink;
                    hlUpdate.Visible = false;

                    var hlDetail1 = e.Row.FindControl("hlDetail1") as HyperLink;
                    hlDetail1.Visible = false;

                    var hlDetail = e.Row.FindControl("hlDetail") as HyperLink;
                    hlDetail.NavigateUrl = "~/Account/AccountOperation.aspx?sDetailID=" + e.Row.Cells[0].Text;
                    hlDetail.ToolTip = "Supreme Domain Detail";
                    hlDetail.Target = "_blank";

                    var hlPermission = e.Row.FindControl("hlPermission") as HyperLink;
                    if (!CanEditPermission) hlPermission.Visible = false;
                    hlPermission.NavigateUrl = "~/Account/AccountOperation.aspx?sPermissionID=" + e.Row.Cells[0].Text;
                    hlPermission.ToolTip = "Supreme Domain Set Permissions";
                    hlPermission.Target = "_blank";

                    e.Row.Cells[0].Visible = false;
                    e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#EEEEEE'");
                    if (Idx % 2 == 0) e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#f7f7f7'");
                    else e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF'");
                    Idx++;
                }
            }
            else if (rbExternal.Checked)
            {
                if (e.Row.RowType == DataControlRowType.Header || e.Row.RowType == DataControlRowType.DataRow || e.Row.RowType == DataControlRowType.Footer)
                    e.Row.Cells[0].Visible = e.Row.Cells[1].Visible = false;
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    var hlDetail = e.Row.FindControl("hlDetail") as HyperLink;
                    hlDetail.NavigateUrl = "~/Account/AccountOperation.aspx?eDetailID=" + e.Row.Cells[0].Text;
                    hlDetail.ToolTip = "External Users Detail";
                    hlDetail.Target = "_blank";

                    var hlUpdate = e.Row.FindControl("hlUpdate") as HyperLink;
                    if (!((string)Session[Utility._sessionUserPermissions]).Contains(SupremeUserPermissions.OPERATIONAL_UPDATES_EDIT))
                    {
                        hlUpdate.Visible = false;
                    }
                    hlUpdate.NavigateUrl = "~/Account/AccountOperation.aspx?eUpdateID=" + e.Row.Cells[0].Text;
                    hlUpdate.ToolTip = "External Users Update";
                    hlUpdate.Target = "_blank";

                    var hlDetail1 = e.Row.FindControl("hlDetail1") as HyperLink;
                    hlDetail1.NavigateUrl = "~/Account/AccountOperation.aspx?eNewDetailID=" + e.Row.Cells[0].Text;
                    hlDetail1.ToolTip = "External Users Detail";
                    hlDetail1.Target = "_blank";

                    var hlPermission = e.Row.FindControl("hlPermission") as HyperLink;
                    if (!CanEditPermission) hlPermission.Visible = false;
                    hlPermission.NavigateUrl = "~/Account/AccountOperation.aspx?ePermissionID=" + e.Row.Cells[0].Text;
                    hlPermission.ToolTip = "External Users Set Permissions";
                    hlPermission.Target = "_blank";

                    e.Row.Cells[0].Visible = false;
                    e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#EEEEEE'");
                    if (Idx % 2 == 0) e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#f7f7f7'");
                    else e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF'");
                    Idx++;
                }
            }
        }

        protected void lbtnLoadMore_Click(object sender, EventArgs e)
        {
            SqlQuery = rbSupreme.Checked
                        ? "select ID, Name, SaMacCountName, Company, Mail, IsActive from pei_custom.XX_Vendor_Users where upper(Domain_Name) = 'SUPREME' and ora_aspnet_userid is not null and (IsActive = 1 or IsActive is null) order by Name"
                        : "select ID, Name, SaMacCountName, Company, Mail, IsActive from pei_custom.XX_Vendor_Users where (upper(Domain_Name) = 'DMZ1' or upper(Domain_Name) = 'SYNCUSERS') and ora_aspnet_userid is not null and (IsActive = 1 or IsActive is null) order by Name";
            CurrentPageIndex = 0;
            Idx = 1;
            GetData(SqlQuery);
            BindGridView();
            currentPageCount = CurrentPageIndex;
            lblCurrentPage.Text = (currentPageCount + 1).ToString();
            totalPageCount = PageCount;
            lblTotalPage.Text = totalPageCount.ToString();
            loadMore = true;
            ddlNType.SelectedIndex = 0;
            txbTextByType.Text = "";
            txbGotoPage.Text = "";
        }

        protected void lbtnPrevious_Click(object sender, EventArgs e)
        {
            CurrentPageIndex -= 1;
            BindGridView(CurrentPageIndex);
            currentPageCount = CurrentPageIndex;
            lblCurrentPage.Text = (currentPageCount + 1).ToString();
            txbGotoPage.Text = "";
        }

        protected void lbtnNext_Click(object sender, EventArgs e)
        {
            CurrentPageIndex += 1;
            BindGridView(CurrentPageIndex);
            currentPageCount = CurrentPageIndex;
            lblCurrentPage.Text = (currentPageCount + 1).ToString();
            txbGotoPage.Text = "";
        }

        protected void btnGo_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(txbGotoPage.Text)) return;
            int inputValue;
            if (!Int32.TryParse(txbGotoPage.Text, out inputValue)) return;
            if (inputValue < 1 || inputValue > PageCount) return;
            CurrentPageIndex = inputValue - 1;
            BindGridView(CurrentPageIndex);
            currentPageCount = CurrentPageIndex;
            lblCurrentPage.Text = (currentPageCount + 1).ToString();
        }
    }
}