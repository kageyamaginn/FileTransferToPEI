﻿using DAL;
using PEI.Web.Account;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.SessionState;

namespace PEI.Web.Ashx
{
    /// <summary>
    /// Summary description for Upload
    /// </summary>
    public class Upload : CreateUser, IHttpHandler, IRequiresSessionState
    {
        protected string destinationFolder = Utility.downloadFolder;//"D:\\SyncCenter\\Download\\";
        protected string filesbackupFolder = "D:\\TransFiles\\";
        // private UserItem user;
        //private string current_user;
        List<FileInfo> fileInfoList;
        private string Js(string v)
        {
            //此函数进行js的转义替换的，防止字符串中输入了'后造成回调输出的js中字符串不闭合
            if (v == null) return "";
            return v.Replace("'", @"\'");
        }
        //public static void WriteJson(HttpResponse response,
        //   string status1, string msg1, object data1 = null)
        //{
        //    response.ContentType = "application/json";
        //    var obj = new { status = status1, msg = msg1, data = data1 };
        //    string json = new JavaScriptSerializer().Serialize(obj);
        //    response.Write(json);
        //}
        //下面就是一个简单的示例，保存上传的文件，如果要验证上传的后缀名，得自己写，还有写数据库什么的
        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/html";
            if (context.Request.Files.Count > 0)
            {
                try
                {
                    HttpPostedFile file = context.Request.Files["myfile"];
                    if (file.ContentLength <= 0)
                    {
                        context.Response.Write("no:Please select the file to upload.");
                        return;
                    }
                    string fileName = file.FileName;// Request["fileName"];
                    if (fileName == null)
                    {
                        context.Response.Write("no:File name can not be empty.");
                        return;
                    }
                    if (fileName.Length > 60)
                    {
                        context.Response.Write("no:File name too long, no more than 60 char.");
                        return;
                    }
                    var invalidFileNameChars = Path.GetInvalidFileNameChars();
                    var existIllegalChar = invalidFileNameChars.FirstOrDefault(v => fileName.Contains(v));
                    if (existIllegalChar != '\0')
                    {
                        context.Response.Write("no:The file name contains illegal characters.");
                        return;
                    }

                    string tempPath = @"D:\SyncCenter\TEMP\";
                    if (!Directory.Exists(tempPath))
                    {
                        Directory.CreateDirectory(tempPath);
                    }
                    file.SaveAs(tempPath + fileName);
                    string current_user = (string)HttpContext.Current.Session[Utility._aspUser];
                    string download_Folder = "";
                    string toUser = context.Request["toUser"];
                    string category = context.Request["category"];
                    string subFolder = context.Request["subCategory"] ?? "";
                    if (toUser.Length > 0 && category.Length > 0)
                    {
                        UserItem user = BllSrv.GetUserItemByID(toUser);
                        if (user != null)
                        {
                            download_Folder = user.Download_Folder;
                        }
                        if (download_Folder != null && download_Folder.Length > 0)
                        {
                            try
                            {
                                var savetofolder = destinationFolder + download_Folder + "\\" + "@Publish\\" + category + "\\";
                                if (subFolder.Length > 0)
                                {
                                    savetofolder += subFolder + "\\";
                                    category += "\\" + subFolder;
                                }
                                if (!Directory.Exists(savetofolder))
                                    Directory.CreateDirectory(savetofolder);

                                File.Copy(tempPath + fileName, savetofolder + fileName, true);
                                var fileID = Guid.NewGuid().ToString();
                                var fileModel = new XX_VENDOR_FILE
                                {
                                    FILE_ID = fileID,
                                    DISPLAY_NAME = fileName,
                                    ACTUAL_NAME = fileName,
                                    CATEGORY = category,
                                    CREATE_DATE = DateTime.Now,
                                    CREATE_BY = current_user.ToLower()
                                };
                                bool isCreateFile = BllSrv.CreateVendorFile(fileModel);
                                XX_VENDOR_USER_FILE userFileModel = new XX_VENDOR_USER_FILE
                                {
                                    USER_ID = toUser,
                                    FILE_ID = fileID,
                                    IS_SHOW = "0"
                                };
                                var isCreateUserFile = BllSrv.CreateVendorUserFile(userFileModel);
                                if (fileID.Length > 0)
                                {
                                    var backupdestFolder = filesbackupFolder + download_Folder + "\\" + fileID + "\\";
                                    if (!Directory.Exists(backupdestFolder))
                                        Directory.CreateDirectory(backupdestFolder);
                                    File.Copy(tempPath + fileName, backupdestFolder + fileName, true);
                                }
                                context.Response.Write("ok:Uploaded successfully");
                                return;
                            }
                            catch (Exception ex)
                            {
                                LogService.WriteErrorLog(typeof(Upload), ex.ToString());
                                context.Response.Write("no:Upload failed.");
                                return;
                            }
                            finally
                            {
                                if (File.Exists(tempPath + fileName))
                                {
                                    File.Delete(tempPath + fileName);
                                }
                            }
                        }
                    }
                    else
                    {
                        context.Response.Write("no:Parameter error.");
                        return;
                    }
                }
                catch (Exception ex)
                {
                    LogService.WriteErrorLog(typeof(Upload), ex.ToString());
                    context.Response.Write("no:Server error");
                    return;
                }
            }
            else
            {
                context.Response.Write("no:Please select the file to upload");
            }
            return;
        }
        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}