﻿using DAL;
using PEI.Web.Account;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;

namespace PEI.Web.Ashx
{
    /// <summary>
    /// Summary description for GetUsersByEmail
    /// </summary>
    public class GetUsersByEmail : CreateUser, IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            try
            {
                string mail = context.Request["EMail"].ToLower();
                var list = BllSrv.GetUserIDsByEmail(mail);
                if (list == null || list.Count() <= 0)
                {
                    context.Response.Write("no:This e-mail address is not the site user");
                    return;
                }
                List<string> users = new List<string>();
                foreach (var item in list)
                {
                    string oraAspUserId = GetUserID(item.UserID);
                    var nameList = BllSrv.GetNameByUserId(oraAspUserId);
                    if (nameList != null && nameList.Count > 0)
                    {
                        users.AddRange(nameList);
                    }
                }
                for (int i = 0; i < users.Count; i++)
                {
                    if (users[i].Contains("__"))
                    {
                        users.Remove(users[i]);
                    }
                }
                if (users.Count() <= 0)
                {
                    context.Response.Write("no:This e-mail address is not the site user");
                    return;
                }
                JavaScriptSerializer js = new JavaScriptSerializer();
                context.Response.Write("ok:" + js.Serialize(users));
            }
            catch (Exception ex)
            {
                context.Response.Write("no:* Server error.");
                LogService.WriteErrorLog(typeof(GetUsersByEmail), ex.ToString());
                return;
            }
        }
        private string GetUserID(byte[] bytes)
        {
            var sb = new StringBuilder();
            for (int i = 0; i < bytes.Length; i++)
            {
                var singleByte = bytes[i];
                if (singleByte < 16)
                {
                    sb.Append("0");
                    sb.AppendFormat(Convert.ToString(singleByte, 16));
                    continue;
                }
                sb.Append(Convert.ToString(singleByte, 16));
            }
            return sb.ToString().ToUpper();
        }
        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}