﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.DirectoryServices;
using System.DirectoryServices.ActiveDirectory;
using System.DirectoryServices.AccountManagement;
using System.Security.AccessControl;
using System.IO;
using System.Threading;
using System.Security.Principal;
using System.Collections;

namespace Pei.DirectoryServices
{
    /// <summary>
    /// 活动目录操作类，主要包括创建用户及用户组，分配目录权限，创建共享等常用操作。
    /// 注意：部分代码虽提供，但因为条件所限，没有进行全面测试。
    /// </summary>
    public class ADHelper
    {
        //[DllImport("advapi32.dll", SetLastError = true)]
        //public static extern bool LogonUser(String lpszUsername, String lpszDomain, String lpszPassword, int dwLogonType, int dwLogonProvider, ref IntPtr phToken);

        private Dictionary<string, PrincipalContextStore> principalContexts;

        public Dictionary<string, PrincipalContextStore> PrincipalContexts
        {
            get { return principalContexts; }
            set { principalContexts = value; }
        }

        private bool disposed;

        public bool IsWinNTProvider(string path)
        {
            return path.StartsWith("WinNT");
        }

        private string exceptionMessage;

        public string ExceptionMessage
        {
            get { return exceptionMessage; }
        }

        public ADHelper(string principalContextStore, bool encryptPassword)
        {
            principalContexts = PrincipalContextStore.LoadXml(principalContextStore, encryptPassword);
        }

        private DirectoryEntry GetDirectoryEntryByPath(string aDPath)
        {
            DirectoryEntry de = null;
            try
            {
                if (DirectoryEntry.Exists(aDPath))
                {
                    de = new DirectoryEntry(aDPath);
                }
                else exceptionMessage = "Active Directory entry not found!";
            }
            catch (Exception ex)
            {
                exceptionMessage = ex.ToString();
            }
            return de;
        }

        private DirectoryEntry GetDirectoryEntryByDomain(string domain)
        {
            domain = domain.ToUpper();
            if (!principalContexts.ContainsKey(domain)) return null;
            PrincipalContextStore pcs = principalContexts[domain];
            string aDRoot = pcs.LdapRoot;
            if (pcs.OperatorAccount == null)
                return new DirectoryEntry(aDRoot);
            else
                return new DirectoryEntry(aDRoot, pcs.OperatorAccount.UserName, pcs.OperatorPassword);
        }

        private DirectoryEntry GetDirectoryEntryByAccount(Account account)
        {
            DirectoryEntry de = GetDirectoryEntryByDomain(account.Domain);
            if (de != null)
            {
                if (IsWinNTProvider(de.Path))
                {
                    de = de.Children.Find(account.UserName, "user");
                }
                else
                {
                    DirectorySearcher deSearch = new DirectorySearcher(de);
                    deSearch.Filter = "(&(&(objectCategory=person)(objectClass=user))(sAMAccountName=" + account.UserName + "))";
                    deSearch.SearchScope = SearchScope.Subtree;
                    try
                    {
                        SearchResult result = deSearch.FindOne();
                        de = new DirectoryEntry(result.Path);
                        return de;
                    }
                    catch
                    {
                        return null;
                    }

                }
            }

            return de;
        }

        #region IDisposable Members

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    //foreach (DirectoryEntry de in aDCache.Values)
                    //{
                    //    de.Close();
                    //    de.Dispose();
                    //}
                }
            }
            disposed = true;
        }
        #endregion

        /// 
        /// 判断用户帐号是否激活
        /// 
        /// 用户帐号属性控制器
        /// 如果用户帐号已经激活，返回 true；否则返回 false
        public static bool IsAccountActive(int userAccountControl)
        {
            int userAccountControl_Disabled = Convert.ToInt32(ADS_USER_FLAG.ADS_UF_ACCOUNTDISABLE);
            int flagExists = userAccountControl & userAccountControl_Disabled;
            if (flagExists > 0)
                return false;
            else
                return true;
        }

        /// 
        /// 判断用户帐号与密码是否足够以满足身份验证进而登录
        /// 
        public LoginResult LoginByUserPrincipal(string account, string password)
        {
            UserPrincipal p = GetUserPrincipalByAccount(account);

            if (p != null)
            {
                // 必须在判断用户密码正确前，对帐号激活属性进行判断；否则将出现异常。
                switch (p.Enabled)
                {
                    case null:
                        return LoginResult.LOGIN_USER_ACCOUNT_INACTIVE;
                    case false:
                        return LoginResult.LOGIN_USER_ACCOUNT_INACTIVE;
                    case true:
                        if (p.IsAccountLockedOut()) return LoginResult.LOGIN_USER_ACCOUNT_INACTIVE;
                        break;
                }

                Account a = new Account(account);
                if (p.Context.ValidateCredentials(a.UserName, password)) return LoginResult.LOGIN_USER_OK;
                else return LoginResult.LOGIN_USER_PASSWORD_INCORRECT;
            }
            else
            {
                return LoginResult.LOGIN_USER_DOESNT_EXIST;
            }
        }

        public UserPrincipal UserInfo(string account)
        {
            return GetUserPrincipalByAccount(account);
        }

        /// 
        /// 判断用户帐号与密码是否足够以满足身份验证进而登录
        /// 
        //public LoginResult LoginByAccount(string account, string password)
        //{
        //    Account a = new Account(account);
        //    if (!principalContexts.ContainsKey(a.Domain)) return LoginResult.LOGIN_USER_DOESNT_EXIST;
        //    PrincipalContext ctx = principalContexts[a.Domain].Context;
        //    if (ctx == null) return LoginResult.LOGIN_USER_DOESNT_EXIST;
        //    UserPrincipal p = UserPrincipal.FindByIdentity(ctx, a.UserName);
        //    if (p == null) return LoginResult.LOGIN_USER_DOESNT_EXIST;
        //    if (!p.Enabled.HasValue || !p.Enabled.Value) return LoginResult.LOGIN_USER_ACCOUNT_INACTIVE;
        //    if (p.IsAccountLockedOut()) return LoginResult.LOGIN_USER_ACCOUNT_INACTIVE;
        //    if (!ctx.ValidateCredentials(a.UserName, password, ContextOptions.Negotiate)) return LoginResult.LOGIN_USER_PASSWORD_INCORRECT;
        //    return LoginResult.LOGIN_USER_OK;
        //}

        //        public LoginResult LoginByAccount(string account, string password)
        //        {
        //            Account a = new Account(account);
        //            //IdentityImpersonation idi = new IdentityImpersonation(a.UserName, password, a.Domain);
        //            //idi.BeginImpersonate();
        //            //using (Impersonation ip = new Impersonation(Impersonation.BuiltinUser.NetworkService))
        //            //{
        //            DirectoryEntry de = null;
        //            try
        //            {
        //                de = GetDirectoryEntryByAccount(a);
        //                if (de != null)
        //                {
        //                    // 必须在判断用户密码正确前，对帐号激活属性进行判断；否则将出现异常。
        //                    int userAccountControl;
        //                    if (IsWinNTProvider(de.Path)) userAccountControl = Convert.ToInt32(de.Properties["UserFlags"][0]);
        //                    else userAccountControl = Convert.ToInt32(de.Properties["userAccountControl"][0]);

        //                    if (!IsAccountActive(userAccountControl))
        //                        return LoginResult.LOGIN_USER_ACCOUNT_INACTIVE;
        //                    if (IsWinNTProvider(de.Path))
        //                    {
        //                        return LoginResult.LOGIN_EXCEPTION;
        //                        //IntPtr x = IntPtr.Zero;
        //                        //if (LogonUser(a.UserName, a.Domain, password, 2, 0, ref x)) return LoginResult.LOGIN_USER_OK;
        //                        //else return LoginResult.LOGIN_USER_PASSWORD_INCORRECT;
        //                    }
        //                    else
        //                    {
        //                        de = new DirectoryEntry(de.Path, a.UserName, password, AuthenticationTypes.Secure);
        //                        try
        //                        {
        //                            if (de != null && de.NativeObject != null) //若密码错误，NativeObject会异常
        //                                return LoginResult.LOGIN_USER_OK;
        //                            else
        //                                return LoginResult.LOGIN_USER_PASSWORD_INCORRECT;
        //                        }
        //                        catch
        //                        {
        //                            return LoginResult.LOGIN_USER_PASSWORD_INCORRECT;
        //                        }
        //                    }
        //                }
        //                else
        //                {
        //                    return LoginResult.LOGIN_USER_DOESNT_EXIST;
        //                }
        //            }
        //            catch (Exception ex)
        //            {
        //                return LoginResult.LOGIN_EXCEPTION;
        //            }
        ////            finally
        //            {
        //                //                    idi.StopImpersonate();
        //            }
        //            //}
        //        }

        public LoginResult LoginByAccount(string account, string password)
        {
            Account a = new Account(account);
            try
            {
                //domainName is something like ldap.abc.com, UserName is domain\username
                DirectoryEntry entry = new DirectoryEntry("LDAP://miadmz1.corp", account, password, AuthenticationTypes.Secure);
                try
                {
                    object nativeObject = entry.NativeObject;
                    return LoginResult.LOGIN_USER_OK;
                }
                catch (Exception ex)
                {
                    return LoginResult.LOGIN_USER_PASSWORD_INCORRECT;
                }
            }
            catch (System.Runtime.InteropServices.COMException e)
            {
                return LoginResult.LOGIN_EXCEPTION;
            }
        }
        public bool IsMemberOf(string userAccount, string groupAccount)
        {
            //using (Impersonation impersonation = new Impersonation("webadmn", "dmz1", "d0n!5h@4e"))
            {
                UserPrincipal up = GetUserPrincipalByAccount(userAccount);
                if (up == null) throw new Exception("User not found.");
                GroupPrincipal gp = GetGroupPrincipalByAccount(groupAccount);
                if (gp == null) throw new Exception("Group not found.");
                DirectoryEntry de = (DirectoryEntry)gp.GetUnderlyingObject();
                object m = de.Invoke("Members");
                foreach (object u in (IEnumerable)m)
                {
                    DirectoryEntry ude = new DirectoryEntry(u);
                    SecurityIdentifier sid = new SecurityIdentifier((byte[])ude.Properties["objectSid"].Value, 0);
                    if (sid == up.Sid) return true;
                }
                return false;
                //return gp.Members.Contains(up);
                //return up.IsMemberOf(gp);
            }
        }

        public bool TestIsMemberOf(string userAccount, string groupAccount)
        {
            UserPrincipal up = GetUserPrincipalByAccount(userAccount);
            if (up == null) throw new Exception("User not found.");
            GroupPrincipal gp = GetGroupPrincipalByAccount(groupAccount);
            if (gp == null) throw new Exception("Group not found.");
            return up.IsMemberOf(gp); //not work in DMZ1 domain
        }

        public List<Dictionary<string, string>> FindUserEntryByAccount(string account)
        {
            List<Dictionary<string, string>> propDict = new List<Dictionary<string, string>>();
            Account a = new Account(account);
            DirectoryEntry de = GetDirectoryEntryByDomain(a.Domain);
            if (IsWinNTProvider(de.Path))
            {
                de.Children.SchemaFilter.Add("user");
                foreach (DirectoryEntry result in de.Children)
                {
                    if (result.Name.ToLower().Contains(a.UserName.ToLower()))
                    {
                        Dictionary<string, string> userPorp = new Dictionary<string, string>();
                        userPorp.Add("Domain", a.Domain);
                        foreach (string key in result.Properties.PropertyNames)
                        {
                            userPorp.Add(key, result.Properties[key][0].ToString());
                        }
                        propDict.Add(userPorp);

                    }
                }
            }
            else
            {
                DirectorySearcher deSearch = new DirectorySearcher(de);
                deSearch.Filter = "(&(&(objectCategory=person)(objectClass=user))(|(sAMAccountName=*" + a.UserName + "*)(cn=*" + a.UserName + "*)))";
                deSearch.SearchScope = SearchScope.Subtree;
                try
                {
                    SearchResultCollection results = deSearch.FindAll();
                    foreach (SearchResult result in results)
                    {
                        Dictionary<string, string> userPorp = new Dictionary<string, string>();
                        userPorp.Add("Domain", a.Domain);
                        foreach (string key in result.Properties.PropertyNames)
                        {
                            userPorp.Add(key, result.Properties[key][0].ToString());
                        }
                        propDict.Add(userPorp);
                    }
                }
                catch
                {
                }
            }
            return propDict;

        }

        public List<Dictionary<string, string>> FindUserEntryOfGroupAccount(string groupAccount, string username)
        {
            List<Dictionary<string, string>> propDict = new List<Dictionary<string, string>>();
            username = username.ToLower();
            Account ga = new Account(groupAccount);
            DirectoryEntry de = GetDirectoryEntryByDomain(ga.Domain);
            if (de == null) return null;
            de = de.Children.Find(ga.UserName, "group");
            if (de == null) return null;
            if (IsWinNTProvider(de.Path))
            {
                object m = de.Invoke("Members");
                foreach (object u in (IEnumerable)m)
                {
                    DirectoryEntry ude = new DirectoryEntry(u);
                    if (ude.Name.ToLower().Contains(username.ToLower()))
                    {
                        Dictionary<string, string> userPorp = new Dictionary<string, string>();
                        userPorp.Add("Domain", ga.Domain);
                        foreach (string key in ude.Properties.PropertyNames)
                        {
                            userPorp.Add(key, ude.Properties[key][0].ToString());
                        }
                        propDict.Add(userPorp);

                    }
                }
                //de.Children.SchemaFilter.Add("user");
                //foreach (DirectoryEntry result in de.Children)
                //{
                //    if (result.Name.ToLower().Contains(ga.UserName.ToLower()))
                //    {
                //        Dictionary<string, string> userPorp = new Dictionary<string, string>();
                //        userPorp.Add("Domain", ga.Domain);
                //        foreach (string key in result.Properties.PropertyNames)
                //        {
                //            userPorp.Add(key, result.Properties[key][0].ToString());
                //        }
                //        propDict.Add(userPorp);

                //    }
                //}
            }
            else
            {
                //UNDO:未在域中进行测试
                DirectorySearcher deSearch = new DirectorySearcher(de);
                deSearch.Filter = "(&(&(objectCategory=person)(objectClass=user))(|(sAMAccountName=*" + username + "*)(cn=*" + ga.UserName + "*)))";
                deSearch.SearchScope = SearchScope.Subtree;
                try
                {
                    SearchResultCollection results = deSearch.FindAll();
                    foreach (SearchResult result in results)
                    {
                        Dictionary<string, string> userPorp = new Dictionary<string, string>();
                        userPorp.Add("Domain", ga.Domain);//UNDO:可能包括其他域的用户，暂时不知在哪个属性中存放
                        foreach (string key in result.Properties.PropertyNames)
                        {
                            userPorp.Add(key, result.Properties[key][0].ToString());
                        }
                        propDict.Add(userPorp);
                    }
                }
                catch
                {
                }
            }
            return propDict;

        }

        protected UserPrincipal GetUserPrincipalByAccount(string account)
        {
            Account a = new Account(account);
            if (!principalContexts.ContainsKey(a.Domain)) return null;
            PrincipalContext ctx = principalContexts[a.Domain].Context;
            if (ctx == null) return null;
            UserPrincipal p = UserPrincipal.FindByIdentity(ctx, a.UserName);
            return p;
        }

        private GroupPrincipal GetGroupPrincipalByAccount(string groupAccount)
        {
            Account a = new Account(groupAccount);
            if (!principalContexts.ContainsKey(a.Domain)) return null;
            PrincipalContext ctx = principalContexts[a.Domain].Context;
            if (ctx == null) return null;
            GroupPrincipal p = GroupPrincipal.FindByIdentity(ctx, a.UserName);
            return p;
        }

        public ErrorMsg CreateUser(string account, string password, string displayName, string mail)
        {
            Account a = new Account(account);
            if (!principalContexts.ContainsKey(a.Domain))
            {
                return ErrorMsg.Invalid_Account;
            }
            PrincipalContextStore pcs = principalContexts[a.Domain];
            PrincipalContext ctx = pcs.Context;
            if (ctx == null)
            {
                return ErrorMsg.Invalid_Account;
            }
            UserPrincipal p = UserPrincipal.FindByIdentity(ctx, a.UserName);
            if (p != null)
            {
                return ErrorMsg.Duplicate_Account;
            }
            p = new UserPrincipal(ctx, a.UserName, password, true);
            //Console.WriteLine(string.Format("Options={0}\r\nConnectedServer={1}\r\nName={2}\r\nUserName={3}\r\n",ctx.Options.ToString(),ctx.ConnectedServer,ctx.Name,ctx.UserName));
            //                p.SamAccountName = a.UserName;
            //                p.SetPassword(password);
            //                p.Enabled = true;
            p.DisplayName = displayName;

            switch (ctx.ContextType)
            {
                case ContextType.Machine:
                    p.Description = mail;
                    p.Name = a.UserName;
                    break;
                case ContextType.Domain:
                    p.EmailAddress = mail;
                    break;
                case ContextType.ApplicationDirectory:
                    break;
            }
            //Console.WriteLine(string.Format("DistinguishedName={0}\r\nContextType={1}\r\nUserPrincipalName={2}\r\n", p.DistinguishedName, p.ContextType, p.UserPrincipalName));
            p.Save();
            return ErrorMsg.None;
        }

        public ErrorMsg ModifyUser(string account, string password, string displayName, string mail)
        {
            Account a = new Account(account);
            if (!principalContexts.ContainsKey(a.Domain))
            {
                return ErrorMsg.Invalid_Account;
            }
            PrincipalContextStore pcs = principalContexts[a.Domain];
            PrincipalContext ctx = pcs.Context;
            if (ctx == null)
            {
                return ErrorMsg.Invalid_Account;
            }
            UserPrincipal p = UserPrincipal.FindByIdentity(ctx, a.UserName);
            if (p == null)
            {
                return ErrorMsg.Name_Not_Found;
            }

            p.DisplayName = displayName;
            if (!string.IsNullOrEmpty(password)) p.SetPassword(password);
            switch (ctx.ContextType)
            {
                case ContextType.Machine:
                    p.Description = mail;
                    p.Name = a.UserName;
                    break;
                case ContextType.Domain:
                    p.EmailAddress = mail;
                    break;
                case ContextType.ApplicationDirectory:
                    break;
            }
            p.Save();
            return ErrorMsg.None;
        }

        public ErrorMsg DeleteUser(string account)
        {
            Account a = new Account(account);
            if (!principalContexts.ContainsKey(a.Domain))
            {
                return ErrorMsg.Invalid_Account;
            }
            PrincipalContextStore pcs = principalContexts[a.Domain];
            PrincipalContext ctx = pcs.Context;
            if (ctx == null)
            {
                return ErrorMsg.Invalid_Account;
            }
            UserPrincipal p = UserPrincipal.FindByIdentity(ctx, a.UserName);
            if (p == null)
            {
                return ErrorMsg.Name_Not_Found;
            }
            p.Delete();
            return ErrorMsg.None;
        }

        public ErrorMsg SetPassword(string account, string password)
        {
            Account a = new Account(account);
            if (!principalContexts.ContainsKey(a.Domain))
            {
                return ErrorMsg.Invalid_Account;
            }
            PrincipalContextStore pcs = principalContexts[a.Domain];
            PrincipalContext ctx = pcs.Context;
            if (ctx == null)
            {
                return ErrorMsg.Invalid_Account;
            }
            UserPrincipal p = UserPrincipal.FindByIdentity(ctx, a.UserName);
            if (p == null)
            {
                return ErrorMsg.Name_Not_Found;
            }
            p.SetPassword(password);
            return ErrorMsg.None;
        }

        public ErrorMsg ChangePassword(string account,string oldPassword, string password)
        {
            Account a = new Account(account);
            if (!principalContexts.ContainsKey(a.Domain))
            {
                return ErrorMsg.Invalid_Account;
            }
            PrincipalContextStore pcs = principalContexts[a.Domain];
            PrincipalContext ctx = pcs.Context;
            if (ctx == null)
            {
                return ErrorMsg.Invalid_Account;
            }
            UserPrincipal p = UserPrincipal.FindByIdentity(ctx, a.UserName);
            if (p == null)
            {
                return ErrorMsg.Name_Not_Found;
            }
            p.ChangePassword(oldPassword, password);
            return ErrorMsg.None;
        }

        /// <summary>
        /// Get group member list dictionary by group name
        /// </summary>
        /// <param name="account">group name: domain\all_bjn_mis</param>
        /// <returns>dictionary or null</returns>
        public Dictionary<string, Dictionary<string, string>> ListGroupMembersByAccount(string groupAccount)
        {
            GroupPrincipal gp = GetGroupPrincipalByAccount(groupAccount);
            if (gp == null) return null;
            Dictionary<string, Dictionary<string, string>> members = new Dictionary<string, Dictionary<string, string>>();
            string account = null;
            foreach (Principal p in gp.GetMembers())
            {
                DirectoryEntry de = (DirectoryEntry)p.GetUnderlyingObject();
                Dictionary<string, string> properties = new Dictionary<string, string>();
                properties.Add("Path", de.Path);
                PropertyCollection pcoll = de.Properties;
                foreach (string sc in pcoll.PropertyNames)
                    properties.Add(sc, pcoll[sc].Value.ToString());
                switch (p.ContextType)
                {
                    case ContextType.Machine:
                        account = ".\\" + p.Name;
                        break;
                    case ContextType.Domain:
                        if (p.StructuralObjectClass != "user") continue;
                        account = GetDomainNameByPath(p.DistinguishedName) + "\\" + p.SamAccountName;
                        break;
                    case ContextType.ApplicationDirectory:
                        account = p.Name;
                        //UNDO ContextType.ApplicationDirectory.
                        break;
                }
                members.Add(account, properties);
            }
            return members;
            //DirectoryEntry de = GetGroupEntryByAccount(account);
            //if (de == null) return null;
            //return ListGroupMembers(de.Path);
        }

        protected string GetDomainNameByPath(string path)
        {
            //UNDO child domain name
            foreach (PrincipalContextStore s in principalContexts.Values)
            {
                if (s.Type != ContextType.Domain) continue;
                if (path.EndsWith(s.Container, StringComparison.InvariantCultureIgnoreCase)) return s.Name;
            }
            return null;
        }

        public Dictionary<string, string> ListUserCommonPropertiesByAccount(string account)
        {
            Account a = new Account(account);
            PrincipalContext ctx = principalContexts[a.Domain].Context;
            if (ctx == null) return null;
            UserPrincipal p = UserPrincipal.FindByIdentity(ctx, a.UserName);
            if (p == null) return null;
            Dictionary<string, string> properties = new Dictionary<string, string>();
            switch (ctx.ContextType)
            {
                case ContextType.Machine:
                    properties.Add("samaccountname", p.SamAccountName);
                    properties.Add("mail", p.Description);
                    properties.Add("displayname", p.DisplayName);
                    break;
                case ContextType.Domain:
                    properties.Add("samaccountname", p.SamAccountName);
                    properties.Add("mail", p.EmailAddress);
                    properties.Add("displayname", p.DisplayName);
                    break;
                case ContextType.ApplicationDirectory:
                    break;
            }
            return properties;
        }

        public Dictionary<string, string> ListUserPropertiesByAccount(string account)
        {
            Account a = new Account(account);
            DirectoryEntry de = GetDirectoryEntryByAccount(a);
            if (de == null) return null;
            Dictionary<string, string> properties = new Dictionary<string, string>();
            //DirectoryEntry de = null;
            //de = new DirectoryEntry(domainPath + UserName, "Administrator", "kevin", AuthenticationTypes.Secure);
            PropertyCollection pcoll = de.Properties;
            foreach (string sc in pcoll.PropertyNames)
                properties.Add(sc, pcoll[sc].Value.ToString());
            return properties;
        }

        public Dictionary<string, string> ListUserPropByADPath(string aDPath)
        {
            DirectoryEntry de = GetDirectoryEntryByPath(aDPath);
            if (de == null) return null;
            Dictionary<string, string> properties = new Dictionary<string, string>();
            //DirectoryEntry de = null;
            //de = new DirectoryEntry(domainPath + UserName, "Administrator", "kevin", AuthenticationTypes.Secure);
            PropertyCollection pcoll = de.Properties;
            foreach (string sc in pcoll.PropertyNames)
                properties.Add(sc, pcoll[sc].Value.ToString());
            return properties;
        }

        public bool AddUserToGroup(string userAccount, string groupAccount)
        {
            Account ua = new Account(userAccount);
            Account ga = new Account(groupAccount);
            UserPrincipal up = null;
            GroupPrincipal gp = null;
            PrincipalContextStore pcsUser = principalContexts[ua.Domain];
            if (pcsUser == null || pcsUser.Context == null)
            {
                throw new Exception("User Domain not exists");
            }
            PrincipalContextStore pcsGroup = principalContexts[ga.Domain];
            if (pcsGroup == null || pcsGroup.Context == null)
            {
                throw new Exception("Group Domain not exists");
            }
            up = UserPrincipal.FindByIdentity(pcsUser.Context, ua.UserName);
            if (up == null)
            {
                throw new Exception("User not exists");
            }
            DirectoryEntry ude = (DirectoryEntry)up.GetUnderlyingObject();
            gp = GroupPrincipal.FindByIdentity(pcsGroup.Context, ga.UserName);
            if (gp == null)
            {
                throw new Exception("Group not exists");
            }
            DirectoryEntry gde = (DirectoryEntry)gp.GetUnderlyingObject();

            object m = gde.Invoke("Members");
            foreach (object u in (IEnumerable)m)
            {
                DirectoryEntry de = new DirectoryEntry(u);
                SecurityIdentifier sid = new SecurityIdentifier((byte[])de.Properties["objectSid"].Value, 0);
                if (sid == up.Sid) return true;
            }

            string userADsPath = string.Format("WinNT://{0}", up.Sid);
            gde.Invoke("Add", new object[] { userADsPath });
            gde.CommitChanges();
            //gde.Children.Add(userAccount, "user");
            //if (up.ContextType == ContextType.Machine)
            //    result = Convert.ToBoolean(gde.Invoke("Add", new object[] { ude.Path }));
            //else
            //    result = Convert.ToBoolean(gde.Invoke("Add", new object[] { up.DistinguishedName })); //or ude.Properties["distinguishedName"].Value
            return true;

            //if (gp.Members.Contains(up)) return true;
            //if (up.IsMemberOf(gp)) return true;
            //gp.Members.Add(up);
            //gp.Save();
            //try
            //{
            //}
            //catch (PrincipalExistsException)
            //{
            //    return true;
            //}
            //catch (Exception ex)
            //{
            //    throw ex;
            //}
        }

        public static void AddDirectorySecurity(string path, string account, FileSystemRights fsRights, InheritanceFlags inheritanceFlags, PropagationFlags propagationFlags, AccessControlType accessControlType)
        {
            string aDPath = "WinNT://" + Environment.MachineName + ",computer";
            AddDirectorySecurity(aDPath, path, account, fsRights, inheritanceFlags, propagationFlags, accessControlType);
        }

        // Adds an ACL entry on the specified directory for the specified account.
        public static void AddDirectorySecurity(string aDPath, string path, string account, FileSystemRights fsRights, InheritanceFlags inheritanceFlags, PropagationFlags propagationFlags, AccessControlType accessControlType)
        {
            // Create a new DirectoryInfo object.
            DirectoryInfo dInfo = new DirectoryInfo(path);

            // Get a DirectorySecurity object that represents the current security settings.
            DirectorySecurity dSecurity = dInfo.GetAccessControl();
            AuthorizationRuleCollection arc = dSecurity.GetAccessRules(true, true, typeof(System.Security.Principal.NTAccount));
            foreach (FileSystemAccessRule rule in arc)
            {
                if ((rule.IdentityReference.Value.Equals(account, StringComparison.InvariantCultureIgnoreCase)
                    && rule.AccessControlType == accessControlType && rule.FileSystemRights == fsRights)) return;
            }
            // Add the FileSystemAccessRule to the security settings. 
            dSecurity.AddAccessRule(new FileSystemAccessRule(account, fsRights, inheritanceFlags, propagationFlags, accessControlType));

            // Set the new access settings.
            dInfo.SetAccessControl(dSecurity);
        }

        #region reference codes

        //Console.WriteLine("Credential=" + ctx.ValidateCredentials(pcs.OperatorAccount.UserName, pcs.OperatorPassword));
        //string[] props = new string[] { "allowedChildClassesEffective" };
        //                DirectoryEntry de = new DirectoryEntry("LDAP://CN=webadmn,CN=Users,DC=MIADMZ1,DC=corp", pcs.OperatorAccount.UserName, pcs.OperatorPassword);
        //DirectoryEntry oude = new DirectoryEntry("LDAP://SUPREME/OU=Users,OU=MIS TEST,OU=Beijing,OU=China,OU=Perry Ellis,DC=supreme,DC=com", pcs.OperatorAccount.ToString(), pcs.OperatorPassword);
        //DirectoryEntry oude = new DirectoryEntry(pcs.LdapRoot, pcs.OperatorAccount.UserName, pcs.OperatorPassword);
        //                DirectoryEntry ude = oude.Children.Add(a.UserName, "User");
        //                ude.Properties["sAMAccountName"].Add(a.UserName);
        //                ude.Properties["displayName"].Add(displayName);
        //Console.WriteLine("DN=", oude.Properties["distinguishedName"][0].ToString());
        //ude.Invoke("SetPassword", new object[] { password });
        //try
        //{
        //    ude.CommitChanges();
        //}
        //catch (Exception ex)
        //{
        //    Console.WriteLine(ex.ToString());                    
        //}
        //Console.WriteLine("allowedChildClassesEffective:");
        //                de.RefreshCache();
        //                ActiveDirectorySchema adSchema = ActiveDirectorySchema.GetSchema(new DirectoryContext(DirectoryContextType.DirectoryServer, pcs.LdapServer, pcs.OperatorAccount.UserName, pcs.OperatorPassword));
        //                ReadOnlyActiveDirectorySchemaClassCollection classes = adSchema.FindClass(SchemaClassType.Structural);
        //                foreach (ActiveDirectorySchemaClass schemaClass in classes)
        //                {
        //                    // Get the entry to retreive all properties/attributes
        ////                    DirectoryEntry entry = schemaClass.GetDirectoryEntry();
        //                    oude.RefreshCache(new string[] { "allowedChildClassesEffective" });
        //                    PropertyValueCollection properties = oude.Properties["allowedChildClassesEffective"];
        //                    for (int i = 0; i < properties.Count; i++) Console.WriteLine(properties[i]);
        //                }
        //ActiveDirectorySchemaClass schemaClass = adSchema.FindClass("user");
        //oude.RefreshCache(new string[] { "allowedChildClassesEffective" });
        //PropertyValueCollection properties = oude.Properties["allowedChildClassesEffective"];
        //for (int i = 0; i < properties.Count; i++) Console.WriteLine(properties[i]);
        //DirectorySearcher ADSearch = new DirectorySearcher(de);
        //ADSearch.CacheResults = true;
        ////ADSearch.PropertiesToLoad.Add("cn");
        ////ADSearch.PropertiesToLoad.Add("allowedChildClassesEffective");
        //ADSearch.Filter = "(allowedChildClassesEffective=*)";
        //foreach (SearchResult ADSearchres in ADSearch.FindAll())
        //{
        //    foreach (string pn in ADSearchres.Properties.PropertyNames)
        //    {
        //        Console.WriteLine(pn + "=" + ADSearchres.Properties[pn]);
        //    }
        //}


        /// <summary>
        /// 根据组名获得组对象
        /// </summary>
        /// <param name="groupName">组名,如DOMAIN\ALL_BJN_MIS</param>
        /// <returns>组对象，错误则返回空</returns>
        //public DirectoryEntry GetGroupEntryByAccount(string groupAccount)
        //{
        //    Account a = new Account(groupAccount);
        //    DirectoryEntry de = GetDirectoryEntryByDomain(a.Domain);
        //    if (IsWinNTProvider(de.Path))
        //    {
        //        de.Children.SchemaFilter.Add("Group");
        //        de = de.Children.Find(a.UserName);
        //        return de;
        //    }
        //    else
        //    {
        //        DirectorySearcher deSearch = new DirectorySearcher(de);
        //        deSearch.Filter = "(&(&(objectCategory=Group)(objectClass=group))(sAMAccountName=" + a.UserName + "))";
        //        deSearch.SearchScope = SearchScope.Subtree;
        //        try
        //        {
        //            SearchResult result = deSearch.FindOne();
        //            de = GetDirectoryEntryByPath(result.Path);
        //            return de;
        //        }
        //        catch
        //        {
        //            return null;
        //        }
        //    }
        //}


        //public bool AddUserToLocalGroup(string aDPath, string userName, string groupName)
        //{
        //    DirectoryEntry de = GetDirectoryEntryByPath(aDPath);
        //    if (de == null) return false;
        //    DirectoryEntry grp = de.Children.Find(groupName, "group");
        //    if (grp != null) grp.Invoke("Add", new object[] { userName });
        //    return true;
        //}

        //public bool SetUserProperties(string account, Dictionary<string, string> properties)
        //{
        //    Account a = new Account(account);
        //    DirectoryEntry de = GetDirectoryEntryByAccount(a);
        //    if (de == null) return false;
        //    foreach (KeyValuePair<string, string> kvp in properties)
        //    {
        //        de.InvokeSet(kvp.Key, new object[] { kvp.Value });
        //    }
        //    return true;
        //}


        /// <summary>
        /// Create a share folder for local machine
        /// </summary>
        /// <param name="folderPath"></param>
        /// <param name="shareName"></param>
        //public bool ShareLocalFolder(string aDPath, string folderPath, string shareName)
        //{
        //    DirectoryEntry de = GetDirectoryEntryByPath(aDPath);
        //    if (de == null) return false;
        //    //de must first link to service LanmanServer "WinNT://LOCALHOST/LanmanServer"
        //    IADsContainer container = de.NativeObject as IADsContainer;
        //    IADsFileShare sharenew = container.Create("FileShare", shareName) as IADsFileShare;
        //    sharenew.Path = folderPath;
        //    sharenew.SetInfo();
        //    return true;
        //}
        /// <summary>
        /// Publish network shares in active directory
        /// </summary>
        /// <param name="ldapPath">for example: "OU=public,dc=supreme,dc=com"</param>
        /// <param name="shareName">"Files"</param>
        /// <param name="shareUncPath">@"\\192.168.2.1\Files"</param>
        /// <param name="shareDescription">"Shared files"</param>
        //public bool ShareLdapFolder(string aDPath, string shareName, string shareUncPath, string shareDescription)
        //{
        //    DirectoryEntry de = GetDirectoryEntryByPath(aDPath);
        //    if (de == null) return false;
        //    DirectoryEntry networkShare = de.Children.Add("CN=" + shareName, "volume");
        //    networkShare.Properties["uNCName"].Value = shareUncPath;
        //    networkShare.Properties["Description"].Value = shareDescription;
        //    networkShare.CommitChanges();
        //    networkShare.Close();
        //    return true;
        //}

        /// <summary>
        /// Create a new security group
        /// Note: by default if no GroupType property is set, the group is created as a domain security group.
        /// </summary>
        /// <param name="name"></param>
        /// <param name="description"></param>
        //public bool CreateGroup(string aDPath, string name, string description)
        //{
        //    DirectoryEntry de = GetDirectoryEntryByPath(aDPath);
        //    if (de == null) return false;
        //    DirectoryEntry group = de.Children.Add("CN=" + name, "group");
        //    group.Properties["sAmAccountName"].Value = name;
        //    group.Properties["Description"].Value = description;
        //    group.CommitChanges();
        //    return true;
        //}

        /// <summary>
        /// Delete a LDAP group
        /// </summary>
        /// <param name="groupPath"></param>
        //public bool DeleteGroup(string aDPath, string groupPath)
        //{
        //    if (DirectoryEntry.Exists(aDPath))
        //    {
        //        using (DirectoryEntry entry = new DirectoryEntry(aDPath))
        //        {
        //            DirectoryEntry group = new DirectoryEntry(groupPath);
        //            entry.Children.Remove(group);
        //            group.CommitChanges();
        //        }
        //    }
        //    return true;
        //}

        // Removes an ACL entry on the specified directory for the specified account.
        //public static void RemoveDirectorySecurity(string aDPath, string path, string account, FileSystemRights rights, AccessControlType controlType)
        //{
        //    // Create a new DirectoryInfo object.
        //    DirectoryInfo dInfo = new DirectoryInfo(path);

        //    // Get a DirectorySecurity object that represents the current security settings.
        //    DirectorySecurity dSecurity = dInfo.GetAccessControl();

        //    // Add the FileSystemAccessRule to the security settings. 
        //    dSecurity.RemoveAccessRule(new FileSystemAccessRule(account, rights, controlType));

        //    // Set the new access settings.
        //    dInfo.SetAccessControl(dSecurity);
        //}

        //public static void TurnOffDirectoryInheriting(string path)
        //{
        //    DirectoryInfo dInfo = new DirectoryInfo(path);
        //    DirectorySecurity dSecurity = dInfo.GetAccessControl();
        //    if (dSecurity.GetOwner(typeof(System.Security.Principal.NTAccount)).Value !=Thread.CurrentPrincipal.Identity.Name)
        //        dSecurity.SetOwner(new NTAccount(Thread.CurrentPrincipal.Identity.Name));

        //    //isProtected
        //    //要防止与此 ObjectSecurity 对象关联的访问规则被继承，则为 true；要允许继承，则为 false。
        //    //preserveInheritance
        //    //要保留继承的访问规则，则为 true；要移除继承的访问规则，则为 false。如果 isProtected 为 false，则忽略此参数。
        //    dSecurity.SetAccessRuleProtection(true, false);

        //    dInfo.SetAccessControl(dSecurity);
        //}

        public static void TurnOnDirectoryInheriting(string path)
        {
            DirectoryInfo dInfo = new DirectoryInfo(path);
            DirectorySecurity dSecurity = dInfo.GetAccessControl();
            dSecurity.SetAccessRuleProtection(false, true);
            dInfo.SetAccessControl(dSecurity);
        }
        ///// <summary>
        ///// Enumerate objects in an OU
        ///// </summary>
        ///// <param name="OuDn">The parameter OuDn is the Organizational Unit distinguishedName such as OU=Users,dc=myDomain,dc=com</param>
        ///// <returns></returns>
        //public List<string> EnumerateOU(string aDPath)
        //{
        //    List<string> alObjects = new List<string>();
        //    DirectoryEntry de = GetDirectoryEntryByPath(aDPath);

        //    foreach (DirectoryEntry child in de.Children)
        //    {
        //        string childPath = child.Path.ToString();
        //        alObjects.Add(childPath.Remove(0, 7));  //remove the LDAP prefix from the path
        //    }
        //    return alObjects;
        //}

        ///// <summary>
        ///// get full domain name by friendly domain name
        ///// </summary>
        ///// <param name="friendlyDomainName">for example: supreme</param>
        ///// <returns>for example: supreme.com</returns>
        //public static string FriendlyDomainToLdapDomain(string friendlyDomainName)
        //{
        //    string ldapPath = null;
        //    try
        //    {
        //        DirectoryContext objContext = new DirectoryContext(DirectoryContextType.Domain, friendlyDomainName);
        //        Domain objDomain = Domain.GetDomain(objContext);
        //        ldapPath = objDomain.Name;
        //    }
        //    catch (DirectoryServicesCOMException e)
        //    {
        //        ldapPath = e.Message.ToString();
        //    }
        //    return ldapPath;
        //}

        ///// <summary>
        ///// 
        ///// </summary>
        ///// <param name="userDn"></param>
        //public void EnableLdapUser(string aDPath)
        //{
        //    DirectoryEntry user = GetDirectoryEntryByPath(aDPath);
        //    int val = (int)user.Properties["userAccountControl"].Value;
        //    user.Properties["userAccountControl"].Value = val & ~ADS_USER_FLAG.ADS_UF_ACCOUNTDISABLE.GetHashCode() & ~ADS_USER_FLAG.ADS_UF_DONT_EXPIRE_PASSWD.GetHashCode();
        //    user.CommitChanges();
        //    user.Close();
        //}

        //public void DisableLdapUser(string aDPath)
        //{
        //    DirectoryEntry user = GetDirectoryEntryByPath(aDPath);
        //    int val = (int)user.Properties["userAccountControl"].Value;
        //    user.Properties["userAccountControl"].Value = val | ADS_USER_FLAG.ADS_UF_ACCOUNTDISABLE.GetHashCode();
        //    user.CommitChanges();
        //    user.Close();
        //}

        ///// <summary>
        ///// unlock user account
        ///// </summary>
        ///// <param name="userDn"></param>
        //public void UnlockLdapUser(string aDPath)
        //{
        //    DirectoryEntry uEntry = GetDirectoryEntryByPath(aDPath);
        //    uEntry.Properties["LockOutTime"].Value = 0; //unlock account
        //    uEntry.CommitChanges(); //may not be needed but adding it anyways
        //    uEntry.Close();
        //}
        ///// <summary>
        ///// Reset a user password
        ///// </summary>
        ///// <param name="userDn"></param>
        ///// <param name="password"></param>
        //public void ResetLdapUserPassword(string aDPath, string password)
        //{
        //    DirectoryEntry uEntry = GetDirectoryEntryByPath(aDPath);
        //    uEntry.Invoke("SetPassword", new object[] { password });
        //    uEntry.Properties["LockOutTime"].Value = 0; //unlock account
        //    uEntry.Close();
        //}

        //public bool RenameLdapObject(string aDPath, string newName)
        //{
        //    DirectoryEntry child = GetDirectoryEntryByPath(aDPath);
        //    child.Rename("CN=" + newName);
        //    return true;
        //}

        //public static List<string> EnumerateForestTrustRelationshipInformation()
        //{
        //    List<string> alDomains = new List<string>();
        //    Forest currentForest = Forest.GetCurrentForest();
        //    DomainCollection myDomains = currentForest.Domains;

        //    foreach (Domain objDomain in myDomains)
        //    {
        //        alDomains.Add(objDomain.Name);
        //    }
        //    return alDomains;
        //}

        //public static List<string> EnumerateDomains()
        //{
        //    List<string> alDomains = new List<string>();
        //    Forest currentForest = Forest.GetCurrentForest();
        //    DomainCollection myDomains = currentForest.Domains;

        //    foreach (Domain objDomain in myDomains)
        //    {
        //        alDomains.Add(objDomain.Name);
        //    }
        //    return alDomains;
        //}

        //public List<string> GetTrustedDomains()
        //{
        //    SearchResultCollection resultCollection = SearchActiveDirectory("container", "System");
        //    List<string> arrList = new List<string>();
        //    if (resultCollection != null)
        //    {
        //        foreach (SearchResult sr in resultCollection)
        //        {
        //            DirectoryEntry entry = sr.GetDirectoryEntry();
        //            foreach (DirectoryEntry newEntry in entry.Children)
        //            {
        //                if (newEntry.SchemaClassName == "trustedDomain")
        //                {
        //                    arrList.Add(newEntry.Name.Substring(3));
        //                }
        //            }
        //        }
        //    }
        //    return arrList;
        //}

        /// <summary>
        /// Search AD by DirectorySearcher object
        /// </summary>
        /// <param name="categoryType">container, trustedDomain etc.</param>
        /// <param name="nameString"></param>
        /// <returns></returns>
        //private SearchResultCollection SearchActiveDirectory(string categoryType, string nameString)
        //{
        //    string filterString;
        //    DirectorySearcher directorySearcher = new DirectorySearcher();
        //    filterString = String.Format("(&(objectCategory={0})(name={1}))", categoryType, nameString);
        //    //directorySearcher.SearchRoot = new DirectoryEntry(Path, UserName, Password, AuthType);
        //    directorySearcher.SearchRoot = new DirectoryEntry(aDRoot);
        //    directorySearcher.Filter = filterString; SearchResultCollection searchResultCollection = null;
        //    try
        //    {
        //        searchResultCollection = directorySearcher.FindAll();
        //    }
        //    catch { }
        //    return searchResultCollection;
        //}

        //public static string GetRootDomainNamingContext()
        //{
        //    string dnc = string.Empty;
        //    DirectoryEntry de = new DirectoryEntry("LDAP://RootDSE");
        //    if (de != null)
        //    {
        //        dnc = de.Properties["RootDomainNamingContext"].ToString();
        //    }
        //    return dnc;
        //}

        //public static List<string> EnumerateCatalogs()
        //{
        //    List<string> alGCs = new List<string>();
        //    Forest currentForest = Forest.GetCurrentForest();
        //    foreach (GlobalCatalog gc in currentForest.GlobalCatalogs)
        //    {
        //        alGCs.Add(gc.Name);
        //    }
        //    return alGCs;
        //}

        //public static List<string> EnumerateDomainControllers()
        //{
        //    List<string> alDcs = new List<string>();
        //    Domain domain = Domain.GetCurrentDomain();
        //    foreach (DomainController dc in domain.DomainControllers)
        //    {
        //        alDcs.Add(dc.Name);
        //    }
        //    return alDcs;
        //}

        //public void CreateTrust(string sourceForestName, string targetForestName)
        //{
        //    Forest sourceForest = Forest.GetForest(new DirectoryContext(DirectoryContextType.Forest, sourceForestName));

        //    Forest targetForest = Forest.GetForest(new DirectoryContext(DirectoryContextType.Forest, targetForestName));

        //    // create an inbound forest trust
        //    sourceForest.CreateTrustRelationship(targetForest, TrustDirection.Outbound);
        //}

        //public void DeleteTrust(string sourceForestName, string targetForestName)
        //{
        //    Forest sourceForest = Forest.GetForest(new DirectoryContext(DirectoryContextType.Forest, sourceForestName));

        //    Forest targetForest = Forest.GetForest(new DirectoryContext(DirectoryContextType.Forest, targetForestName));

        //    // delete forest trust
        //    sourceForest.DeleteTrustRelationship(targetForest);
        //}
        #endregion

        /// 
        /// 用户登录验证结果
        /// 
        public enum LoginResult
        {
            /// 
            /// 正常登录
            /// 
            LOGIN_USER_OK = 0,

            /// 
            /// 用户不存在
            /// 
            LOGIN_USER_DOESNT_EXIST,

            /// 
            /// 用户帐号被禁用
            /// 
            LOGIN_USER_ACCOUNT_INACTIVE,

            /// 
            /// 用户密码不正确
            /// 
            LOGIN_USER_PASSWORD_INCORRECT,

            /// <summary>
            /// 登录异常
            /// </summary>
            LOGIN_EXCEPTION

        }

        public class Account : IEquatable<Account>
        {
            private string domain = string.Empty;

            public string Domain
            {
                get { return domain; }
                set
                {
                    if (value != null) domain = value.ToUpper();
                    else domain = value;
                    if (domain == Environment.MachineName || domain == "LOCALHOST") domain = ".";
                }
            }

            private string userName = string.Empty;

            public string UserName
            {
                get { return userName; }
                set
                {
                    if (value != null) userName = value.ToLower();
                    else userName = value;
                }
            }

            public Account(string accountString)
            {
                int i = accountString.IndexOf('\\');
                userName = accountString;
                if (i >= 0)
                {
                    Domain = accountString.Substring(0, i);
                    if (accountString.Length > i) userName = accountString.Substring(i + 1).ToLower();
                }
                else domain = ".";
            }
            /// <summary>
            /// Get regular account name, format as "DOMAIN\username"
            /// </summary>
            /// <returns>regular account name string</returns>
            public override string ToString()
            {
                //string toString = "";
                //if (domain == ".") toString = Environment.MachineName;
                //else toString = domain;
                return domain + "\\" + userName;
            }

            #region IEquatable<Account> Members

            public bool Equals(Account other)
            {
                return (domain == other.Domain && userName == other.userName);
            }

            #endregion
        }
    }

    public enum ErrorMsg
    {
        None = 0,
        Not_Administrator = 10000001,
        Duplicate_Name = 10000002, //User Folder Name
        Duplicate_Account = 10000003,
        Name_Not_Found = 10000004,
        User_Disabled = 10000005,
        User_Not_Disabled = 10000006,
        Invalid_Account = 10000007,
        Unknown = -1,

    }
    public enum ADS_GROUP_TYPE_ENUM : long
    {
        ADS_GROUP_TYPE_GLOBAL_GROUP = 0x00000002,
        ADS_GROUP_TYPE_DOMAIN_LOCAL_GROUP = 0x00000004,
        ADS_GROUP_TYPE_LOCAL_GROUP = 0x00000004,
        ADS_GROUP_TYPE_UNIVERSAL_GROUP = 0x00000008,
        ADS_GROUP_TYPE_SECURITY_ENABLED = 0x80000000
    }

    public enum ADS_USER_FLAG
    {
        ADS_UF_SCRIPT = 1,        // 0x1
        ADS_UF_ACCOUNTDISABLE = 2,        // 0x2
        ADS_UF_HOMEDIR_REQUIRED = 8,        // 0x8
        ADS_UF_LOCKOUT = 16,       // 0x10
        ADS_UF_PASSWD_NOTREQD = 32,       // 0x20
        ADS_UF_PASSWD_CANT_CHANGE = 64,       // 0x40
        ADS_UF_ENCRYPTED_TEXT_PASSWORD_ALLOWED = 128,      // 0x80
        ADS_UF_TEMP_DUPLICATE_ACCOUNT = 256,      // 0x100
        ADS_UF_NORMAL_ACCOUNT = 512,      // 0x200
        ADS_UF_INTERDOMAIN_TRUST_ACCOUNT = 2048,     // 0x800
        ADS_UF_WORKSTATION_TRUST_ACCOUNT = 4096,     // 0x1000
        ADS_UF_SERVER_TRUST_ACCOUNT = 8192,     // 0x2000
        ADS_UF_DONT_EXPIRE_PASSWD = 65536,    // 0x10000
        ADS_UF_MNS_LOGON_ACCOUNT = 131072,   // 0x20000
        ADS_UF_SMARTCARD_REQUIRED = 262144,   // 0x40000
        ADS_UF_TRUSTED_FOR_DELEGATION = 524288,   // 0x80000
        ADS_UF_NOT_DELEGATED = 1048576,  // 0x100000
        ADS_UF_USE_DES_KEY_ONLY = 2097152,  // 0x200000
        ADS_UF_DONT_REQUIRE_PREAUTH = 4194304,  // 0x400000
        ADS_UF_PASSWORD_EXPIRED = 8388608,  // 0x800000
        ADS_UF_TRUSTED_TO_AUTHENTICATE_FOR_DELEGATION = 16777216 // 0x1000000
    }

    /// <summary>
    /// An impersonation class (modified from http://born2code.net/?page_id=45) that supports LocalService and NetworkService logons.
    /// Note: To use these built-in logons the code must be running under the local system account.
    /// </summary>
    //public class Impersonation : IDisposable
    //{

    //    #region Dll Imports
    //    /// <summary>
    //    /// Closes an open object handle.
    //    /// </summary>
    //    /// <param name="hObject">A handle to an open object.</param>
    //    /// <returns><c>True</c> when succeeded; otherwise <c>false</c>.</returns>
    //    [DllImport("kernel32.dll")]
    //    private static extern Boolean CloseHandle(IntPtr hObject);

    //    /// <summary>
    //    /// Attempts to log a user on to the local computer.
    //    /// </summary>
    //    /// <param name="username">This is the name of the user account to log on to. 
    //    /// If you use the user principal name (UPN) format, user@DNSdomainname, the 
    //    /// domain parameter must be <c>null</c>.</param>
    //    /// <param name="domain">Specifies the name of the domain or server whose 
    //    /// account database contains the lpszUsername account. If this parameter 
    //    /// is <c>null</c>, the user name must be specified in UPN format. If this 
    //    /// parameter is ".", the function validates the account by using only the 
    //    /// local account database.</param>
    //    /// <param name="password">The password</param>
    //    /// <param name="logonType">The logon type</param>
    //    /// <param name="logonProvider">The logon provides</param>
    //    /// <param name="userToken">The out parameter that will contain the user 
    //    /// token when method succeeds.</param>
    //    /// <returns><c>True</c> when succeeded; otherwise <c>false</c>.</returns>
    //    [DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    //    private static extern bool LogonUser(string username, string domain,
    //                                          string password, LogonType logonType,
    //                                          LogonProvider logonProvider,
    //                                          out IntPtr userToken);

    //    /// <summary>
    //    /// Creates a new access token that duplicates one already in existence.
    //    /// </summary>
    //    /// <param name="token">Handle to an access token.</param>
    //    /// <param name="impersonationLevel">The impersonation level.</param>
    //    /// <param name="duplication">Reference to the token to duplicate.</param>
    //    /// <returns></returns>
    //    [DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    //    private static extern bool DuplicateToken(IntPtr token, int impersonationLevel,
    //        ref IntPtr duplication);

    //    /// <summary>
    //    /// The ImpersonateLoggedOnUser function lets the calling thread impersonate the 
    //    /// security context of a logged-on user. The user is represented by a token handle.
    //    /// </summary>
    //    /// <param name="userToken">Handle to a primary or impersonation access token that represents a logged-on user.</param>
    //    /// <returns>If the function succeeds, the return value is nonzero.</returns>
    //    [DllImport("advapi32.dll", SetLastError = true)]
    //    static extern bool ImpersonateLoggedOnUser(IntPtr userToken);
    //    #endregion

    //    #region Private members
    //    /// <summary>
    //    /// <c>true</c> if disposed; otherwise, <c>false</c>.
    //    /// </summary>
    //    private bool _disposed;

    //    /// <summary>
    //    /// Holds the created impersonation context and will be used
    //    /// for reverting to previous user.
    //    /// </summary>
    //    private WindowsImpersonationContext _impersonationContext;
    //    #endregion

    //    #region Ctor & Dtor

    //    /// <summary>
    //    /// Initializes a new instance of the <see cref="Impersonation"/> class and
    //    /// impersonates as a built in service account.
    //    /// </summary>
    //    /// <param name="builtinUser">The built in user to impersonate - either
    //    /// Local Service or Network Service. These users can only be impersonated
    //    /// by code running as System.</param>
    //    public Impersonation(BuiltinUser builtinUser)
    //        : this(String.Empty, "NT AUTHORITY", String.Empty, LogonType.Service, builtinUser)
    //    {
    //    }

    //    /// <summary>
    //    /// Initializes a new instance of the <see cref="Impersonation"/> class and
    //    /// impersonates with the specified credentials.
    //    /// </summary>
    //    /// <param name="username">his is the name of the user account to log on 
    //    /// to. If you use the user principal name (UPN) format, 
    //    /// user@DNS_domain_name, the lpszDomain parameter must be <c>null</c>.</param>
    //    /// <param name="domain">The name of the domain or server whose account 
    //    /// database contains the lpszUsername account. If this parameter is 
    //    /// <c>null</c>, the user name must be specified in UPN format. If this 
    //    /// parameter is ".", the function validates the account by using only the 
    //    /// local account database.</param>
    //    /// <param name="password">The plaintext password for the user account.</param>
    //    public Impersonation(String username, String domain, String password)
    //        : this(username, domain, password, LogonType.Interactive, BuiltinUser.None)
    //    {
    //    }

    //    private Impersonation(String username, String domain, String password, LogonType logonType, BuiltinUser builtinUser)
    //    {
    //        switch (builtinUser)
    //        {
    //            case BuiltinUser.None: if (String.IsNullOrEmpty(username)) return; break;
    //            case BuiltinUser.LocalService: username = "LOCAL SERVICE"; break;
    //            case BuiltinUser.NetworkService: username = "NETWORK SERVICE"; break;
    //        }

    //        IntPtr userToken = IntPtr.Zero;
    //        IntPtr userTokenDuplication = IntPtr.Zero;

    //        // Logon with user and get token.
    //        bool loggedOn = LogonUser(username, domain, password,
    //            logonType, LogonProvider.Default,
    //            out userToken);

    //        if (loggedOn)
    //        {
    //            try
    //            {
    //                // Create a duplication of the usertoken, this is a solution
    //                // for the known bug that is published under KB article Q319615.
    //                if (DuplicateToken(userToken, 2, ref userTokenDuplication))
    //                {
    //                    // Create windows identity from the token and impersonate the user.
    //                    WindowsIdentity identity = new WindowsIdentity(userTokenDuplication);
    //                    _impersonationContext = identity.Impersonate();
    //                }
    //                else
    //                {
    //                    // Token duplication failed!
    //                    // Use the default ctor overload
    //                    // that will use Mashal.GetLastWin32Error();
    //                    // to create the exceptions details.
    //                    throw new Win32Exception();
    //                }
    //            }
    //            finally
    //            {
    //                // Close usertoken handle duplication when created.
    //                if (!userTokenDuplication.Equals(IntPtr.Zero))
    //                {
    //                    // Closes the handle of the user.
    //                    CloseHandle(userTokenDuplication);
    //                    userTokenDuplication = IntPtr.Zero;
    //                }


    //                // Close usertoken handle when created.
    //                if (!userToken.Equals(IntPtr.Zero))
    //                {
    //                    // Closes the handle of the user.
    //                    CloseHandle(userToken);
    //                    userToken = IntPtr.Zero;
    //                }
    //            }
    //        }
    //        else
    //        {
    //            // Logon failed!
    //            // Use the default ctor overload that 
    //            // will use Mashal.GetLastWin32Error();
    //            // to create the exceptions details.
    //            throw new Win32Exception();
    //        }
    //    }

    //    /// <summary>
    //    /// Releases unmanaged resources and performs other cleanup operations before the
    //    /// <see cref="Born2Code.Net.Impersonation"/> is reclaimed by garbage collection.
    //    /// </summary>
    //    ~Impersonation()
    //    {
    //        Dispose(false);
    //    }
    //    #endregion

    //    #region Public methods
    //    /// <summary>
    //    /// Reverts to the previous user.
    //    /// </summary>
    //    public void Revert()
    //    {
    //        if (_impersonationContext != null)
    //        {
    //            // Revert to previour user.
    //            _impersonationContext.Undo();
    //            _impersonationContext = null;
    //        }
    //    }
    //    #endregion

    //    #region IDisposable implementation.
    //    /// <summary>
    //    /// Performs application-defined tasks associated with freeing, releasing, or
    //    /// resetting unmanaged resources and will revent to the previous user when
    //    /// the impersonation still exists.
    //    /// </summary>
    //    public void Dispose()
    //    {
    //        Dispose(true);
    //        GC.SuppressFinalize(this);
    //    }

    //    /// <summary>
    //    /// Performs application-defined tasks associated with freeing, releasing, or
    //    /// resetting unmanaged resources and will revent to the previous user when
    //    /// the impersonation still exists.
    //    /// </summary>
    //    /// <param name="disposing">Specify <c>true</c> when calling the method directly
    //    /// or indirectly by a user’s code; Otherwise <c>false</c>.
    //    protected virtual void Dispose(bool disposing)
    //    {
    //        if (!_disposed)
    //        {
    //            Revert();

    //            _disposed = true;
    //        }
    //    }
    //    #endregion

    //    #region Enums

    //    public enum LogonType : int
    //    {
    //        /// <summary>
    //        /// This logon type is intended for users who will be interactively using the computer, such as a user being logged on  
    //        /// by a terminal server, remote shell, or similar process.
    //        /// This logon type has the additional expense of caching logon information for disconnected operations;
    //        /// therefore, it is inappropriate for some client/server applications,
    //        /// such as a mail server.
    //        /// </summary>
    //        Interactive = 2,

    //        /// <summary>
    //        /// This logon type is intended for high performance servers to authenticate plaintext passwords.
    //        /// The LogonUser function does not cache credentials for this logon type.
    //        /// </summary>
    //        Network = 3,

    //        /// <summary>
    //        /// This logon type is intended for batch servers, where processes may be executing on behalf of a user without
    //        /// their direct intervention. This type is also for higher performance servers that process many plaintext
    //        /// authentication attempts at a time, such as mail or Web servers.
    //        /// The LogonUser function does not cache credentials for this logon type.
    //        /// </summary>
    //        Batch = 4,

    //        /// <summary>
    //        /// Indicates a service-type logon. The account provided must have the service privilege enabled.
    //        /// </summary>
    //        Service = 5,

    //        /// <summary>
    //        /// This logon type is for GINA DLLs that log on users who will be interactively using the computer.
    //        /// This logon type can generate a unique audit record that shows when the workstation was unlocked.
    //        /// </summary>
    //        Unlock = 7,

    //        /// <summary>
    //        /// This logon type preserves the name and password in the authentication package, which allows the server to make
    //        /// connections to other network servers while impersonating the client. A server can accept plaintext credentials
    //        /// from a client, call LogonUser, verify that the user can access the system across the network, and still
    //        /// communicate with other servers.
    //        /// NOTE: Windows NT:  This value is not supported.
    //        /// </summary>
    //        NetworkCleartText = 8,

    //        /// <summary>
    //        /// This logon type allows the caller to clone its current token and specify new credentials for outbound connections.
    //        /// The new logon session has the same local identifier but uses different credentials for other network connections.
    //        /// NOTE: This logon type is supported only by the LOGON32_PROVIDER_WINNT50 logon provider.
    //        /// NOTE: Windows NT:  This value is not supported.
    //        /// </summary>
    //        NewCredentials = 9,
    //    }

    //    public enum LogonProvider : int
    //    {
    //        /// <summary>
    //        /// Use the standard logon provider for the system.
    //        /// The default security provider is negotiate, unless you pass NULL for the domain name and the user name
    //        /// is not in UPN format. In this case, the default provider is NTLM.
    //        /// NOTE: Windows 2000/NT:   The default security provider is NTLM.
    //        /// </summary>
    //        Default = 0,
    //    }

    //    public enum BuiltinUser
    //    {
    //        None,
    //        LocalService,
    //        NetworkService
    //    }

    //    #endregion

    //}

    /////
    /////用户模拟角色类。实现在程序段内进行用户角色模拟。
    /////
    //public class IdentityImpersonation
    //{
    //    [DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    //    public extern static bool DuplicateToken(IntPtr ExistingTokenHandle, int SECURITY_IMPERSONATION_LEVEL, ref IntPtr DuplicateTokenHandle);

    //    [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
    //    public extern static bool CloseHandle(IntPtr handle);


    //    // 要模拟的用户的用户名、密码、域(机器名)
    //    private String _sImperUsername;
    //    private String _sImperPassword;
    //    private String _sImperDomain;

    //    // 记录模拟上下文
    //    private WindowsImpersonationContext _imperContext;
    //    private IntPtr _adminToken;
    //    private IntPtr _dupeToken;

    //    // 是否已停止模拟
    //    private Boolean _bClosed;

    //    ///
    //    /// 构造函数
    //    ///
    //    /// 所要模拟的用户的用户名
    //    /// 所要模拟的用户的密码
    //    /// 所要模拟的用户所在的域
    //    public IdentityImpersonation(String impersonationUsername, String impersonationPassword, String impersonationDomain)
    //    {
    //        _sImperUsername = impersonationUsername;
    //        _sImperPassword = impersonationPassword;
    //        _sImperDomain = impersonationDomain;

    //        _adminToken = IntPtr.Zero;
    //        _dupeToken = IntPtr.Zero;
    //        _bClosed = true;
    //    }



    //    ///
    //    /// 析构函数
    //    ///

    //    ~IdentityImpersonation()
    //    {
    //        if (!_bClosed)
    //        {
    //            StopImpersonate();
    //        }

    //    }

    //    ///
    //    /// 开始身份角色模拟。
    //    ///
    //    public Boolean BeginImpersonate()
    //    {
    //        Boolean bLogined = LogonUser(_sImperUsername, _sImperDomain, _sImperPassword, 2, 0, ref _adminToken);
    //        if (!bLogined)
    //        {
    //            return false;
    //        }

    //        Boolean bDuped = DuplicateToken(_adminToken, 2, ref _dupeToken);

    //        if (!bDuped)
    //        {
    //            return false;
    //        }

    //        WindowsIdentity fakeId = new WindowsIdentity(_dupeToken);
    //        _imperContext = fakeId.Impersonate();

    //        _bClosed = false;

    //        return true;
    //    }


    //    ///
    //    /// 停止身分角色模拟。
    //    ///

    //    public void StopImpersonate()
    //    {
    //        _imperContext.Undo();
    //        CloseHandle(_dupeToken);
    //        CloseHandle(_adminToken);
    //        _bClosed = true;
    //    }

    //}
}
