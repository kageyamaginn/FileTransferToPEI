﻿////////////////////////////////////////////////////////////////////////////
//
//  $RCSfile: PrincipalContextStore.cs,v $
//  $Revision: 1.1 $
//  $Author: SUPREME\geleo1 $
//  $Date: 2009/02/11 07:32:42 $
//
//  -----------------------------------------
//  Copyright Perry Ellis International, Inc.
//  -----------------------------------------
//
////////////////////////////////////////////////////////////////////////////


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.DirectoryServices.AccountManagement;
using System.Security.Cryptography;
using DirectoryServices;

namespace Pei.DirectoryServices
{
    public class PrincipalContextStore
    {
        private string name;

        public string Name
        {
            get { return name; }
            set { if (value == ".") name = null; else name = value; }
        }

        private string container;

        public string Container
        {
            get { return container; }
            set { if (value == "." || value == "") container = null; else  container = value; }
        }

        private ContextType type;

        public ContextType Type
        {
            get { return type; }
            set
            {
                type = value;
                switch (type)
                {
                    case ContextType.Machine:
                        ldapType = "WinNT://";
                        break;
                    case ContextType.Domain:
                        ldapType = "LDAP://";
                        break;
                    case ContextType.ApplicationDirectory:
                        ldapType = "ADS://";
                        break;
                }
            }
        }

        private string ldapType;

        private PrincipalContext context;

        public PrincipalContext Context
        {
            get
            {
                if (context == null)
                {
                    switch (type)
                    {
                        case ContextType.Machine:
                            //                            ldapType = "WinNT://";
                            if (name == null) name = Environment.MachineName;
                            if (operatorAccount == null)
                                context = new PrincipalContext(type, name);
                            else
                                context = new PrincipalContext(type, name, operatorAccount.UserName, operatorPassword);
                            break;
                        case ContextType.Domain:
                            //                            ldapType = "LDAP://";
                            if (operatorAccount == null)
                                context = new PrincipalContext(type, name, container);
                            else
                                context = new PrincipalContext(type, name, container, operatorAccount.UserName, operatorPassword);
                            break;
                        case ContextType.ApplicationDirectory:
                            //                            ldapType = "ADS://";
                            if (operatorAccount == null)
                                context = new PrincipalContext(type, name, container, ContextOptions.SimpleBind);
                            else
                                context = new PrincipalContext(type, name, container, ContextOptions.SimpleBind, operatorAccount.UserName, operatorPassword);
                            break;
                    }
                }
                return context;
            }
        }

        private ADHelper.Account operatorAccount;

        public ADHelper.Account OperatorAccount
        {
            get { return operatorAccount; }
            set { operatorAccount = value; }
        }

        private string operatorPassword;

        public string OperatorPassword
        {
            get { return operatorPassword; }
            set { operatorPassword = value; }
        }

        private string ldapServer;

        public string LdapServer
        {
            get { return ldapServer; }
            set { ldapServer = value; }
        }

        public string LdapRoot
        {
            get
            {
                return ldapType + name + "/" + container;
                //if (string.IsNullOrEmpty(LdapServer)) return ldapType + name + "/" + container;
                //else return ldapType + LdapServer + "/" + container;
            }
        }

        public static Dictionary<string, PrincipalContextStore> LoadXml(string principalStoreDataXml, bool encryptPassword)
        {
            Dictionary<string, PrincipalContextStore> pcs = new Dictionary<string, PrincipalContextStore>();
            PrincipalStoreData principalStoreData = new PrincipalStoreData();
            principalStoreData.ReadXml(principalStoreDataXml);

            foreach (PrincipalStoreData.PrincipalStoreRow r in principalStoreData.PrincipalStore.Rows)
            {
                PrincipalContextStore s = new PrincipalContextStore();
                s.Type = (ContextType)Enum.Parse(typeof(ContextType), r.Type);
                switch (s.Type)
                {
                    case ContextType.Machine:
                        if (r.Name == null || r.Name == "." || r.Name == "") s.Name = Environment.MachineName;
                        if (r.Container == null || r.Container == "." || r.Container == "") s.Container = s.Name;
                        break;
                    case ContextType.Domain:
                        s.Name = r.Name.ToUpper();
                        s.Container = r.Container;
                        break;
                    case ContextType.ApplicationDirectory:
                        s.Name = r.Name.ToUpper();
                        s.Container = r.Container;
                        break;
                }
                if (!string.IsNullOrEmpty(r.OperatorAccount))
                {
                    s.OperatorAccount = new ADHelper.Account(r.OperatorAccount);
                    if (encryptPassword) s.OperatorPassword = TDESDecrypt(r.OperatorPassword, Environment.MachineName);
                    else s.operatorPassword = r.OperatorPassword;
                }
                s.LdapServer = r.LdapServer;
                pcs.Add(r.Name, s);
            }
            return pcs;
        }

        /// <summary>
        /// 加密文本
        /// </summary>
        /// <param name="text">需要加密的明文</param>
        /// <param name="privateKey">私钥，解密时必须相同</param>
        /// <returns>加密后的密文，若加密操作失败则返回空</returns>
        public static string TDESEncrypt(string text, string privateKey)
        {
            try
            {
                TripleDESCryptoServiceProvider tdes = new TripleDESCryptoServiceProvider();
                MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();
                tdes.Key = md5.ComputeHash(UnicodeEncoding.Default.GetBytes(privateKey));
                tdes.IV = new byte[] { 2, 1, 5, 4, 3, 6, 7, 0 };
                tdes.Mode = CipherMode.CBC;
                ICryptoTransform tdesEncryptor = tdes.CreateEncryptor();
                byte[] buff = UnicodeEncoding.Default.GetBytes(text);
                return Convert.ToBase64String(tdesEncryptor.TransformFinalBlock(buff, 0, buff.Length));
            }
            catch
            {
                return string.Empty;
            }
        }

        /// <summary>
        /// 解密密文
        /// </summary>
        /// <param name="text">需要解密的密文</param>
        /// <param name="privateKey">私钥，必须与加密时相同</param>
        /// <returns>解密后的明文，失败则为空</returns>
        public static string TDESDecrypt(string text, string privateKey)
        {
            try
            {
                TripleDESCryptoServiceProvider tdes = new TripleDESCryptoServiceProvider();
                MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();
                tdes.Key = md5.ComputeHash(UnicodeEncoding.Default.GetBytes(privateKey));
                tdes.IV = new byte[] { 2, 1, 5, 4, 3, 6, 7, 0 };
                tdes.Mode = CipherMode.CBC;
                ICryptoTransform tdesDecryptor = tdes.CreateDecryptor();
                byte[] buff = Convert.FromBase64String(text);
                var str = UnicodeEncoding.Default.GetString(tdesDecryptor.TransformFinalBlock(buff, 0, buff.Length));
                return UnicodeEncoding.Default.GetString(tdesDecryptor.TransformFinalBlock(buff, 0, buff.Length));
            }
            catch
            {
                return string.Empty;
            }
        }
    }

}
