﻿namespace DirectoryServices
{


    partial class PrincipalStoreData
    {
    }
}
